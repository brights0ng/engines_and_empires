// Written by ChatGPT from Claude's M5b spec.
// Edited by Claude: fixed wall temperatures per solid cell (M7c).
package dev.brights0ng.greedyfluids.grid;

import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;

/** Dense editable grid of 1 m cubes, indexed (y * nz + z) * nx + x. */
public final class CellGrid3D {
    /** Domain side; axes x, y, z are numbered 0, 1, 2. */
    public enum Side {
        WEST, EAST, DOWN, UP, NORTH, SOUTH;
        /** Normal axis, dimensionless. */
        public int axis() { return ordinal() / 2; }
        /** Whether this side is at the high coordinate. */
        public boolean high() { return (ordinal() & 1) != 0; }
    }
    /** Flow condition on a domain side. */
    public enum Boundary { OPEN, INFLOW, CLOSED }
    private final int nx, ny, nz;
    private final CellType[] types;
    private final Material[] materials;
    private final boolean[] doors;
    /** Fixed wall temperatures, °C, by cell (NaN: none); null until one is set. */
    private double[] fixed;
    private final Map<Integer, Double> sources = new TreeMap<>();
    private final Map<Integer, Double> sourceView = Collections.unmodifiableMap(sources);
    private final Boundary[] boundaries = {Boundary.OPEN, Boundary.OPEN, Boundary.CLOSED,
            Boundary.OPEN, Boundary.OPEN, Boundary.OPEN};
    private final double[] speeds = new double[6];

    /** Creates an AIR grid with positive dimensions in cells (= m). */
    public CellGrid3D(int nx, int ny, int nz) {
        if (nx <= 0 || ny <= 0 || nz <= 0 || (long) nx * ny > Integer.MAX_VALUE / nz)
            throw new IllegalArgumentException("invalid grid dimensions");
        this.nx = nx; this.ny = ny; this.nz = nz;
        types = new CellType[nx * ny * nz];
        Arrays.fill(types, CellType.AIR);
        materials = new Material[types.length];
        doors = new boolean[types.length];
    }
    /** x extent, cells (= m). */
    public int nx() { return nx; }
    /** y extent, cells (= m). */
    public int ny() { return ny; }
    /** z extent, cells (= m). */
    public int nz() { return nz; }
    /** Cell index, dimensionless; coordinates are cells. */
    public int index(int x, int y, int z) { return (y * nz + z) * nx + x; }
    /** Whether the cell coordinates lie in this grid. */
    public boolean inBounds(int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < nx && y < ny && z < nz;
    }
    private int checked(int x, int y, int z) {
        if (!inBounds(x, y, z)) throw new IllegalArgumentException("cell outside grid");
        return index(x, y, z);
    }
    /** Cell type. Coordinates are cells. */
    public CellType type(int x, int y, int z) { return types[checked(x, y, z)]; }
    /** Solid/door material, null for AIR. Coordinates are cells. */
    public Material material(int x, int y, int z) { return materials[checked(x, y, z)]; }
    /** Door flag, false for non-doors. Coordinates are cells. */
    public boolean doorOpen(int x, int y, int z) { return doors[checked(x, y, z)]; }
    private void set(int x, int y, int z, CellType type, Material material, boolean open) {
        int i = checked(x, y, z);
        types[i] = type; materials[i] = material; doors[i] = open;
        if (fixed != null) fixed[i] = Double.NaN;
    }
    /** Sets an AIR cell (coordinates in cells). */
    public void setAir(int x, int y, int z) { set(x, y, z, CellType.AIR, null, false); }
    /** Sets a SOLID cell (coordinates in cells); null uses the default wall material. */
    public void setSolid(int x, int y, int z, Material material) { set(x, y, z, CellType.SOLID, material, false); }
    /** Sets a DOOR cell (coordinates in cells). */
    public void setDoor(int x, int y, int z, Material material, boolean open) {
        set(x, y, z, CellType.DOOR, material, open);
    }
    /** Changes an existing door's flag; throws for non-doors. */
    public void setDoorOpen(int x, int y, int z, boolean open) {
        int i = checked(x, y, z);
        if (types[i] != CellType.DOOR) throw new IllegalArgumentException("not a door");
        doors[i] = open;
    }
    /**
     * Fixes a SOLID cell's wall temperature, °C (M7c): every wall store holding the block keeps that temperature
     * (lava, a magma block). NaN clears it. Any later change of the cell's type or material clears it too.
     */
    public void setFixedTemperature(int x, int y, int z, double celsius) {
        int i = checked(x, y, z);
        if (!Double.isNaN(celsius) && (types[i] != CellType.SOLID || !Double.isFinite(celsius)))
            throw new IllegalArgumentException("a fixed temperature needs a SOLID cell and a finite value");
        if (fixed == null) {
            if (Double.isNaN(celsius)) return;
            fixed = new double[types.length];
            Arrays.fill(fixed, Double.NaN);
        }
        fixed[i] = celsius;
    }
    /** A cell's fixed wall temperature by index, °C, or NaN. */
    public double fixedTemperature(int index) { return fixed == null ? Double.NaN : fixed[index]; }
    /** Whether any cell has a fixed wall temperature. */
    public boolean hasFixedTemperatures() {
        if (fixed == null) return false;
        for (double t : fixed) if (!Double.isNaN(t)) return true;
        return false;
    }
    /** Fills the inclusive cuboid in cell coordinates with AIR. */
    public void fillAir(int x0, int y0, int z0, int x1, int y1, int z1) {
        for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++)
            for (int x = x0; x <= x1; x++) setAir(x, y, z);
    }
    /** Fills the inclusive cuboid in cell coordinates with SOLID. */
    public void fillSolid(int x0, int y0, int z0, int x1, int y1, int z1, Material material) {
        for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++)
            for (int x = x0; x <= x1; x++) setSolid(x, y, z, material);
    }
    /** Adds finite power in W to an in-bounds fluid cell. */
    public void addSource(int x, int y, int z, double watts) {
        int i = checked(x, y, z);
        setSource(x, y, z, sources.getOrDefault(i, 0.0) + watts);
    }
    /** Sets finite power in W in an in-bounds fluid cell; zero removes it. */
    public void setSource(int x, int y, int z, double watts) {
        int i = checked(x, y, z);
        if (!types[i].isFluid() || !Double.isFinite(watts)) throw new IllegalArgumentException("invalid source");
        if (watts == 0) sources.remove(i); else sources.put(i, watts);
    }
    /** Unmodifiable live view of cell-index to power (W), in ascending index order. */
    public Map<Integer, Double> sources() { return sourceView; }
    /** Side condition. */
    public Boundary boundary(Side side) { return boundaries[side.ordinal()]; }
    /** Speed into the domain, m/s; zero except for INFLOW. */
    public double inflowSpeed(Side side) { return speeds[side.ordinal()]; }
    /** Sets a side condition with zero inflow speed (m/s). */
    public void setBoundary(Side side, Boundary boundary) { setBoundary(side, boundary, 0); }
    /** Sets a side condition, retaining speed (m/s into domain) only for INFLOW. */
    public void setBoundary(Side side, Boundary boundary, double inflowSpeed) {
        boundaries[side.ordinal()] = boundary;
        speeds[side.ordinal()] = boundary == Boundary.INFLOW ? inflowSpeed : 0;
    }
    /** Independent deep copy of cells, source powers (W), boundaries and speeds (m/s). */
    public CellGrid3D copy() {
        CellGrid3D out = new CellGrid3D(nx, ny, nz);
        System.arraycopy(types, 0, out.types, 0, types.length);
        System.arraycopy(materials, 0, out.materials, 0, types.length);
        System.arraycopy(doors, 0, out.doors, 0, types.length);
        System.arraycopy(boundaries, 0, out.boundaries, 0, 6);
        System.arraycopy(speeds, 0, out.speeds, 0, 6);
        out.sources.putAll(sources);
        if (fixed != null) out.fixed = fixed.clone();
        return out;
    }
}
