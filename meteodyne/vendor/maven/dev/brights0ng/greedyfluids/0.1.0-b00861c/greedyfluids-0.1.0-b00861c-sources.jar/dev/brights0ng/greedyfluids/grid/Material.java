// Written by Claude.
// Edited by ChatGPT: relative volumetric heat capacity for optional wall storage (M2.5).
package dev.brights0ng.greedyfluids.grid;

/**
 * Heat-loss properties of a solid (or door) material.
 * <p>
 * A wall of {@code n} blocks between two air regions has the per-area conductance
 * {@code rhoCp / (2 * FILM_RESISTANCE + n / conductancePerBlock)} W/(m²·K), where {@code rhoCp} is the air's
 * volumetric heat capacity. This matches Meteodyne's {@code film} and {@code wallK}: stone has
 * {@code conductancePerBlock = 0.035 m/s} (relative conductivity 1), giving 41.77 W/(m²·K) for one block.
 *
 * @param name                display name
 * @param relHeatCapacity     volumetric heat capacity relative to air rhoCp, dimensionless, positive
 * @param conductancePerBlock per-block conductance in m/s, {@code 0.035 * relativeConductivity}
 */
public record Material(String name, double conductancePerBlock, double relHeatCapacity) {
    /** Existing material usage defaults to 3.5 times air volumetric heat capacity. */
    public Material(String name, double conductancePerBlock) {
        this(name, conductancePerBlock, 3.5);
    }
    /** Surface film resistance on each side of a wall, in s/m. */
    public static final double FILM_RESISTANCE = 0.15;
    /** Per-block conductance of stone (relative conductivity 1), in m/s. */
    public static final double STONE_CONDUCTANCE_PER_BLOCK = 0.035;

    public static final Material STONE = relative("stone", 1.0);
    /** Placeholder: a closed door conducts like one block of stone. */
    public static final Material DOOR = relative("door", 1.0);

    public Material {
        if (!(relHeatCapacity > 0)) {
            throw new IllegalArgumentException("relHeatCapacity must be positive: " + relHeatCapacity);
        }
        if (!(conductancePerBlock > 0)) {
            throw new IllegalArgumentException("conductancePerBlock must be positive: " + conductancePerBlock);
        }
    }

    /** A material with the given conductivity relative to stone. */
    public static Material relative(String name, double relativeConductivity) {
        return new Material(name, STONE_CONDUCTANCE_PER_BLOCK * relativeConductivity);
    }

    /** Volumetric heat capacity, J/(m³·K), for air volumetric heat capacity rhoCp in the same units. */
    public double heatCapacity(double rhoCp) {
        return relHeatCapacity * rhoCp;
    }

    /** Resistance of one block of this material, in s/m. */
    public double resistancePerBlock() {
        return 1.0 / conductancePerBlock;
    }

    /** Conductance of {@code blocks} blocks of this material, in W/(m²·K). */
    public double conductance(int blocks, double rhoCp) {
        return conductanceOfBlocks(blocks * resistancePerBlock(), rhoCp);
    }

    /**
     * Conductance of a wall whose blocks sum to {@code blockResistance} s/m (mixed materials add their per-block
     * resistances), in W/(m²·K). Both surface films are included.
     */
    public static double conductanceOfBlocks(double blockResistance, double rhoCp) {
        return rhoCp / (2 * FILM_RESISTANCE + blockResistance);
    }
}
