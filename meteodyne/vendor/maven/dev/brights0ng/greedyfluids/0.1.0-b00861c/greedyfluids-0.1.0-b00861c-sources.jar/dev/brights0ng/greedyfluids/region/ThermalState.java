// Written by Claude (M7a).
package dev.brights0ng.greedyfluids.region;

import java.util.Arrays;

/**
 * A region's temperatures by cell, °C, for saving, restoring and carrying across a recentre (M7a). air holds each
 * air cell's temperature and NaN for solid or unknown cells; solid holds each solid cell's wall temperature where a
 * wall store tracks it (the mean of the stores that contain the block) and NaN elsewhere. Both are in grid index
 * order (y·nz + z)·nx + x. Velocity is not kept: a restored region starts at rest and its flow settles within
 * seconds. Immutable: the arrays are copied in and out.
 */
public final class ThermalState {
    private final int nx, ny, nz;
    private final float[] air, solid;

    public ThermalState(int nx, int ny, int nz, float[] air, float[] solid) {
        if (nx < 1 || ny < 1 || nz < 1) throw new IllegalArgumentException("grid dimensions must be positive");
        int n = nx * ny * nz;
        if (air.length != n || solid.length != n) throw new IllegalArgumentException("expected one value per cell");
        this.nx = nx; this.ny = ny; this.nz = nz; this.air = air.clone(); this.solid = solid.clone();
    }

    /** A state that knows nothing (every cell NaN). */
    public static ThermalState unknown(int nx, int ny, int nz) {
        float[] a = new float[nx * ny * nz];
        Arrays.fill(a, Float.NaN);
        return new ThermalState(nx, ny, nz, a, a);
    }

    public int nx() { return nx; }
    public int ny() { return ny; }
    public int nz() { return nz; }
    /** Air temperature of a cell by grid index, °C, or NaN. */
    public float air(int index) { return air[index]; }
    /** Wall temperature of a solid cell by grid index, °C, or NaN. */
    public float solid(int index) { return solid[index]; }
    /** Copy of the air temperatures. */
    public float[] airArray() { return air.clone(); }
    /** Copy of the wall temperatures. */
    public float[] solidArray() { return solid.clone(); }

    /**
     * This state seen from a window of size (nx, ny, nz) whose low corner sits at (dx, dy, dz) in this state's
     * cells: cells inside both windows keep their values, the rest are NaN. For v1 recentring, the new window is
     * the old one moved by (dx, dy, dz).
     */
    public ThermalState moved(int dx, int dy, int dz, int nx, int ny, int nz) {
        float[] a = new float[nx * ny * nz], s = new float[a.length];
        Arrays.fill(a, Float.NaN); Arrays.fill(s, Float.NaN);
        for (int y = 0; y < ny; y++) {
            int oy = y + dy;
            if (oy < 0 || oy >= this.ny) continue;
            for (int z = 0; z < nz; z++) {
                int oz = z + dz;
                if (oz < 0 || oz >= this.nz) continue;
                for (int x = 0; x < nx; x++) {
                    int ox = x + dx;
                    if (ox < 0 || ox >= this.nx) continue;
                    int to = (y * nz + z) * nx + x, from = (oy * this.nz + oz) * this.nx + ox;
                    a[to] = air[from]; s[to] = solid[from];
                }
            }
        }
        return new ThermalState(nx, ny, nz, a, s);
    }
}
