// Written by ChatGPT from Claude's M5c spec.
// Edited by ChatGPT from Claude's M5d spec.
// Edited by Claude: local remeshing around fixed old boxes (M5e2).
// Edited by Claude: no growth or merge across a roofed/open-sky change on INFLOW side walls (M6b1).
// Edited by Claude: worklist grading, bitwise identical to the full-scan passes (M6c1).
// Edited by Claude: the fixed-box grading check visits only fixed boxes touching new boxes; local rounds reuse
//   unaffected sections' greedy and merge results (M6c1).
// Edited by Claude: report-only single-round local remeshing (M6c2).
package dev.brights0ng.greedyfluids.mesh;

import dev.brights0ng.greedyfluids.grid.CellGrid3D;
import dev.brights0ng.greedyfluids.grid.CellType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

/**
 * Static greedy cuboids, numbered by ascending (y, z, x).
 * <ul>
 * <li>Only AIR outside keep-fine is mergeable; DOOR and keep-fine fluid cells stay 1×1×1.</li>
 * <li>No box crosses a 16-cell section line; extents are at most 16 and max/min aspect at most 4.</li>
 * <li>Bottom-up seeds scan y, z, x. Grow x, then z (at most 4 sx), then y
 * (at most 4 min(sx, sz)); trim x and z to 4 times the smallest extent.</li>
 * <li>Before grading, repeatedly merge matching high faces in y, x, z order, in creation order,
 * preserving section, extent and three-axis aspect limits.</li>
 * <li>Grade to a fixed point in creation order, visiting appended boxes immediately. Split aspect
 * first (largest axis, ties x, y, z), then neighbours on x, y, z faces, low before high,
 * with cyclic tangential traversal. Compare all three extents, x first. Split at the integer
 * midpoint, keeping the low floor(n/2) half. Boxes only shrink during grading. Passes visit only boxes whose
 * face neighbourhood changed since they last passed; the result is identical to visiting every box.</li>
 * </ul>
 * Local remeshing ({@link #boxesLocal}) keeps every old box that contains no dirty cell, runs the same greedy,
 * merge and grading passes on the remaining fluid cells (fixed boxes never merge or split), and rebuilds any
 * fixed box that a new neighbour leaves out of grading, repeating until none does.
 */
public final class GreedyMesher3D {
    /** Section size, cells. */
    public static final int SECTION = 16;
    /** Largest extent, cells. */
    public static final int MAX_EXTENT = 16;
    /** Largest three-axis aspect ratio, dimensionless. */
    public static final int MAX_ASPECT = 4;
    /** Default all-axes neighbour grading ratio, dimensionless. */
    public static final int DEFAULT_GRADING = 2;

    private GreedyMesher3D() { }

    private static volatile boolean referenceMeshing;
    /**
     * Tests and benches only: mesh with the pre-M6c1 reference algorithms (full-scan grading passes; every fixed
     * box re-checked; whole-domain greedy and merge in every local round). They give identical meshes; the
     * reference is kept as the identity oracle. Process-wide.
     */
    public static void setReferenceMeshingForTesting(boolean on) { referenceMeshing = on; }

    /** Final starts/extents in cells, sorted (y0, z0, x0), with pass counts. */
    public record Boxes(int[] x0, int[] y0, int[] z0, int[] sx, int[] sy, int[] sz,
                        int greedyBoxes, int mergedBoxes, int splits) { }

    /** Builds static boxes; gradingRatio must be at least one. */
    public static Boxes boxes(CellGrid3D grid, boolean[] keepFine, int gradingRatio) {
        return boxes(grid, keepFine, gradingRatio, null);
    }

    /** Constrained growth and merge; grading only splits and does not consult the constraint. */
    public static Boxes boxes(CellGrid3D grid, boolean[] keepFine, int gradingRatio, MeshConstraint3D c) {
        if (keepFine.length != grid.nx() * grid.ny() * grid.nz() || gradingRatio < 1)
            throw new IllegalArgumentException("invalid keep-fine length or grading ratio");
        State s = new State(grid, keepFine, c);
        s.greedy();
        int greedy = s.boxes.size();
        int merged = greedy - s.merge();
        int splits = s.grade(gradingRatio);
        return sorted(s, greedy, merged, splits);
    }

    /**
     * Local constrained remesh: old boxes containing no dirty cell are kept as they are; the rest of the fluid is
     * meshed as by {@link #boxes}, then fixed boxes that break grading against new boxes join the rebuild and the
     * round repeats. localStats, if non-null, receives {rounds, rebuilt old boxes, kept old boxes}.
     */
    public static Boxes boxesLocal(CellGrid3D grid, boolean[] keepFine, int gradingRatio, MeshConstraint3D c,
            BoxGraph3D old, boolean[] dirty, int[] localStats) {
        return boxesLocal(grid, keepFine, gradingRatio, c, old, dirty, localStats, false);
    }

    /**
     * As above. singleRound (report-only, M6c2): a fixed box that breaks grading against the new boxes is not
     * freed for a restarted round; it stops being fixed and grading splits it in place, in the same round. The
     * mesh obeys the same rules but differs from the restarted one. localStats[0] then counts check passes.
     */
    public static Boxes boxesLocal(CellGrid3D grid, boolean[] keepFine, int gradingRatio, MeshConstraint3D c,
            BoxGraph3D old, boolean[] dirty, int[] localStats, boolean singleRound) {
        int cells = grid.nx() * grid.ny() * grid.nz();
        if (keepFine.length != cells || dirty.length != cells || gradingRatio < 1)
            throw new IllegalArgumentException("invalid keep-fine or dirty length, or grading ratio");
        boolean[] rebuild = new boolean[old.boxCount()];
        for (int i = 0; i < cells; i++) if (dirty[i]) {
            int x = i % grid.nx(), z = (i / grid.nx()) % grid.nz(), y = i / (grid.nx() * grid.nz());
            int ob = old.boxOfCell(x, y, z);
            if (ob >= 0) rebuild[ob] = true;
        }
        // Greedy growth and merges never cross a section line and only read their own section's cells, so a
        // section's greedy+merge result depends only on which of its cells fixed boxes own. It is cached per section
        // and recomputed only in sections where a round freed an old box (old boxes lie within one section).
        int ns = SECTION, secX = (grid.nx() + ns - 1) / ns, secY = (grid.ny() + ns - 1) / ns, secZ = (grid.nz() + ns - 1) / ns;
        int sections = secX * secY * secZ;
        boolean[] sectionStale = new boolean[sections];
        Arrays.fill(sectionStale, true);
        @SuppressWarnings("unchecked") ArrayList<Box>[] cached = new ArrayList[sections];
        int[] cachedGreedy = new int[sections], cachedMerges = new int[sections];
        for (int rounds = 1; ; rounds++) {
            State s = new State(grid, keepFine, c);
            int[] fixedOld = new int[old.boxCount()];
            for (int ob = 0; ob < old.boxCount(); ob++) if (!rebuild[ob]) {
                fixedOld[s.boxes.size()] = ob;
                s.boxes.add(new Box(new int[]{old.boxX0(ob), old.boxY0(ob), old.boxZ0(ob)},
                        new int[]{old.boxSx(ob), old.boxSy(ob), old.boxSz(ob)}, false, true));
                s.paint(s.boxes.size() - 1);
            }
            int fixed = s.boxes.size();
            int greedy, merged;
            if (referenceMeshing) {
                s.greedy();
                greedy = s.boxes.size() - fixed;
                merged = greedy - s.merge();
            } else {
                int created = 0, merges = 0;
                for (int sec = 0; sec < sections; sec++) {
                    if (sectionStale[sec]) {
                        int from = s.boxes.size();
                        s.greedySection((sec % secX) * ns, (sec / (secX * secZ)) * ns, (sec / secX % secZ) * ns);
                        cachedGreedy[sec] = s.boxes.size() - from;
                        cachedMerges[sec] = s.mergeRange(from, s.boxes.size());
                        ArrayList<Box> live = new ArrayList<>();
                        for (int i = from; i < s.boxes.size(); i++) if (s.boxes.get(i).alive) live.add(s.boxes.get(i).copy());
                        cached[sec] = live; sectionStale[sec] = false;
                    } else {
                        for (Box b : cached[sec]) { s.boxes.add(b.copy()); s.paint(s.boxes.size() - 1); }
                    }
                    created += cachedGreedy[sec]; merges += cachedMerges[sec];
                }
                s.creationOrder(fixed);
                greedy = created; merged = created - merges;
            }
            int splits = s.grade(gradingRatio);
            if (singleRound) {
                int passes = 1, unfixed = 0;
                java.util.BitSet check;
                if (s.boxes.size() - fixed >= fixed) { check = new java.util.BitSet(fixed); check.set(0, fixed); }
                else check = s.fixedFaceNeighbours(fixed);
                s.touchedFixed = new java.util.BitSet(fixed);
                while (true) {
                    boolean any = false;
                    for (int i = check.nextSetBit(0); i >= 0; i = check.nextSetBit(i + 1)) {
                        Box f = s.boxes.get(i);
                        if (!f.fixed || s.splitAxis(f, gradingRatio) < 0) continue;
                        f.fixed = false; s.stale.set(i); rebuild[fixedOld[i]] = true; unfixed++; any = true;
                    }
                    if (!any) break;
                    s.touchedFixed.clear();
                    splits += s.gradeStale(gradingRatio);
                    check = (java.util.BitSet) s.touchedFixed.clone();
                    passes++;
                }
                if (localStats != null) {
                    localStats[0] = passes; localStats[1] = old.boxCount() - fixed + unfixed; localStats[2] = fixed - unfixed;
                }
                return sorted(s, greedy, merged, splits);
            }
            // Fixed boxes are old boxes, so fixed–fixed pairs already meet grading and aspect; only fixed boxes
            // face-adjacent to a new box can fail. Finding those scans the new boxes' faces, so it is used only when
            // new boxes are fewer than fixed ones (edits); otherwise every fixed box is checked (wind). Exact both ways.
            boolean expanded = false;
            java.util.BitSet touched;
            if (referenceMeshing || s.boxes.size() - fixed >= fixed) { touched = new java.util.BitSet(fixed); touched.set(0, fixed); }
            else touched = s.fixedFaceNeighbours(fixed);
            for (int i = touched.nextSetBit(0); i >= 0; i = touched.nextSetBit(i + 1))
                if (s.splitAxis(s.boxes.get(i), gradingRatio) >= 0) {
                    rebuild[fixedOld[i]] = true; expanded = true;
                    Box f = s.boxes.get(i);
                    sectionStale[(f.p[1] / ns * secZ + f.p[2] / ns) * secX + f.p[0] / ns] = true;
                }
            if (expanded) continue;
            if (localStats != null) {
                localStats[0] = rounds; localStats[1] = old.boxCount() - fixed; localStats[2] = fixed;
            }
            return sorted(s, greedy, merged, splits);
        }
    }

    /** Local constrained mesh as a graph, with rhoCp in J/(m³·K). */
    public static BoxGraph3D meshLocal(CellGrid3D grid, boolean[] keepFine, int gradingRatio, MeshConstraint3D c,
            double rhoCp, BoxGraph3D old, boolean[] dirty, int[] localStats) {
        return meshLocal(grid, keepFine, gradingRatio, c, rhoCp, old, dirty, localStats, false);
    }
    /** As above, optionally single-round (report-only, M6c2; see boxesLocal). */
    public static BoxGraph3D meshLocal(CellGrid3D grid, boolean[] keepFine, int gradingRatio, MeshConstraint3D c,
            double rhoCp, BoxGraph3D old, boolean[] dirty, int[] localStats, boolean singleRound) {
        Boxes b = boxesLocal(grid, keepFine, gradingRatio, c, old, dirty, localStats, singleRound);
        return BoxGraph3D.build(grid, b.x0, b.y0, b.z0, b.sx, b.sy, b.sz, rhoCp);
    }

    /**
     * Counts mesh-rule violations in a graph: per box, an extent over 16, a max/min aspect over 4, or crossing a
     * section line on any axis; per face, any of the three extents differing by more than gradingRatio. 0 for
     * every mesh this class builds.
     */
    public static int violations(BoxGraph3D g, int gradingRatio) {
        int v = 0;
        for (int b = 0; b < g.boxCount(); b++) {
            int[] p = {g.boxX0(b), g.boxY0(b), g.boxZ0(b)}, n = {g.boxSx(b), g.boxSy(b), g.boxSz(b)};
            int mn = Math.min(n[0], Math.min(n[1], n[2])), mx = Math.max(n[0], Math.max(n[1], n[2]));
            if (mx > MAX_EXTENT || mx > MAX_ASPECT * mn) v++;
            for (int a = 0; a < 3; a++) if (p[a] / SECTION != (p[a] + n[a] - 1) / SECTION) v++;
        }
        for (int f = 0; f < g.faceCount(); f++) {
            int a = g.faceA(f), b = g.faceB(f);
            int[] na = {g.boxSx(a), g.boxSy(a), g.boxSz(a)}, nb = {g.boxSx(b), g.boxSy(b), g.boxSz(b)};
            for (int k = 0; k < 3; k++)
                if (na[k] > (long) gradingRatio * nb[k] || nb[k] > (long) gradingRatio * na[k]) { v++; break; }
        }
        return v;
    }

    private static Boxes sorted(State s, int greedy, int merged, int splits) {
        var live = s.boxes.stream().filter(b -> b.alive).sorted(Comparator
                .comparingInt((Box b) -> b.p[1]).thenComparingInt(b -> b.p[2])
                .thenComparingInt(b -> b.p[0])).toList();
        int[][] p = new int[3][live.size()], n = new int[3][live.size()];
        for (int i = 0; i < live.size(); i++) for (int a = 0; a < 3; a++) {
            p[a][i] = live.get(i).p[a]; n[a][i] = live.get(i).n[a];
        }
        return new Boxes(p[0], p[1], p[2], n[0], n[1], n[2], greedy, merged, splits);
    }

    /** Builds the graph using rhoCp in J/(m³·K). */
    public static BoxGraph3D mesh(CellGrid3D grid, boolean[] keepFine, int gradingRatio, double rhoCp) {
        return mesh(grid, keepFine, gradingRatio, null, rhoCp);
    }

    /** Constrained mesh, with rhoCp in J/(m³·K). */
    public static BoxGraph3D mesh(CellGrid3D grid, boolean[] keepFine, int gradingRatio,
            MeshConstraint3D c, double rhoCp) {
        Boxes b = boxes(grid, keepFine, gradingRatio, c);
        return BoxGraph3D.build(grid, b.x0, b.y0, b.z0, b.sx, b.sy, b.sz, rhoCp);
    }

    /** Static keep-fine and default grading, with rhoCp in J/(m³·K). */
    public static BoxGraph3D mesh(CellGrid3D grid, double rhoCp) {
        return mesh(grid, StaticRefinement3D.keepFine(grid), DEFAULT_GRADING, rhoCp);
    }

    private static final class Box {
        final int[] p, n;
        final boolean mergeable;
        /** Kept old box; only single-round local remeshing (M6c2) clears it. */
        boolean fixed;
        boolean alive = true;
        Box(int[] p, int[] n, boolean mergeable) { this(p, n, mergeable, false); }
        Box(int[] p, int[] n, boolean mergeable, boolean fixed) {
            this.p = p; this.n = n; this.mergeable = mergeable; this.fixed = fixed;
        }
        /** A live copy with its own coordinate arrays. */
        Box copy() { return new Box(p.clone(), n.clone(), mergeable, fixed); }
    }

    private static final class State {
        final CellGrid3D grid;
        final boolean[] fine;
        final MeshConstraint3D constraint;
        final int[] owner, dims, roofTops;
        final ArrayList<Box> boxes = new ArrayList<>();
        State(CellGrid3D grid, boolean[] fine, MeshConstraint3D constraint) {
            this.grid = grid; this.fine = fine; this.constraint = constraint;
            roofTops = InflowExposure3D.roofTops(grid);
            dims = new int[]{grid.nx(), grid.ny(), grid.nz()};
            owner = new int[fine.length];
            Arrays.fill(owner, -1);
        }
        int owner(int x, int y, int z) {
            return grid.inBounds(x, y, z) ? owner[grid.index(x, y, z)] : -1;
        }
        boolean free(int x, int y, int z) {
            int c = grid.index(x, y, z);
            return owner[c] < 0 && grid.type(x, y, z) == CellType.AIR && !fine[c];
        }
        boolean slabFree(int[] p, int[] n, int a) {
            int u = (a+1)%3, v = (a+2)%3;
            int[] c = p.clone();
            c[a] += n[a];
            for (c[u] = p[u]; c[u] < p[u]+n[u]; c[u]++)
                for (c[v] = p[v]; c[v] < p[v]+n[v]; c[v]++)
                    if (!free(c[0], c[1], c[2])) return false;
            return true;
        }
        void paint(int i) {
            Box b = boxes.get(i);
            for (int y = b.p[1]; y < b.p[1]+b.n[1]; y++)
                for (int z = b.p[2]; z < b.p[2]+b.n[2]; z++)
                    Arrays.fill(owner, grid.index(b.p[0], y, z), grid.index(b.p[0]+b.n[0], y, z), i);
        }
        void add(int[] p, int[] n, boolean mergeable) {
            boxes.add(new Box(p, n, mergeable));
            paint(boxes.size()-1);
        }
        void greedy() {
            for (int y = 0; y < dims[1]; y++) for (int z = 0; z < dims[2]; z++)
                for (int x = 0; x < dims[0]; x++) seed(x, y, z);
        }
        /** Greedy over one section (low corner in cells), in the same y, z, x scan order. */
        void greedySection(int x0, int y0, int z0) {
            int x1 = Math.min(dims[0], x0 + SECTION), y1 = Math.min(dims[1], y0 + SECTION), z1 = Math.min(dims[2], z0 + SECTION);
            for (int y = y0; y < y1; y++) for (int z = z0; z < z1; z++)
                for (int x = x0; x < x1; x++) seed(x, y, z);
        }
        private void seed(int x, int y, int z) {
            if (owner(x,y,z) >= 0 || !grid.type(x,y,z).isFluid()) return;
            int[] p = {x,y,z}, n = {1,1,1};
            boolean mergeable = free(x,y,z);
            if (mergeable) {
                grow(p,n,0,MAX_EXTENT);
                grow(p,n,2,MAX_ASPECT*n[0]);
                grow(p,n,1,MAX_ASPECT*Math.min(n[0],n[2]));
                int m = Math.min(n[0],Math.min(n[1],n[2]));
                n[0] = Math.min(n[0],MAX_ASPECT*m);
                n[2] = Math.min(n[2],MAX_ASPECT*m);
            }
            add(p,n,mergeable);
        }
        /**
         * Drops dead boxes from index fixed on and puts the rest in whole-domain greedy creation order: ascending
         * seed (y, z, x). Greedy boxes keep their seed as low corner through growth and merges, so this is the
         * relative order a whole-domain greedy and merge would leave them in.
         */
        void creationOrder(int fixed) {
            ArrayList<Box> live = new ArrayList<>(boxes.size() - fixed);
            for (int i = fixed; i < boxes.size(); i++) if (boxes.get(i).alive) live.add(boxes.get(i));
            live.sort(Comparator.comparingInt((Box b) -> b.p[1]).thenComparingInt(b -> b.p[2]).thenComparingInt(b -> b.p[0]));
            boxes.subList(fixed, boxes.size()).clear();
            for (Box b : live) { boxes.add(b); paint(boxes.size() - 1); }
        }
        void grow(int[] p, int[] n, int a, int cap) {
            int limit = Math.min(dims[a], Math.min((p[a]/SECTION+1)*SECTION, p[a]+MAX_EXTENT));
            while (n[a] < cap && p[a]+n[a] < limit && slabFree(p,n,a)) {
                n[a]++;
                if (!allows(p,n)) { n[a]--; break; }
            }
        }
        boolean allows(int[] p, int[] n) {
            if (!InflowExposure3D.uniform(roofTops, grid, p[0], p[1], p[2], n[0], n[2])) return false;
            return constraint == null || constraint.allows(p[0],p[1],p[2],n[0],n[1],n[2]);
        }
        int merge() { return mergeRange(0, boxes.size()); }
        /** Merge passes over boxes [from, to) only; exact for one section's boxes, as merges stay in a section. */
        int mergeRange(int from, int to) {
            int total = 0;
            boolean changed;
            do {
                changed = false;
                for (int i = from; i < to; i++) {
                    Box b = boxes.get(i);
                    if (!b.alive || !b.mergeable) continue;
                    for (int a : new int[]{1,0,2}) {
                        int x = b.p[0]+(a==0 ? b.n[0] : 0);
                        int y = b.p[1]+(a==1 ? b.n[1] : 0);
                        int z = b.p[2]+(a==2 ? b.n[2] : 0);
                        int j = owner(x,y,z);
                        if (j < 0) continue;
                        Box c = boxes.get(j);
                        if (!c.alive || !c.mergeable || c.p[a] != b.p[a]+b.n[a]) continue;
                        int u = (a+1)%3, v = (a+2)%3;
                        if (b.p[u]!=c.p[u] || b.p[v]!=c.p[v] || b.n[u]!=c.n[u] || b.n[v]!=c.n[v]) continue;
                        int sum = b.n[a]+c.n[a];
                        if (sum > MAX_EXTENT || b.p[a]/SECTION != (c.p[a]+c.n[a]-1)/SECTION) continue;
                        if (Math.max(sum,Math.max(b.n[u],b.n[v]))
                                > MAX_ASPECT*Math.min(sum,Math.min(b.n[u],b.n[v]))) continue;
                        int before = b.n[a];
                        b.n[a] = sum;
                        if (!allows(b.p,b.n)) { b.n[a] = before; continue; }
                        c.alive = false;
                        paint(i); total++; changed = true;
                    }
                }
            } while (changed);
            return total;
        }
        /**
         * Grades to a fixed point with the full-scan passes' visit order, skipping boxes that would pass again.
         * splitAxis(b) reads only b and the boxes owning b's face-adjacent cells. Grading never merges, so those
         * only change when a box splits (it shrinks and its new half takes over cells). A box whose face-adjacent
         * owners have not split since splitAxis last returned −1 for it returns −1 again, so skipping it is exact.
         * Stale boxes are visited in index order: one marked above the cursor is visited in this pass, one marked
         * below it in the next, as in the full scan (Claude, M6c1; reference: {@link #gradeFullScan}).
         */
        int grade(int ratio) {
            if (referenceMeshing) return gradeFullScan(ratio);
            stale.clear();
            for (int i = 0; i < boxes.size(); i++) if (boxes.get(i).alive && !boxes.get(i).fixed) stale.set(i);
            return gradeStale(ratio);
        }
        /** Continues worklist grading from the current stale set (single-round local remeshing, M6c2). */
        int gradeStale(int ratio) {
            int splits = 0;
            while (!stale.isEmpty()) {
                for (int i = stale.nextSetBit(0); i >= 0; i = stale.nextSetBit(i + 1)) {
                    stale.clear(i);
                    Box b = boxes.get(i);
                    int a;
                    while ((a = splitAxis(b,ratio)) >= 0) {
                        System.arraycopy(b.p, 0, shellP, 0, 3); System.arraycopy(b.n, 0, shellN, 0, 3);
                        int[] p = b.p.clone(), n = b.n.clone();
                        b.n[a] /= 2;
                        p[a] += b.n[a]; n[a] -= b.n[a];
                        add(p,n,b.mergeable);
                        stale.set(boxes.size() - 1);
                        markFaceShell(shellP, shellN, i);
                        splits++;
                    }
                }
            }
            return splits;
        }
        private final java.util.BitSet stale = new java.util.BitSet();
        /** Single-round local remeshing only: fixed boxes next to a split since the last check, else null. */
        java.util.BitSet touchedFixed;
        private final int[] shellP = new int[3], shellN = new int[3], shellCell = new int[3];
        /** Marks the non-fixed owners of the cells face-adjacent to a cuboid (cells), except box self. */
        private void markFaceShell(int[] p, int[] n, int self) {
            int[] c = shellCell;
            for (int a = 0; a < 3; a++) {
                int u = (a+1)%3, v = (a+2)%3;
                for (int side = 0; side < 2; side++) {
                    c[a] = p[a] + (side == 0 ? -1 : n[a]);
                    if (c[a] < 0 || c[a] >= dims[a]) continue;
                    for (c[u] = p[u]; c[u] < p[u]+n[u]; c[u]++)
                        for (c[v] = p[v]; c[v] < p[v]+n[v]; c[v]++) {
                            int j = owner[grid.index(c[0], c[1], c[2])];
                            if (j < 0 || j == self) continue;
                            if (!boxes.get(j).fixed) stale.set(j);
                            else if (touchedFixed != null) touchedFixed.set(j);
                        }
                }
            }
        }
        /** Fixed boxes (indices below fixed) face-adjacent to a live non-fixed box. */
        java.util.BitSet fixedFaceNeighbours(int fixed) {
            java.util.BitSet out = new java.util.BitSet(fixed);
            int[] c = shellCell;
            for (int i = fixed; i < boxes.size(); i++) {
                Box b = boxes.get(i);
                if (!b.alive) continue;
                for (int a = 0; a < 3; a++) {
                    int u = (a+1)%3, v = (a+2)%3;
                    for (int side = 0; side < 2; side++) {
                        c[a] = b.p[a] + (side == 0 ? -1 : b.n[a]);
                        if (c[a] < 0 || c[a] >= dims[a]) continue;
                        for (c[u] = b.p[u]; c[u] < b.p[u]+b.n[u]; c[u]++)
                            for (c[v] = b.p[v]; c[v] < b.p[v]+b.n[v]; c[v]++) {
                                int j = owner[grid.index(c[0], c[1], c[2])];
                                if (j >= 0 && j < fixed) out.set(j);
                            }
                    }
                }
            }
            return out;
        }
        /** Reference grading: full passes over every box until a pass splits nothing (M4–M6b behaviour). */
        int gradeFullScan(int ratio) {
            int splits = 0;
            boolean changed;
            do {
                changed = false;
                for (int i = 0; i < boxes.size(); i++) {
                    Box b = boxes.get(i);
                    if (!b.alive || b.fixed) continue;
                    int a;
                    while ((a = splitAxis(b,ratio)) >= 0) {
                        int[] p = b.p.clone(), n = b.n.clone();
                        b.n[a] /= 2;
                        p[a] += b.n[a]; n[a] -= b.n[a];
                        add(p,n,b.mergeable);
                        splits++; changed = true;
                    }
                }
            } while (changed);
            return splits;
        }
        int splitAxis(Box b, int ratio) {
            int largest = 0;
            for (int a = 1; a < 3; a++) if (b.n[a] > b.n[largest]) largest = a;
            if (b.n[largest] > MAX_ASPECT*Math.min(b.n[0],Math.min(b.n[1],b.n[2]))) return largest;
            int[] c = b.p.clone();
            for (int a = 0; a < 3; a++) {
                int u = (a+1)%3, v = (a+2)%3;
                for (int side = 0; side < 2; side++) {
                    c[a] = b.p[a]+(side==0 ? -1 : b.n[a]);
                    for (c[u] = b.p[u]; c[u] < b.p[u]+b.n[u]; c[u]++)
                        for (c[v] = b.p[v]; c[v] < b.p[v]+b.n[v]; c[v]++) {
                            int j = owner(c[0],c[1],c[2]);
                            if (j < 0) continue;
                            for (int axis = 0; axis < 3; axis++)
                                if (b.n[axis] > (long)ratio*boxes.get(j).n[axis]) return axis;
                        }
                }
            }
            return -1;
        }
    }
}
