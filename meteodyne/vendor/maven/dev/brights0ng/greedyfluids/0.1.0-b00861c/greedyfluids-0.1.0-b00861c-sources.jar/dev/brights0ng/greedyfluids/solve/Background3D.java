// Written by Claude (M7a).
// Edited by Claude: per-cell follow weights for the weather shift (M7a).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;

/**
 * Background temperature, °C, per grid cell (M7; Bright, 2026-11-13): the temperature the air and walls would have
 * with no sources, edits or local flow. The host supplies it, for example the weather temperature where a cell is
 * open to the sky and the underground temperature at depth. It replaces the single SolverConfig3D.ambientT
 * wherever the solver compared with or relaxed toward ambient:
 * <ul>
 *   <li>buoyancy: a face's buoyant force is relative to the mean background of its two boxes;</li>
 *   <li>open boundaries: eddy exchange and inflow at the boundary box's background;</li>
 *   <li>wall stores of kind AMBIENT: the far side at the background of the ray's last solid cell;</li>
 *   <li>samples in solid or outside the grid, and the initial temperature of a mesh with none given;</li>
 *   <li>D3's thermal velocity gate and its velocity hold's flow test (AdaptiveMesh3D).</li>
 * </ul>
 * SolverConfig3D.ambientT stays the reference of the expansion coefficient 1/(T + 273.15).
 *
 * <p><b>Follow weights</b> (0–1 per cell, 0 when not given): how much a cell's air follows a change of its
 * background (Bright, 2026-11-13). 1 for air open to the sky, because outdoor air is the weather; 0 indoors and
 * underground, where walls buffer the change and the air catches up only through walls and openings. When a mesh
 * changes its background, each box moves by the mean of follow × (new − old background) over its cells, keeping
 * its departure from the background (a plume stays a plume); the new field's weights are used.
 *
 * <p>Immutable. Values are held as float offsets from a double reference, so a uniform field gives every box and
 * cell exactly the reference value, and a field built from a constant array matches {@link #uniform} bit for bit.
 * A box's background is the mean over its cells, from summed offsets (O(1) per box).
 */
public final class Background3D {
    private final int nx, ny, nz;
    private final double reference;
    private final float[] offset;
    private final double[] sums;
    private final float[] follow;

    private Background3D(int nx, int ny, int nz, double reference, float[] offset, double[] sums, float[] follow) {
        this.nx = nx; this.ny = ny; this.nz = nz; this.reference = reference; this.offset = offset; this.sums = sums;
        this.follow = follow;
    }

    /** One temperature, °C, for every cell of an nx×ny×nz grid. */
    public static Background3D uniform(int nx, int ny, int nz, double celsius) {
        check(nx, ny, nz);
        if (!Double.isFinite(celsius)) throw new IllegalArgumentException("background must be finite");
        return new Background3D(nx, ny, nz, celsius, null, null, null);
    }

    /**
     * A per-cell field, °C, in grid index order (y·nz + z)·nx + x; the array is copied. The reference is the first
     * cell's value; a constant array gives a uniform field.
     */
    public static Background3D of(int nx, int ny, int nz, float[] celsius) {
        check(nx, ny, nz);
        if (celsius.length != nx * ny * nz) throw new IllegalArgumentException("expected one value per cell");
        double ref = celsius[0];
        boolean flat = true;
        for (float t : celsius) {
            if (!Float.isFinite(t)) throw new IllegalArgumentException("background must be finite");
            if (t != celsius[0]) flat = false;
        }
        if (flat) return new Background3D(nx, ny, nz, ref, null, null, null);
        float[] off = new float[celsius.length];
        for (int i = 0; i < off.length; i++) off[i] = (float) (celsius[i] - ref);
        int px = nx + 1, pz = nz + 1;
        double[] s = new double[px * (ny + 1) * pz];
        for (int y = 0; y < ny; y++) for (int z = 0; z < nz; z++) for (int x = 0; x < nx; x++) {
            int p = ((y + 1) * pz + (z + 1)) * px + (x + 1);
            s[p] = off[(y * nz + z) * nx + x]
                    + s[p - 1] + s[p - px] + s[p - px * pz]
                    - s[p - 1 - px] - s[p - 1 - px * pz] - s[p - px - px * pz]
                    + s[p - 1 - px - px * pz];
        }
        return new Background3D(nx, ny, nz, ref, off, s, null);
    }

    /** A per-cell field with follow weights (0–1 per cell, grid index order); both arrays are copied. */
    public static Background3D of(int nx, int ny, int nz, float[] celsius, float[] follow) {
        return of(nx, ny, nz, celsius).withFollow(follow);
    }

    /** This field with follow weights (0–1 per cell, grid index order; copied), or none for null. */
    public Background3D withFollow(float[] weights) {
        if (weights == null) return new Background3D(nx, ny, nz, reference, offset, sums, null);
        if (weights.length != nx * ny * nz) throw new IllegalArgumentException("expected one follow weight per cell");
        for (float w : weights) if (!(w >= 0 && w <= 1)) throw new IllegalArgumentException("follow weights must be in [0, 1]");
        return new Background3D(nx, ny, nz, reference, offset, sums, weights.clone());
    }

    /** Whether any follow weights are set. */
    public boolean follows() { return follow != null; }

    /** Follow weight of a cell by grid index, 0–1. */
    public double follow(int index) { return follow == null ? 0 : follow[index]; }

    private static void check(int nx, int ny, int nz) {
        if (nx < 1 || ny < 1 || nz < 1) throw new IllegalArgumentException("grid dimensions must be positive");
    }

    /** Grid size along x, cells. */
    public int nx() { return nx; }
    /** Grid size along y, cells. */
    public int ny() { return ny; }
    /** Grid size along z, cells. */
    public int nz() { return nz; }
    /** Whether every cell has the reference value. */
    public boolean isUniform() { return offset == null; }
    /** Reference temperature, °C: the uniform value, or the first cell's. */
    public double reference() { return reference; }
    /** Whether this field is for an nx×ny×nz grid. */
    public boolean fits(int nx, int ny, int nz) { return this.nx == nx && this.ny == ny && this.nz == nz; }

    /** Background of a cell by grid index, °C. */
    public double cell(int index) { return offset == null ? reference : reference + offset[index]; }

    /** Background of cell (x, y, z), °C; the reference outside the grid. */
    public double at(int x, int y, int z) {
        if (x < 0 || y < 0 || z < 0 || x >= nx || y >= ny || z >= nz) return reference;
        return cell((y * nz + z) * nx + x);
    }

    /** Mean background over the cells of box b, °C. */
    public double box(BoxGraph3D g, int b) {
        if (offset == null) return reference;
        int x0 = g.boxX0(b), y0 = g.boxY0(b), z0 = g.boxZ0(b);
        int x1 = x0 + g.boxSx(b), y1 = y0 + g.boxSy(b), z1 = z0 + g.boxSz(b);
        double sum = s(x1, y1, z1) - s(x0, y1, z1) - s(x1, y0, z1) - s(x1, y1, z0)
                + s(x0, y0, z1) + s(x0, y1, z0) + s(x1, y0, z0) - s(x0, y0, z0);
        return reference + sum / ((double) g.boxSx(b) * g.boxSy(b) * g.boxSz(b));
    }

    /** Fills out[b] with each box's mean background, °C. */
    public void boxes(BoxGraph3D g, double[] out) {
        if (out.length != g.boxCount()) throw new IllegalArgumentException("expected one value per box");
        for (int b = 0; b < out.length; b++) out[b] = box(g, b);
    }

    private double s(int x, int y, int z) { return sums[(y * (nz + 1) + z) * (nx + 1) + x]; }
}
