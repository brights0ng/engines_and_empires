// Written by Claude (M5e1).
package dev.brights0ng.greedyfluids.grid;

import java.util.Objects;

/** One 1 m cell AIR/SOLID edit, validated against the pre-batch grid by GridEdits3D. */
public record CellEdit3D(int x, int y, int z, Kind kind, Material material) {
    /** PLACE turns AIR into SOLID; BREAK turns SOLID into AIR. Door blocks are not edited in M5. */
    public enum Kind { PLACE, BREAK }

    public CellEdit3D {
        Objects.requireNonNull(kind, "kind");
        if (kind == Kind.PLACE) Objects.requireNonNull(material, "PLACE material");
        else if (material != null) throw new IllegalArgumentException("BREAK material must be null");
    }

    public static CellEdit3D place(int x, int y, int z, Material material) {
        return new CellEdit3D(x, y, z, Kind.PLACE, material);
    }

    public static CellEdit3D breakBlock(int x, int y, int z) {
        return new CellEdit3D(x, y, z, Kind.BREAK, null);
    }
}
