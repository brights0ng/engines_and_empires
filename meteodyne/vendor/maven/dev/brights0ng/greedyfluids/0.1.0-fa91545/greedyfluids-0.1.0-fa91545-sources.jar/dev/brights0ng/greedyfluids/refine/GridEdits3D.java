// Written by Claude (M5e1); rules ported from GridEdits (written by ChatGPT; model decided by Bright,
// mechanics specified by Claude).
// Edited by Claude: caller-supplied remap projection (M5e2).
// Edited by Claude: optional local rasterisation (M6c3).
// Edited by Claude: solid distances updated locally on rebuild (M6d2).
// Edited by Claude: optional local wall-store rebuild and per-block tracked heat (M6e2).
// Edited by Claude: the replacement solver keeps the background temperature field (M7a).
package dev.brights0ng.greedyfluids.refine;

import dev.brights0ng.greedyfluids.grid.CellEdit3D;
import dev.brights0ng.greedyfluids.grid.CellGrid3D;
import dev.brights0ng.greedyfluids.grid.CellType;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.solve.BoxSolver3D;
import dev.brights0ng.greedyfluids.solve.WallStore3D;
import java.util.List;
import java.util.Objects;

/**
 * Atomic AIR/SOLID edit batches between steps, for any 3D run (model decided by Bright, 2026-10-31; ported to 3D
 * 2026-11-04). Rules:
 * <ol>
 * <li>Validate the whole batch against the pre-batch grid before any mutation: every cell at most once, PLACE needs
 *     AIR, BREAK needs SOLID. Door cells are never edited.</li>
 * <li>Rasterise the old solver (limited cell T and velocities, unit-face velocities) into the caller's raster.</li>
 * <li>Old solid block heat: T_blk = Σ w_s T_s / Σ w_s with w_s = C_s / min(n_s, 2) (J/K) over the old non-door
 *     stores containing the block. A block in no store has no tracked heat.</li>
 * <li>BREAK: T_nbr is the mean of the pre-batch fluid face neighbours (up to 6). With tracked heat,
 *     T = (C_air T_nbr + C_blk T_blk) / (C_air + C_blk), C_air = rhoCp · 1 m³, C_blk = Σ w_s; without neighbours
 *     T_nbr = T_blk. Without tracked heat T = T_nbr; with neither, fallback (counted). New air starts at rest.</li>
 * <li>PLACE: the new block takes the displaced pre-batch air T. Steps 3–5 read only old state, so order within a
 *     batch has no effect.</li>
 * <li>Mutate the grid, zero every unit face of each edited cell, and rebuild the wall stores
 *     ({@link WallStore3D#rebuild}: identical rays copy bitwise, others take their blocks' T).</li>
 * <li>The caller meshes the edited grid and calls {@link #rebuild}, which remaps, projects and books
 *     E_after − E_before as edit energy outside the step residual.</li>
 * </ol>
 * Edit application may allocate; stepping does not.
 */
public final class GridEdits3D {
    private GridEdits3D() { }

    /** Temperature (°C) for a cell with no tracked heat. */
    @FunctionalInterface
    public interface FallbackT { double at(int x, int y, int z); }

    /**
     * Replacement wall stores, pre-edit total energy (J), fallback air/block cell counts, and the edited cells'
     * indices ((y·nz + z)·nx + x).
     */
    public record Result(WallStore3D store, double energyBefore, int fallbackAirCells, int fallbackBlocks,
            int[] editedCells) { }

    /**
     * Applies steps 1–6. The raster must belong to old's graph; on return its cells hold the edited fields
     * (placed cells NaN, broken cells at their new T and at rest) and its unit faces the edited velocities.
     */
    public static Result apply(BoxSolver3D old, CellGrid3D grid, List<CellEdit3D> edits, FallbackT fallback,
            Remap3D.Raster raster) {
        return apply(old, grid, edits, fallback, raster, false);
    }

    /**
     * As above. localRaster (M6c3): the raster is prepared in local mode and only the old boxes holding the edited
     * cells and their six neighbours are rasterised here, which is everything this step reads or writes; the
     * caller rasterises the boxes it remeshes, and the local transfer the rest it replaces.
     */
    public static Result apply(BoxSolver3D old, CellGrid3D grid, List<CellEdit3D> edits, FallbackT fallback,
            Remap3D.Raster raster, boolean localRaster) {
        return apply(old, grid, edits, fallback, raster, localRaster, false);
    }

    /**
     * As above. localStores (M6e2): block heat is read only for the blocks this batch needs, and the wall stores
     * are rebuilt along the edited cells' axis lines ({@link WallStore3D#rebuildLocal}) instead of from a scan of
     * the grid. The result is the same, bit for bit.
     */
    public static Result apply(BoxSolver3D old, CellGrid3D grid, List<CellEdit3D> edits, FallbackT fallback,
            Remap3D.Raster raster, boolean localRaster, boolean localStores) {
        Objects.requireNonNull(fallback, "fallback");
        int nx = grid.nx(), ny = grid.ny(), nz = grid.nz(), cells = nx * ny * nz, count = edits.size();
        java.util.HashSet<Integer> seen = new java.util.HashSet<>();
        int[] editedCells = new int[count];
        for (int k = 0; k < count; k++) {
            CellEdit3D e = edits.get(k);
            if (!grid.inBounds(e.x(), e.y(), e.z()))
                throw new IllegalArgumentException("edit outside grid: " + e);
            int cell = grid.index(e.x(), e.y(), e.z());
            if (!seen.add(cell)) throw new IllegalArgumentException("repeated edit cell: " + e);
            editedCells[k] = cell;
            CellType required = e.kind() == CellEdit3D.Kind.PLACE ? CellType.AIR : CellType.SOLID;
            if (grid.type(e.x(), e.y(), e.z()) != required)
                throw new IllegalArgumentException("edit requires " + required + ": " + e);
        }
        double energyBefore = old.totalEnergy();
        if (!localRaster) Remap3D.rasterise(old, raster);
        else {
            Remap3D.prepareLocal(old, raster);
            for (CellEdit3D e : edits)
                for (int d = 0; d < 7; d++) {
                    int x = e.x() + (d == 1 ? -1 : d == 2 ? 1 : 0);
                    int y = e.y() + (d == 3 ? -1 : d == 4 ? 1 : 0);
                    int z = e.z() + (d == 5 ? -1 : d == 6 ? 1 : 0);
                    if (grid.inBounds(x, y, z)) Remap3D.rasteriseCell(raster, grid.index(x, y, z));
                }
        }
        double[] cellT = raster.cells[0];
        WallStore3D stores = old.wallStore();
        // Tracked block heat (rule 3): every cell on the full path, the broken cells alone on the local one.
        double[] blockT = null, blockC = null, heat = new double[2];
        if (!localStores) {
            blockT = new double[cells]; blockC = new double[cells];
            for (int i = 0; i < stores.count(); i++) {
                if (stores.kind(i) == WallStore3D.DOOR) continue;
                int start = stores.blockStart(i), end = stores.blockStart(i + 1);
                double w = stores.capacity(i) / Math.min(end - start, WallStore3D.MAX_STORE_BLOCKS);
                for (int k = start; k < end; k++) {
                    int cell = stores.blockCell(k);
                    blockT[cell] += w * stores.temperature(i);
                    blockC[cell] += w;
                }
            }
            for (int c = 0; c < cells; c++) blockT[c] = blockC[c] == 0 ? Double.NaN : blockT[c] / blockC[c];
        }
        double rhoCp = old.config().rhoCp();
        double[] newAirT = new double[count], placedT = new double[count];
        boolean[] wasSolid = new boolean[count];
        int fallbackAir = 0;
        for (int k = 0; k < count; k++) {
            CellEdit3D e = edits.get(k);
            int cell = editedCells[k];
            if (e.kind() == CellEdit3D.Kind.PLACE) {
                placedT[k] = cellT[cell];
                if (!localStores) blockT[cell] = cellT[cell];
                continue;
            }
            wasSolid[k] = true;
            double capacity, tracked;
            if (localStores) {
                stores.trackedHeat(grid, cell, c -> grid.type(c % nx, c / (nx * nz), (c / nx) % nz) == CellType.SOLID, heat);
                capacity = heat[1]; tracked = capacity == 0 ? Double.NaN : heat[0] / capacity;
            } else { capacity = blockC[cell]; tracked = blockT[cell]; }
            double sum = 0;
            int fluid = 0;
            for (int d = 0; d < 6; d++) {
                int x = e.x() + (d == 0 ? -1 : d == 1 ? 1 : 0);
                int y = e.y() + (d == 2 ? -1 : d == 3 ? 1 : 0);
                int z = e.z() + (d == 4 ? -1 : d == 5 ? 1 : 0);
                if (grid.inBounds(x, y, z) && grid.type(x, y, z).isFluid()) { sum += cellT[grid.index(x, y, z)]; fluid++; }
            }
            double nbr = fluid > 0 ? sum / fluid : tracked;
            if (capacity > 0) newAirT[k] = (rhoCp * nbr + capacity * tracked) / (rhoCp + capacity);
            else if (fluid > 0) newAirT[k] = nbr;
            else { newAirT[k] = fallback.at(e.x(), e.y(), e.z()); fallbackAir++; }
        }
        for (int k = 0; k < count; k++) {
            CellEdit3D e = edits.get(k);
            int cell = editedCells[k];
            boolean place = e.kind() == CellEdit3D.Kind.PLACE;
            if (place) grid.setSolid(e.x(), e.y(), e.z(), e.material()); else grid.setAir(e.x(), e.y(), e.z());
            cellT[cell] = place ? Double.NaN : newAirT[k];
            for (int f = 1; f < 4; f++) raster.cells[f][cell] = place ? Double.NaN : 0;
            Remap3D.clearCellFaces(raster, e.x(), e.y(), e.z());
        }
        java.util.function.IntToDoubleFunction fill = c -> fallback.at(c % nx, c / (nx * nz), (c / nx) % nz);
        WallStore3D.Rebuilt rebuilt = localStores
                ? WallStore3D.rebuildLocal(grid, rhoCp, stores, editedCells, wasSolid, placedT, fill)
                : WallStore3D.rebuild(grid, rhoCp, stores, blockT, fill);
        return new Result(rebuilt.store(), energyBefore, fallbackAir, rebuilt.fallbackBlocks(), editedCells);
    }

    /**
     * Builds the replacement solver on a graph meshed from the edited grid: sources, wind, time and door states
     * carried, fields remapped from the raster, pressure cold-started and projected, edit energy booked.
     */
    public static BoxSolver3D rebuild(BoxSolver3D old, Result edit, Remap3D.Raster raster, BoxGraph3D next,
            CellGrid3D grid) {
        return rebuild(old, edit, raster, next, grid, BoxSolver3D::projectRemapped);
    }

    /** As {@link #rebuild}, with the caller's remap projection (for example AdaptiveMesh3D's local projection). */
    public static BoxSolver3D rebuild(BoxSolver3D old, Result edit, Remap3D.Raster raster, BoxGraph3D next,
            CellGrid3D grid, java.util.function.ToIntFunction<BoxSolver3D> projection) {
        BoxSolver3D solver = new BoxSolver3D(next, edit.store(), old.config(), old.solidDistance().edited(next, edit.editedCells()));
        solver.setSources(next.sourcePowers(grid));
        solver.setBackground(old.background());
        solver.setBackgroundWind(old.backgroundX(), old.backgroundY(), old.backgroundZ());
        BoxGraph3D before = old.graph();
        for (int b = 0; b < next.boxCount(); b++) if (next.isDoor(b))
            solver.setDoorOpen(b, before.doorOpen(before.boxOfCell(next.boxX0(b), next.boxY0(b), next.boxZ0(b))));
        Remap3D.transfer(raster, next).install(solver);
        solver.setTime(old.time());
        projection.applyAsInt(solver);
        solver.recordEdit(old, solver.totalEnergy() - edit.energyBefore(), edit.fallbackAirCells(), edit.fallbackBlocks());
        return solver;
    }
}
