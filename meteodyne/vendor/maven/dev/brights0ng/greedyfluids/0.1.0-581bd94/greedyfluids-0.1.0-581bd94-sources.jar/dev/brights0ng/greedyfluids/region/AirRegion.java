// Written by Claude (M7a).
// Edited by Claude: per-door toggles, entity heat, thermal state save/restore and the read-only frame (M7a).
// Edited by Claude: edit batches may place and remove doors (M7b).
// Edited by Claude: fixed wall temperatures (M7c).
// Edited by Claude: keep-fine follows source changes (M7f adoption); wall stores saved and restored one by one (M7f).
// Edited by Claude: the outdoor-store shift and wind changes that leave the hold (M7f adoption).
// Edited by Claude: EXCHANGE faces: far-side temperatures and distances, side cells' own conditions; frames carry box
//   extents (M8b).
// Edited by Claude: the contrast gate and the source-velocity radius join D3's defaults (M8c c3).
// Edited by Claude: the dynamic start: a heat-only estimate and moving toward it (M8e e3).
package dev.brights0ng.greedyfluids.region;

import dev.brights0ng.greedyfluids.grid.CellEdit3D;
import dev.brights0ng.greedyfluids.grid.CellGrid3D;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.mesh.StaticRefinement3D;
import dev.brights0ng.greedyfluids.refine.AdaptiveMesh3D;
import dev.brights0ng.greedyfluids.refine.RefineSettings;
import dev.brights0ng.greedyfluids.solve.Background3D;
import dev.brights0ng.greedyfluids.solve.BoxSolver3D;
import dev.brights0ng.greedyfluids.solve.WallStore3D;
import dev.brights0ng.greedyfluids.solve.SolverConfig3D;
import dev.brights0ng.greedyfluids.solve.SteadyHeat3D;
import dev.brights0ng.greedyfluids.solve.StepStats;
import java.util.List;
import java.util.Objects;

/**
 * One simulated air region: the adaptive solver D3 with every adopted default built in (M7a). This is the
 * production entry point; benches keep building variants from {@link AdaptiveMesh3D} directly.
 *
 * <p>D3's defaults, by where they live:
 * <ul>
 *   <li>numerics ({@link #config}): PCG tolerance {@link SolverConfig3D#ADAPTIVE_PCG_TOLERANCE}, heat sweeps at
 *       {@link SolverConfig3D#ADAPTIVE_THERMAL_TOLERANCE} with over-relaxation
 *       {@link SolverConfig3D#ADAPTIVE_THERMAL_RELAXATION};</li>
 *   <li>mesh: {@link RefineSettings#DEFAULT} and the opening rule {@link StaticRefinement3D#DEFAULT_RULE};</li>
 *   <li>{@link AdaptiveMesh3D}'s own defaults: RING local remeshes in a single round, full merge-cadence remeshes,
 *       local raster and wall-store rebuilds, warm pressure, the 0.25 °C thermal velocity gate;</li>
 *   <li>the adaptive velocity hold AH25T12 ({@link #applyDefaults}), which AdaptiveMesh3D leaves off;</li>
 *   <li>background updates that leave the hold alone, and the weather shift of following air and the wall
 *       stores it touches (H1).</li>
 *   <li>keep-fine that follows source changes (SKF, M7f): a source turned on mid-run gets the fine cube a source
 *       present at the build has.</li>
 * </ul>
 *
 * <p>Geometry is the region's grid: cell (x, y, z) is the 1 m cube from (x, y, z) to (x + 1, y + 1, z + 1) m in
 * region coordinates. The region owns the grid it is given; the host must not change it afterwards except through
 * this class. Not thread-safe: one thread (the host's air thread) makes every call.
 */
public final class AirRegion {
    /**
     * D3's adaptive velocity hold since the M6e4 adoption (Bright, 2026-11-12; sweep AH25T12): refresh stretches
     * of 10 s, holds up to 110 s, 30 s of full steps after an event, flow tolerance 0.25 (relative), temperature
     * trigger 0.125 °C.
     */
    public static final double HOLD_REFRESH = 10, HOLD_LONGEST = 110, HOLD_WAKE = 30, HOLD_FLOW = 0.25,
            HOLD_DELTA_T = 0.125;

    private final CellGrid3D grid;
    private final AdaptiveMesh3D mesh;

    /**
     * A region whose air starts at its background, with the default physics ({@link SolverConfig3D#DEFAULT}, with
     * the background's reference as the expansion reference). Initial wind in m/s along x and z; boundaries are
     * the grid's (production windows set every side OPEN).
     */
    public AirRegion(CellGrid3D grid, Background3D background, double windX, double windZ) {
        this(grid, background, null, windX, windZ, SolverConfig3D.DEFAULT.withAmbientT(background.reference()));
    }

    /**
     * As above, with initial air temperatures (°C per cell in grid index order, null for the background) and the
     * physical settings of base; D3's numerics are applied to base by {@link #config}.
     */
    public AirRegion(CellGrid3D grid, Background3D background, double[] initialT, double windX, double windZ,
            SolverConfig3D base) {
        this.grid = Objects.requireNonNull(grid);
        mesh = new AdaptiveMesh3D(grid, initialT, config(base), RefineSettings.DEFAULT,
                StaticRefinement3D.DEFAULT_RULE, background);
        applyDefaults(mesh);
        if (windX != 0 || windZ != 0) {
            mesh.solver().setUniformVelocity(windX, 0, windZ);
            mesh.setBackgroundWind(windX, windZ);
        }
    }

    /**
     * A region restored from a thermal state (saved, or carried from an old window by
     * {@link ThermalState#moved}): air cells with a value start at it and the rest at their background; wall
     * stores take the mean of their blocks' values where any is known and equilibrate with the air otherwise.
     * The air starts at rest.
     */
    public static AirRegion restore(CellGrid3D grid, Background3D background, ThermalState initial, double windX,
            double windZ, SolverConfig3D base) {
        AirRegion r = new AirRegion(grid, background, initialAir(grid, background, initial), windX, windZ, base);
        WallStore3D w = r.mesh.solver().wallStore();
        for (int i = 0; i < w.count(); i++) {
            double sum = 0; int known = 0;
            for (int k = w.blockStart(i); k < w.blockStart(i + 1); k++) {
                float t = initial.solid(w.blockCell(k));
                if (Float.isFinite(t)) { sum += t; known++; }
            }
            if (known > 0) w.setTemperature(i, sum / known);
        }
        // M7f: stores kept one by one are exact. In a state that keeps stores, a store it doesn't list is at its air
        // cell's background, as an unlisted air cell is (a saver leaves out what reads as the background); the block
        // means above stand only for states without stores.
        if (initial.stores() > 0) {
            boolean[] listed = new boolean[w.count()];
            for (int k = 0; k < initial.stores(); k++) {
                int i = w.find(initial.storeCell(k), initial.storeDir(k));
                if (i >= 0 && Float.isFinite(initial.storeT(k))) { w.setTemperature(i, initial.storeT(k)); listed[i] = true; }
            }
            for (int i = 0; i < w.count(); i++) if (!listed[i]) w.setTemperature(i, background.cell(w.cellA(i)));
        }
        return r;
    }

    private static double[] initialAir(CellGrid3D grid, Background3D background, ThermalState initial) {
        if (initial.nx() != grid.nx() || initial.ny() != grid.ny() || initial.nz() != grid.nz())
            throw new IllegalArgumentException("thermal state does not fit the grid");
        double[] t = new double[grid.nx() * grid.ny() * grid.nz()];
        for (int c = 0; c < t.length; c++) {
            float a = initial.air(c);
            t[c] = Float.isFinite(a) ? a : background.cell(c);
        }
        return t;
    }

    /** D3's numerics on base's physics: PCG and heat-sweep tolerances and the heat sweeps' over-relaxation. */
    public static SolverConfig3D config(SolverConfig3D base) {
        return base.withTolerances(SolverConfig3D.ADAPTIVE_PCG_TOLERANCE, SolverConfig3D.ADAPTIVE_THERMAL_TOLERANCE,
                        base.thermalMaxSweeps())
                .withThermalRelaxation(SolverConfig3D.ADAPTIVE_THERMAL_RELAXATION);
    }

    /**
     * Sets D3's remesh levers, thermal gate and adaptive velocity hold on a mesh. The levers and gate repeat
     * AdaptiveMesh3D's own defaults, so a mesh that has changed none of them differs only by the hold.
     */
    public static void applyDefaults(AdaptiveMesh3D m) {
        m.setLocalScope(AdaptiveMesh3D.LocalScope.RING);
        m.setSingleRoundLocal(true);
        m.setLocalMergeRemesh(false);
        m.setFullFallback(1);
        m.setThermalVelocityGate(AdaptiveMesh3D.DEFAULT_THERMAL_GATE);
        m.setGateMode(AdaptiveMesh3D.GateMode.CONTRAST);
        m.setSourceVelocityRadius(AdaptiveMesh3D.DEFAULT_SOURCE_VELOCITY_RADIUS,
                AdaptiveMesh3D.DEFAULT_SOURCE_VELOCITY_LINGER);
        m.setHoldTrigger(AdaptiveMesh3D.HoldTrigger.CONTRAST);
        m.setShiftStores(true);
        m.setShiftOutdoorStoresOnly(true);
        m.setWindWake(AdaptiveMesh3D.WindWake.NONE);
        m.setSourceKeepFine(true);
        m.setVelocityHold(HOLD_REFRESH, HOLD_LONGEST, HOLD_WAKE);
        m.setAdaptiveHold(HOLD_FLOW, HOLD_DELTA_T);
    }

    /** Advances one step (dt s, 0.5 by default). */
    public void step() { mesh.step(); }

    /** Simulated time, s. */
    public double time() { return mesh.solver().time(); }

    /** Step length, s. */
    public double dt() { return mesh.solver().config().dt(); }

    /**
     * Applies an atomic batch of edits now (one per cell): AIR ↔ SOLID, and AIR ↔ DOOR (M7b; see
     * {@link CellEdit3D}). Air opened where no air neighbour exists, and blocks with no tracked heat, start at their
     * cell's background.
     */
    public void applyEdits(List<CellEdit3D> edits) {
        Background3D bg = mesh.background();
        mesh.applyEdits(edits, bg::at);
    }

    /** Opens or closes one door cell; a change wakes the velocity hold. */
    public void setDoorOpen(int x, int y, int z, boolean open) { mesh.setDoorOpen(x, y, z, open); }

    /**
     * Replaces the heat of moving entities (players, mobs), packed x, y, z (region metres), watts per entity.
     * It never wakes the velocity hold and never changes the mesh; returns how many entries landed in air.
     */
    public int setEntityHeat(double[] xyzw) { return mesh.setEntityHeat(xyzw); }

    /**
     * Fixes a SOLID cell's wall temperature, °C (lava, magma), or clears it with NaN (M7c). Every wall store holding
     * the block keeps that temperature, an unlimited source or sink for the air beside it. Changing the cell (an
     * edit) clears it; a change wakes the velocity hold.
     */
    public void setFixedTemperature(int x, int y, int z, double celsius) { mesh.setFixedTemperature(x, y, z, celsius); }

    /** Sets a cell's block heat source, W (negative cools); wakes the velocity hold. */
    public void setSource(int x, int y, int z, double watts) { mesh.setSource(x, y, z, watts); }

    /** Sets the background (weather) wind along x and z, m/s; a change wakes the velocity hold. */
    public void setWind(double windX, double windZ) { mesh.setBackgroundWind(windX, windZ); }

    /**
     * Replaces the background temperature field (°C per cell); the velocity hold is left as it is. Air in cells
     * with follow weights moves with its background (the weather shift; see {@link Background3D}).
     */
    public void setBackground(Background3D background) { mesh.setBackground(background); }

    /**
     * Sets one side's far-side temperatures for its EXCHANGE faces (M8b), °C by face-plane index
     * ({@link CellGrid3D#faceIndex}; NaN where nothing is across), or clears them with null: no heat crosses there.
     * The array is kept by reference and read at every step; it never wakes the velocity hold.
     */
    public void setExchangeTemperatures(CellGrid3D.Side side, float[] values) { mesh.exchange().set(side, values); }

    /**
     * Sets one side's far distances for its EXCHANGE faces (M8b), m by face-plane index: from the border to the far
     * air's centre, half the far box's depth ({@link AirFrame#extent}); NaN or unset for half a cell. Kept by
     * reference, read at every step.
     */
    public void setExchangeDistances(CellGrid3D.Side side, float[] values) { mesh.exchange().setDistances(side, values); }

    /**
     * Changes side cells' own conditions while running (M8b: OPEN, CLOSED, EXCHANGE or null for the side's): the
     * cells' boxes are remeshed and the solver rebuilt; a real change wakes the velocity hold. Set the starting
     * conditions on the grid before the region is built instead.
     */
    public void setFaceBoundaries(List<CellGrid3D.FaceBoundary> changes) { mesh.setFaceBoundaries(changes); }

    /** Background temperature field, °C per cell. */
    public Background3D background() { return mesh.background(); }

    /** Air temperature, °C, at a point in region metres; the background in solid or outside the grid. */
    public double sampleT(double x, double y, double z) { return mesh.solver().sampleT(x, y, z); }

    /** Air velocity into out[3], m/s, at a point in region metres; false (out unchanged) in solid or outside. */
    public boolean sampleVelocity(double x, double y, double z, double[] out) {
        return mesh.solver().sampleVelocity(x, y, z, out);
    }

    /**
     * Temperatures by cell for saving or carrying to a new window: each air cell its box's temperature, each cell
     * a wall store tracks the mean of those stores' temperatures, NaN elsewhere.
     */
    public ThermalState thermalState() {
        BoxSolver3D s = mesh.solver();
        BoxGraph3D g = s.graph();
        int n = grid.nx() * grid.ny() * grid.nz();
        float[] air = new float[n], solid = new float[n];
        for (int c = 0; c < n; c++) {
            int b = g.boxOfCellIndex(c);
            air[c] = b < 0 ? Float.NaN : (float) s.temperature(b);
        }
        double[] sum = new double[n];
        int[] count = new int[n];
        WallStore3D w = s.wallStore();
        for (int i = 0; i < w.count(); i++)
            for (int k = w.blockStart(i); k < w.blockStart(i + 1); k++) { sum[w.blockCell(k)] += w.temperature(i); count[w.blockCell(k)]++; }
        for (int c = 0; c < n; c++) solid[c] = count[c] == 0 ? Float.NaN : (float) (sum[c] / count[c]);
        // M7f: every store that isn't fixed, one by one, so a restore on the same geometry puts each back exactly
        int kept = 0;
        int[] cells = new int[w.count()];
        byte[] dirs = new byte[w.count()];
        float[] temps = new float[w.count()];
        for (int i = 0; i < w.count(); i++) {
            if (w.isFixed(i)) continue;
            cells[kept] = w.cellA(i); dirs[kept] = (byte) w.direction(i); temps[kept++] = (float) w.temperature(i);
        }
        return new ThermalState(grid.nx(), grid.ny(), grid.nz(), air, solid, java.util.Arrays.copyOf(cells, kept),
                java.util.Arrays.copyOf(dirs, kept), java.util.Arrays.copyOf(temps, kept));
    }

    private BoxGraph3D framedGraph;
    private int[] framedBoxOf, framedExtents;
    /**
     * A read-only copy of the air now, for queries from other threads: per-box temperature and the velocity at
     * each box's centre. The cell-to-box map is copied only when the mesh has changed since the last frame.
     */
    public AirFrame publish() {
        BoxSolver3D s = mesh.solver();
        BoxGraph3D g = s.graph();
        int nb = g.boxCount();
        if (g != framedGraph) {
            int[] boxOf = new int[grid.nx() * grid.ny() * grid.nz()];
            for (int c = 0; c < boxOf.length; c++) boxOf[c] = g.boxOfCellIndex(c);
            int[] extents = new int[3 * nb];
            for (int b = 0; b < nb; b++) {
                extents[3 * b] = g.boxSx(b); extents[3 * b + 1] = g.boxSy(b); extents[3 * b + 2] = g.boxSz(b);
            }
            framedGraph = g; framedBoxOf = boxOf; framedExtents = extents;
        }
        float[] t = new float[nb], u = new float[nb], v = new float[nb], w = new float[nb];
        double[] out = new double[3];
        for (int b = 0; b < nb; b++) {
            t[b] = (float) s.temperature(b);
            double cx = g.boxX0(b) + 0.5 * g.boxSx(b), cy = g.boxY0(b) + 0.5 * g.boxSy(b), cz = g.boxZ0(b) + 0.5 * g.boxSz(b);
            if (s.sampleVelocity(cx, cy, cz, out)) { u[b] = (float) out[0]; v[b] = (float) out[1]; w[b] = (float) out[2]; }
        }
        return new AirFrame(time(), grid.nx(), grid.ny(), grid.nz(), framedBoxOf, framedExtents, t, u, v, w,
                mesh.background());
    }

    /** The region's grid (owned by the region; read only for callers). */
    public CellGrid3D grid() { return grid; }

    /** Last step's statistics (mutable, overwritten each step). */
    public StepStats stats() { return mesh.stats(); }

    /** The adaptive mesh, for diagnostics and benches. */
    public AdaptiveMesh3D mesh() { return mesh; }

    /**
     * Whether the dynamic start has anything to estimate here (M8e e3): a fixed wall, or a box with a nonzero source
     * in {@code sourceWatts} (per box of the current graph, W; null for the region's own).
     */
    public boolean needsEstimate(double[] sourceWatts) {
        return SteadyHeat3D.needed(mesh.solver(), sourceWatts);
    }

    /**
     * The dynamic start's heat-only estimate on the current graph and stores ({@link SteadyHeat3D}): fixed walls at
     * steady state, block sources a horizon on, outdoor air tied to the weather; EXCHANGE faces read the far sides
     * the host has set. {@code sourceWatts}: per box of the current graph, W (null: the region's own). Changes
     * nothing; pass the result to {@link #moveTowardEstimate} before the graph changes (a step may remesh).
     */
    public SteadyHeat3D.Estimate estimateStart(SteadyHeat3D.Settings settings, double[] sourceWatts) {
        return estimateStart(settings, sourceWatts, null);
    }

    /**
     * As above with the outdoor tie per cell, 0–1 in grid index order ({@code tie}: the host's air open to the sky;
     * null: the background's follow weights where they are 1).
     */
    public SteadyHeat3D.Estimate estimateStart(SteadyHeat3D.Settings settings, double[] sourceWatts, float[] tie) {
        return SteadyHeat3D.estimate(mesh.solver(), mesh.exchange(), sourceWatts, tie, settings);
    }

    /**
     * Moves the air and wall stores toward an estimate (M8e e3): each box and non-fixed store gains
     * (estimate − its cold start) × {@code weight}. A region built cold reaches the estimate at weight 1; a region
     * restored from a save decayed toward the background by e^(−Δt/τ) reaches estimate + (saved − estimate) ·
     * e^(−Δt/τ) at weight 1 − e^(−Δt/τ) (decision 49). Throws if the graph or stores changed since the estimate.
     */
    public void moveTowardEstimate(SteadyHeat3D.Estimate estimate, double weight) {
        BoxSolver3D s = mesh.solver();
        if (estimate.graph() != s.graph() || estimate.walls() != s.wallStore())
            throw new IllegalStateException("the estimate is for another graph or set of stores");
        if (!(weight >= 0 && weight <= 1)) throw new IllegalArgumentException("weight must be in [0, 1]");
        if (weight == 0) return;
        for (int b = 0; b < estimate.boxT().length; b++)
            s.setTemperature(b, s.temperature(b) + weight * (estimate.boxT()[b] - estimate.coldBoxT()[b]));
        WallStore3D w = s.wallStore();
        for (int i = 0; i < w.count(); i++)
            if (!w.isFixed(i)) w.setTemperature(i, w.temperature(i) + weight * (estimate.storeT()[i] - estimate.coldStoreT()[i]));
    }
}
