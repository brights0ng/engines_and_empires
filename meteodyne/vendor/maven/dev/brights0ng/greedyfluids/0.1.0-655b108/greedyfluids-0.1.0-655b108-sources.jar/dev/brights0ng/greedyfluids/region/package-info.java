// Written by Claude (M7a).
/** Production entry points for hosts: one simulated air region with D3's adopted defaults. */
package dev.brights0ng.greedyfluids.region;
