// Written by ChatGPT from Claude's M5b spec.
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D.BoundaryKind;
import java.util.Arrays;

/** Mutable physical state: T in °C, phi in m²/s, normal velocities in m/s, time in s. */
final class FlowState3D {
    final double[] T, phi, u, ub, uBg, ubBg;
    private final BoxGraph3D g;
    double backgroundX, backgroundY, backgroundZ, time;

    FlowState3D(BoxGraph3D graph, SolverConfig3D config) {
        g = graph;
        T = new double[g.boxCount()]; phi = new double[g.boxCount()];
        u = new double[g.faceCount()]; ub = new double[g.boundaryCount()];
        uBg = new double[u.length]; ubBg = new double[ub.length];
        Arrays.fill(T, config.ambientT());
    }
    void applyClosures(BoxGraph3D graph) {
        for (int f = 0; f < u.length; f++) if (graph.aperture(f) == 0) u[f] = 0;
        for (int k = 0; k < ub.length; k++) {
            if (graph.boundaryAperture(k) == 0) ub[k] = 0;
            else if (graph.boundaryKind(k) == BoundaryKind.INFLOW) ub[k] = graph.boundaryInflow(k);
        }
    }
    void setBackgroundWind(double ux, double uy, double uz) {
        backgroundX = ux; backgroundY = uy; backgroundZ = uz;
        for (int f = 0; f < u.length; f++) uBg[f] = component(g.faceAxis(f), ux, uy, uz);
        for (int k = 0; k < ub.length; k++) ubBg[k] = component(g.boundaryAxis(k), ux, uy, uz);
    }
    static double component(int axis, double x, double y, double z) {
        return axis == 0 ? x : axis == 1 ? y : z;
    }
}
