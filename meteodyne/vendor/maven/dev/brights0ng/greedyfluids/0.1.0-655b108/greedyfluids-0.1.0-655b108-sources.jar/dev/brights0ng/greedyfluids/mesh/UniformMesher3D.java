// Written by ChatGPT from Claude's M5b spec.
package dev.brights0ng.greedyfluids.mesh;

import dev.brights0ng.greedyfluids.grid.CellGrid3D;
import java.util.Arrays;

/** One 1 m³ box per fluid cell, in ascending cell-index order (y, z, x). */
public final class UniformMesher3D {
    private UniformMesher3D() { }
    /** Builds a uniform graph using air volumetric heat capacity rhoCp, J/(m³·K). */
    public static BoxGraph3D mesh(CellGrid3D grid, double rhoCp) {
        int n = 0;
        for (int y = 0; y < grid.ny(); y++) for (int z = 0; z < grid.nz(); z++)
            for (int x = 0; x < grid.nx(); x++) if (grid.type(x, y, z).isFluid()) n++;
        int[] xs = new int[n], ys = new int[n], zs = new int[n], ones = new int[n];
        Arrays.fill(ones, 1);
        int i = 0;
        for (int y = 0; y < grid.ny(); y++) for (int z = 0; z < grid.nz(); z++)
            for (int x = 0; x < grid.nx(); x++) if (grid.type(x, y, z).isFluid()) {
                xs[i] = x; ys[i] = y; zs[i++] = z;
            }
        return BoxGraph3D.build(grid, xs, ys, zs, ones, ones, ones, rhoCp);
    }
}
