// Written by Claude (M8b).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.grid.CellGrid3D;
import dev.brights0ng.greedyfluids.grid.CellGrid3D.Side;

/**
 * Far sides of EXCHANGE faces (M8b), per side cell by its face-plane index ({@link CellGrid3D#faceIndex}): the air
 * just across a tile border as the host last saw it.
 * <ul>
 *   <li><b>Temperature,</b> °C. A side with none set, or a NaN entry, is insulated there: no heat crosses.</li>
 *   <li><b>Distance</b> from the border to the far air's centre, m (the far box's half depth along the normal). With
 *       none set, or a NaN or non-positive entry, half a cell.</li>
 * </ul>
 * Arrays are kept by reference, so the host replaces a side's array (or rewrites it) only between steps.
 */
public final class ExchangeTemperatures {
    /** The far distance where the host gives none: half a cell, m. */
    public static final double HALF_CELL = 0.5;
    private final int nx, ny, nz;
    private final float[][] sides = new float[6][], distances = new float[6][];

    /** For a domain of nx × ny × nz cells. */
    public ExchangeTemperatures(int nx, int ny, int nz) {
        if (nx <= 0 || ny <= 0 || nz <= 0) throw new IllegalArgumentException("invalid domain");
        this.nx = nx; this.ny = ny; this.nz = nz;
    }

    /** Cells in a side's face plane, as {@link CellGrid3D#faceLength}. */
    public int length(Side side) {
        return switch (side.axis()) { case 0 -> ny * nz; case 1 -> nx * nz; default -> nx * ny; };
    }

    /** Sets a side's far temperatures, °C by face-plane index (NaN: insulated), or clears them with null. */
    public void set(Side side, float[] values) {
        if (values != null && values.length != length(side))
            throw new IllegalArgumentException(side + " takes " + length(side) + " values, got " + values.length);
        sides[side.ordinal()] = values;
    }

    /** A side's far temperatures as set, or null. */
    public float[] get(Side side) { return sides[side.ordinal()]; }

    /** Sets a side's far distances, m by face-plane index (NaN or non-positive: half a cell), or clears them. */
    public void setDistances(Side side, float[] values) {
        if (values != null && values.length != length(side))
            throw new IllegalArgumentException(side + " takes " + length(side) + " values, got " + values.length);
        distances[side.ordinal()] = values;
    }

    /** A side's far distances as set, or null. */
    public float[] distances(Side side) { return distances[side.ordinal()]; }

    /** The far distance at a face-plane index of a side, m: as set when positive, else half a cell. */
    public double distance(Side side, int index) {
        float[] values = distances[side.ordinal()];
        if (values == null) return HALF_CELL;
        float d = values[index];
        return d > 0 ? d : HALF_CELL;
    }

    /** The far temperature at a face-plane index of a side, °C; NaN when none. */
    public double at(Side side, int index) {
        float[] values = sides[side.ordinal()];
        return values == null ? Double.NaN : values[index];
    }
}
