// Written by ChatGPT from Claude's M5b spec.
// Edited by Claude: fixed wall temperatures per solid cell (M7c).
// Edited by Claude: the surface film resistance, set by a host (M8a).
// Edited by Claude: per-cell side conditions and EXCHANGE (M8b).
// Edited by Claude: the surface of fixed walls, and keep-fine cubes around them, a host's choice (M8e).
package dev.brights0ng.greedyfluids.grid;

import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;

/** Dense editable grid of 1 m cubes, indexed (y * nz + z) * nx + x. */
public final class CellGrid3D {
    /** Domain side; axes x, y, z are numbered 0, 1, 2. */
    public enum Side {
        WEST, EAST, DOWN, UP, NORTH, SOUTH;
        /** Normal axis, dimensionless. */
        public int axis() { return ordinal() / 2; }
        /** Whether this side is at the high coordinate. */
        public boolean high() { return (ordinal() & 1) != 0; }
    }
    /**
     * Condition on a domain side, or on one cell of it (M8b). OPEN: air passes at ambient pressure and conducts to
     * the background. INFLOW: the wind is forced in. CLOSED: no air and no heat cross. EXCHANGE: no air crosses, and
     * heat crosses to a far-side temperature the host sets per cell (none set: no heat either), the way air meets
     * air across a tile border.
     */
    public enum Boundary { OPEN, INFLOW, CLOSED, EXCHANGE }
    /** One side cell's own condition, for changes to a running region (M8b); a null condition clears it. */
    public record FaceBoundary(Side side, int x, int y, int z, Boundary boundary) { }
    private final int nx, ny, nz;
    private final CellType[] types;
    private final Material[] materials;
    private final boolean[] doors;
    /** Fixed wall temperatures, °C, by cell (NaN: none); null until one is set. */
    private double[] fixed;
    private final Map<Integer, Double> sources = new TreeMap<>();
    private final Map<Integer, Double> sourceView = Collections.unmodifiableMap(sources);
    private final Boundary[] boundaries = {Boundary.OPEN, Boundary.OPEN, Boundary.CLOSED,
            Boundary.OPEN, Boundary.OPEN, Boundary.OPEN};
    private final double[] speeds = new double[6];
    /** Per side, each face cell's own condition (null: the side's), by {@link #faceIndex}; null until one is set. */
    private final Boundary[][] faceKinds = new Boundary[6][];
    private int faceOverrides;
    /** Surface film resistance on each side of a solid face, s/m. */
    private double filmResistance = Material.FILM_RESISTANCE;
    /** How fixed walls meet their air (M8e). */
    private FixedSurface fixedSurface = FixedSurface.RAY;
    /** Keep-fine cube radius around fixed walls that face fluid, cells; 0: none (M8e). */
    private int fixedKeepFine;

    /** Creates an AIR grid with positive dimensions in cells (= m). */
    public CellGrid3D(int nx, int ny, int nz) {
        if (nx <= 0 || ny <= 0 || nz <= 0 || (long) nx * ny > Integer.MAX_VALUE / nz)
            throw new IllegalArgumentException("invalid grid dimensions");
        this.nx = nx; this.ny = ny; this.nz = nz;
        types = new CellType[nx * ny * nz];
        Arrays.fill(types, CellType.AIR);
        materials = new Material[types.length];
        doors = new boolean[types.length];
    }
    /** x extent, cells (= m). */
    public int nx() { return nx; }
    /** y extent, cells (= m). */
    public int ny() { return ny; }
    /** z extent, cells (= m). */
    public int nz() { return nz; }
    /** Cell index, dimensionless; coordinates are cells. */
    public int index(int x, int y, int z) { return (y * nz + z) * nx + x; }
    /** Whether the cell coordinates lie in this grid. */
    public boolean inBounds(int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < nx && y < ny && z < nz;
    }
    private int checked(int x, int y, int z) {
        if (!inBounds(x, y, z)) throw new IllegalArgumentException("cell outside grid");
        return index(x, y, z);
    }
    /** Cell type. Coordinates are cells. */
    public CellType type(int x, int y, int z) { return types[checked(x, y, z)]; }
    /** Solid/door material, null for AIR. Coordinates are cells. */
    public Material material(int x, int y, int z) { return materials[checked(x, y, z)]; }
    /** Door flag, false for non-doors. Coordinates are cells. */
    public boolean doorOpen(int x, int y, int z) { return doors[checked(x, y, z)]; }
    private void set(int x, int y, int z, CellType type, Material material, boolean open) {
        int i = checked(x, y, z);
        types[i] = type; materials[i] = material; doors[i] = open;
        if (fixed != null) fixed[i] = Double.NaN;
    }
    /** Sets an AIR cell (coordinates in cells). */
    public void setAir(int x, int y, int z) { set(x, y, z, CellType.AIR, null, false); }
    /** Sets a SOLID cell (coordinates in cells); null uses the default wall material. */
    public void setSolid(int x, int y, int z, Material material) { set(x, y, z, CellType.SOLID, material, false); }
    /** Sets a DOOR cell (coordinates in cells). */
    public void setDoor(int x, int y, int z, Material material, boolean open) {
        set(x, y, z, CellType.DOOR, material, open);
    }
    /** Changes an existing door's flag; throws for non-doors. */
    public void setDoorOpen(int x, int y, int z, boolean open) {
        int i = checked(x, y, z);
        if (types[i] != CellType.DOOR) throw new IllegalArgumentException("not a door");
        doors[i] = open;
    }
    /**
     * Fixes a SOLID cell's wall temperature, °C (M7c): every wall store holding the block keeps that temperature
     * (lava, a magma block). NaN clears it. Any later change of the cell's type or material clears it too.
     */
    public void setFixedTemperature(int x, int y, int z, double celsius) {
        int i = checked(x, y, z);
        if (!Double.isNaN(celsius) && (types[i] != CellType.SOLID || !Double.isFinite(celsius)))
            throw new IllegalArgumentException("a fixed temperature needs a SOLID cell and a finite value");
        if (fixed == null) {
            if (Double.isNaN(celsius)) return;
            fixed = new double[types.length];
            Arrays.fill(fixed, Double.NaN);
        }
        fixed[i] = celsius;
    }
    /** A cell's fixed wall temperature by index, °C, or NaN. */
    public double fixedTemperature(int index) { return fixed == null ? Double.NaN : fixed[index]; }
    /** Whether any cell has a fixed wall temperature. */
    public boolean hasFixedTemperatures() {
        if (fixed == null) return false;
        for (double t : fixed) if (!Double.isNaN(t)) return true;
        return false;
    }
    /** Fills the inclusive cuboid in cell coordinates with AIR. */
    public void fillAir(int x0, int y0, int z0, int x1, int y1, int z1) {
        for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++)
            for (int x = x0; x <= x1; x++) setAir(x, y, z);
    }
    /** Fills the inclusive cuboid in cell coordinates with SOLID. */
    public void fillSolid(int x0, int y0, int z0, int x1, int y1, int z1, Material material) {
        for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++)
            for (int x = x0; x <= x1; x++) setSolid(x, y, z, material);
    }
    /** Adds finite power in W to an in-bounds fluid cell. */
    public void addSource(int x, int y, int z, double watts) {
        int i = checked(x, y, z);
        setSource(x, y, z, sources.getOrDefault(i, 0.0) + watts);
    }
    /** Sets finite power in W in an in-bounds fluid cell; zero removes it. */
    public void setSource(int x, int y, int z, double watts) {
        int i = checked(x, y, z);
        if (!types[i].isFluid() || !Double.isFinite(watts)) throw new IllegalArgumentException("invalid source");
        if (watts == 0) sources.remove(i); else sources.put(i, watts);
    }
    /** Unmodifiable live view of cell-index to power (W), in ascending index order. */
    public Map<Integer, Double> sources() { return sourceView; }
    /** Side condition. */
    public Boundary boundary(Side side) { return boundaries[side.ordinal()]; }
    /** Speed into the domain, m/s; zero except for INFLOW. */
    public double inflowSpeed(Side side) { return speeds[side.ordinal()]; }
    /** Sets a side condition with zero inflow speed (m/s). */
    public void setBoundary(Side side, Boundary boundary) { setBoundary(side, boundary, 0); }
    /** Sets a side condition, retaining speed (m/s into domain) only for INFLOW. */
    public void setBoundary(Side side, Boundary boundary, double inflowSpeed) {
        boundaries[side.ordinal()] = boundary;
        speeds[side.ordinal()] = boundary == Boundary.INFLOW ? inflowSpeed : 0;
    }
    /** Cells in a side's face plane: ny·nz on WEST/EAST, nx·nz on DOWN/UP, nx·ny on NORTH/SOUTH. */
    public int faceLength(Side side) {
        return switch (side.axis()) { case 0 -> ny * nz; case 1 -> nx * nz; default -> nx * ny; };
    }
    /**
     * A cell's index in a side's face plane: its cell index with the side's axis dropped (y·nz + z on WEST/EAST,
     * z·nx + x on DOWN/UP, y·nx + x on NORTH/SOUTH). The cell must lie on that side.
     */
    public int faceIndex(Side side, int x, int y, int z) {
        checked(x, y, z);
        int a = side.axis(), at = a == 0 ? x : a == 1 ? y : z, edge = side.high() ? (a == 0 ? nx : a == 1 ? ny : nz) - 1 : 0;
        if (at != edge) throw new IllegalArgumentException("cell " + x + "," + y + "," + z + " is not on " + side);
        return a == 0 ? y * nz + z : a == 1 ? z * nx + x : y * nx + x;
    }
    /** The condition at one cell of a side: its own if set, else the side's (M8b). The cell must lie on the side. */
    public Boundary faceBoundary(Side side, int x, int y, int z) {
        Boundary[] own = faceKinds[side.ordinal()];
        int i = faceIndex(side, x, y, z);
        return own == null || own[i] == null ? boundaries[side.ordinal()] : own[i];
    }
    /**
     * Sets one side cell's own condition (M8b): OPEN, CLOSED or EXCHANGE (INFLOW needs a side's speed), or null for
     * the side's again. The cell must lie on the side. A region reads it when its mesh is built; a running one
     * takes changes through {@code AirRegion.setFaceBoundaries}.
     */
    public void setFaceBoundary(Side side, int x, int y, int z, Boundary boundary) {
        if (boundary == Boundary.INFLOW) throw new IllegalArgumentException("INFLOW is a whole side's condition");
        int i = faceIndex(side, x, y, z);
        Boundary[] own = faceKinds[side.ordinal()];
        if (own == null) {
            if (boundary == null) return;
            own = faceKinds[side.ordinal()] = new Boundary[faceLength(side)];
        }
        if ((own[i] == null) != (boundary == null)) faceOverrides += boundary == null ? -1 : 1;
        own[i] = boundary;
    }
    /** Whether any side cell has its own condition. */
    public boolean hasFaceBoundaries() { return faceOverrides > 0; }
    /** Surface film resistance on each side of a solid face, s/m: {@link Material#FILM_RESISTANCE} unless set. */
    public double filmResistance() { return filmResistance; }
    /**
     * Sets the surface film resistance on each side of a solid face, s/m (M8a). A physical film of R m²·K/W is
     * R × the air's rhoCp in these units (still indoor air, 0.13 m²·K/W, is 156.8 s/m at 1206 J/(m³·K)). Graphs and
     * wall stores read it when they are built, so set it before the region is.
     */
    public void setFilmResistance(double secondsPerMetre) {
        if (!(secondsPerMetre > 0) || !Double.isFinite(secondsPerMetre))
            throw new IllegalArgumentException("film resistance must be positive and finite: " + secondsPerMetre);
        filmResistance = secondsPerMetre;
    }
    /**
     * How a fixed wall's stores (lava, magma: {@link #setFixedTemperature}) couple to their air (M8e).
     * <ul>
     *   <li>{@link FixedSurface#RAY}: as every other store, through the film and half the resistance of the whole
     *       ray of solid blocks the store holds (M7c to M8d). A lava floor over deep stone then couples through the
     *       stone below it: about 0.6 W/K a face over 7 blocks, against 7.7 for the film alone.</li>
     *   <li>{@link FixedSurface#FILM}: through the film and only the blocks between the air and the first fixed
     *       block (none when the fixed block touches the air); the far side likewise from the last fixed block.</li>
     *   <li>{@link FixedSurface#CONVECTION}: as FILM, but a fixed block touching the air couples through the larger
     *       of the film's conductance and free convection off a hot (or cold) surface, by which way it faces.</li>
     * </ul>
     */
    public enum FixedSurface { RAY, FILM, CONVECTION }
    /** How fixed walls couple to their air: {@link FixedSurface#RAY} unless set. */
    public FixedSurface fixedSurface() { return fixedSurface; }
    /** Sets how fixed walls couple to their air (M8e); wall stores read it when they are built or refreshed. */
    public void setFixedSurface(FixedSurface surface) {
        fixedSurface = java.util.Objects.requireNonNull(surface, "surface");
    }
    /** Keep-fine cube radius around fixed walls that face fluid, cells: 0 (none) unless set. */
    public int fixedKeepFine() { return fixedKeepFine; }
    /**
     * Sets the keep-fine cube radius around fixed walls that face fluid, cells (M8e; 0 for none): such a wall is kept
     * fine as a source is ({@link dev.brights0ng.greedyfluids.mesh.StaticRefinement3D#marks}), so the air it heats
     * isn't averaged into one large box. Meshes read it when they are built or their marks refreshed.
     */
    public void setFixedKeepFine(int radius) {
        if (radius < 0) throw new IllegalArgumentException("radius must not be negative: " + radius);
        fixedKeepFine = radius;
    }
    /**
     * Independent deep copy of cells, source powers (W), boundaries and speeds (m/s), side cells' own conditions, the
     * film resistance, the fixed-wall surface and keep-fine radius.
     */
    public CellGrid3D copy() {
        CellGrid3D out = new CellGrid3D(nx, ny, nz);
        System.arraycopy(types, 0, out.types, 0, types.length);
        System.arraycopy(materials, 0, out.materials, 0, types.length);
        System.arraycopy(doors, 0, out.doors, 0, types.length);
        System.arraycopy(boundaries, 0, out.boundaries, 0, 6);
        System.arraycopy(speeds, 0, out.speeds, 0, 6);
        out.filmResistance = filmResistance;
        out.fixedSurface = fixedSurface;
        out.fixedKeepFine = fixedKeepFine;
        for (int s = 0; s < 6; s++) if (faceKinds[s] != null) out.faceKinds[s] = faceKinds[s].clone();
        out.faceOverrides = faceOverrides;
        out.sources.putAll(sources);
        if (fixed != null) out.fixed = fixed.clone();
        return out;
    }
}
