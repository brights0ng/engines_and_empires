// Written by ChatGPT from Claude's M5c spec.
// Edited by ChatGPT from Claude's M6a spec.
// Edited by Claude: report-only opening-rule variants (M6b2); THROUGH_AXIS_R1 is D3's default (M6b2 adoption).
// Edited by Claude: keep-fine cubes around fixed walls that face fluid, by the grid's radius (M8e).
package dev.brights0ng.greedyfluids.mesh;

import dev.brights0ng.greedyfluids.grid.CellGrid3D;
import dev.brights0ng.greedyfluids.grid.CellType;

/** Static Chebyshev keep-fine cubes around sources, doors and short solid-to-solid fluid runs. */
public final class StaticRefinement3D {
    /** Source radius, cells. */
    public static final int SOURCE_RADIUS = 3;
    /** Door/opening radius, cells. */
    public static final int OPENING_RADIUS = 2;
    /** Maximum opening fluid-run length, cells. */
    public static final int OPENING_GAP = 2;

    /** Longest narrow run along a through axis that still counts as a hole in a wall (THROUGH rules), cells. */
    public static final int THROUGH_LENGTH = 3;

    private StaticRefinement3D() { }

    /**
     * Opening-rule variants (M6b2). R2 is the M6b1 rule, still used by keepFine and G3: every opening cell
     * ({@link #isOpening}) marks a keep-fine cube of radius 2. Doors and sources are the same in every variant.
     * <ul>
     *   <li>R1: the cube has radius 1.</li>
     *   <li>AXIS_R2: radius 2, but the cube holds only the opening's narrow axes at extent 1 (an axis mask for
     *       MeshConstraint3D) instead of forcing unit boxes.</li>
     *   <li>THROUGH_R2: only through-holes mark (radius 2 cube): along an open axis the narrow run is at most
     *       {@link #THROUGH_LENGTH} cells and opens into fluid at both ends. Dead-end notches don't mark.</li>
     *   <li>THROUGH_AXIS_R1: through-holes only, axis mask, radius 1.</li>
     *   <li>OFF: no opening rule.</li>
     * </ul>
     */
    public enum OpeningRule { R2, R1, AXIS_R2, THROUGH_R2, THROUGH_AXIS_R1, OFF }

    /**
     * The adaptive mesh's default rule since M6b2 (Bright, 2026-11-07): through-holes only, axis-limited,
     * radius 1 (sweep variant V6). {@link #keepFine(CellGrid3D)} keeps the R2 rule for the static G3 mesher.
     */
    public static final OpeningRule DEFAULT_RULE = OpeningRule.THROUGH_AXIS_R1;

    /** Keep-fine flags and an optional per-cell axis mask (bit 0 x, 1 y, 2 z: extent 1 along that axis). */
    public record Marks(boolean[] fine, byte[] axis) { }

    /** Marks for a rule with no extra sources; R2 gives exactly {@link #keepFine(CellGrid3D)} and no axis mask. */
    public static Marks marks(CellGrid3D grid, OpeningRule rule) {
        if (rule == OpeningRule.R2) return new Marks(keepFine(grid), null);
        int n = grid.nx() * grid.ny() * grid.nz();
        boolean[] fine = new boolean[n];
        boolean axisRule = rule == OpeningRule.AXIS_R2 || rule == OpeningRule.THROUGH_AXIS_R1;
        byte[] axis = axisRule ? new byte[n] : null;
        for (int c : grid.sources().keySet()) markSource(grid, fine, c);
        markFixedWalls(grid, fine);
        byte[] narrow = rule == OpeningRule.OFF ? null : narrowMasks(grid);
        boolean through = rule == OpeningRule.THROUGH_R2 || rule == OpeningRule.THROUGH_AXIS_R1;
        int r = rule == OpeningRule.R1 || rule == OpeningRule.THROUGH_AXIS_R1 ? 1 : OPENING_RADIUS;
        for (int y = 0; y < grid.ny(); y++) for (int z = 0; z < grid.nz(); z++)
            for (int x = 0; x < grid.nx(); x++) {
                if (grid.type(x, y, z) == CellType.DOOR) mark(grid, fine, x, y, z, OPENING_RADIUS);
                if (narrow == null) continue;
                int m = narrow[grid.index(x, y, z)];
                if (m == 0 || through && !throughHole(grid, narrow, x, y, z)) continue;
                if (axisRule) markAxis(grid, axis, (byte) m, x, y, z, r);
                else mark(grid, fine, x, y, z, r);
            }
        return new Marks(fine, axis);
    }

    /** Per cell, bit a set when the AIR cell's bounded fluid run along axis a is at most OPENING_GAP. */
    static byte[] narrowMasks(CellGrid3D grid) {
        byte[] m = new byte[grid.nx() * grid.ny() * grid.nz()];
        for (int y = 0; y < grid.ny(); y++) for (int z = 0; z < grid.nz(); z++)
            for (int x = 0; x < grid.nx(); x++) {
                if (grid.type(x, y, z) != CellType.AIR) continue;
                int b = 0;
                if (gap(grid, x, y, z, 1, 0, 0) <= OPENING_GAP) b |= 1;
                if (gap(grid, x, y, z, 0, 1, 0) <= OPENING_GAP) b |= 2;
                if (gap(grid, x, y, z, 0, 0, 1) <= OPENING_GAP) b |= 4;
                m[grid.index(x, y, z)] = (byte) b;
            }
        return m;
    }

    /**
     * Whether an opening cell is a through-hole: along some open (non-narrow) axis, the run of cells narrow on
     * one of its narrow axes is at most THROUGH_LENGTH long and both cells past its ends are fluid.
     */
    static boolean throughHole(CellGrid3D g, byte[] narrow, int x, int y, int z) {
        int m = narrow[g.index(x, y, z)];
        for (int w = 0; w < 3; w++) {
            if ((m & 1 << w) != 0) continue;
            int dx = w == 0 ? 1 : 0, dy = w == 1 ? 1 : 0, dz = w == 2 ? 1 : 0, len = 1;
            boolean ends = true;
            for (int s = -1; s <= 1; s += 2) {
                int cx = x + s * dx, cy = y + s * dy, cz = z + s * dz;
                while (g.inBounds(cx, cy, cz) && (narrow[g.index(cx, cy, cz)] & m) != 0 && len <= THROUGH_LENGTH) {
                    len++; cx += s * dx; cy += s * dy; cz += s * dz;
                }
                if (!(g.inBounds(cx, cy, cz) && g.type(cx, cy, cz).isFluid())) ends = false;
            }
            if (len <= THROUGH_LENGTH && ends) return true;
        }
        return false;
    }

    private static void markAxis(CellGrid3D g, byte[] axis, byte m, int x, int y, int z, int r) {
        for (int cy = Math.max(0, y-r); cy <= Math.min(g.ny()-1, y+r); cy++)
            for (int cz = Math.max(0, z-r); cz <= Math.min(g.nz()-1, z+r); cz++)
                for (int cx = Math.max(0, x-r); cx <= Math.min(g.nx()-1, x+r); cx++)
                    axis[g.index(cx, cy, cz)] |= m;
    }

    /** Keep-fine flags in cell-index order; solids may also be flagged. */
    public static boolean[] keepFine(CellGrid3D grid) {
        return keepFine(grid, new int[0]);
    }

    /** Extra source indices may be solid heat blocks; all radii are in cells. */
    public static boolean[] keepFine(CellGrid3D grid, int[] extraSourceCells) {
        boolean[] fine = new boolean[grid.nx() * grid.ny() * grid.nz()];
        for (int c : grid.sources().keySet()) markSource(grid, fine, c);
        for (int c : extraSourceCells) markSource(grid, fine, c);
        markFixedWalls(grid, fine);
        for (int y = 0; y < grid.ny(); y++) for (int z = 0; z < grid.nz(); z++)
            for (int x = 0; x < grid.nx(); x++)
                if (grid.type(x, y, z) == CellType.DOOR || isOpening(grid, x, y, z))
                    mark(grid, fine, x, y, z, OPENING_RADIUS);
        return fine;
    }

    /** Cells marked by opening, source and door cubes independently, including solids and overlaps. */
    public static int[] ruleCounts(CellGrid3D grid) {
        int n = grid.nx() * grid.ny() * grid.nz();
        boolean[][] rules = new boolean[3][n];
        for (int c : grid.sources().keySet()) markSource(grid, rules[1], c);
        for (int y = 0; y < grid.ny(); y++) for (int z = 0; z < grid.nz(); z++)
            for (int x = 0; x < grid.nx(); x++) {
                if (isOpening(grid, x, y, z)) mark(grid, rules[0], x, y, z, OPENING_RADIUS);
                if (grid.type(x, y, z) == CellType.DOOR) mark(grid, rules[2], x, y, z, OPENING_RADIUS);
            }
        int[] counts = new int[3];
        for (int i = 0; i < rules.length; i++) for (boolean marked : rules[i]) if (marked) counts[i]++;
        return counts;
    }

    /**
     * Marks a cube of the grid's {@link CellGrid3D#fixedKeepFine} radius around every fixed wall (lava, magma) with a
     * fluid face neighbour (M8e); nothing when the radius is 0.
     */
    static void markFixedWalls(CellGrid3D g, boolean[] fine) {
        int r = g.fixedKeepFine();
        if (r == 0 || !g.hasFixedTemperatures()) return;
        for (int y = 0; y < g.ny(); y++) for (int z = 0; z < g.nz(); z++)
            for (int x = 0; x < g.nx(); x++) {
                if (Double.isNaN(g.fixedTemperature(g.index(x, y, z)))) continue;
                boolean faces = false;
                for (int d = 0; d < 6 && !faces; d++) {
                    int cx = x + (d == 0 ? -1 : d == 1 ? 1 : 0), cy = y + (d == 2 ? -1 : d == 3 ? 1 : 0);
                    int cz = z + (d == 4 ? -1 : d == 5 ? 1 : 0);
                    faces = g.inBounds(cx, cy, cz) && g.type(cx, cy, cz).isFluid();
                }
                if (faces) mark(g, fine, x, y, z, r);
            }
    }

    private static void markSource(CellGrid3D g, boolean[] fine, int c) {
        mark(g, fine, c % g.nx(), c / g.nx() / g.nz(), c / g.nx() % g.nz(), SOURCE_RADIUS);
    }

    /** Whether this AIR cell has a bounded fluid run of at most two cells on any axis. */
    public static boolean isOpening(CellGrid3D grid, int x, int y, int z) {
        return grid.type(x, y, z) == CellType.AIR && (gap(grid, x, y, z, 1, 0, 0) <= OPENING_GAP
                || gap(grid, x, y, z, 0, 1, 0) <= OPENING_GAP
                || gap(grid, x, y, z, 0, 0, 1) <= OPENING_GAP);
    }

    private static int gap(CellGrid3D g, int x, int y, int z, int dx, int dy, int dz) {
        int n = 1;
        for (int s = -1; s <= 1; s += 2) {
            int cx = x + s * dx, cy = y + s * dy, cz = z + s * dz;
            while (g.inBounds(cx, cy, cz) && g.type(cx, cy, cz).isFluid()) {
                if (++n > OPENING_GAP) return Integer.MAX_VALUE;
                cx += s * dx; cy += s * dy; cz += s * dz;
            }
            if (!g.inBounds(cx, cy, cz)) return Integer.MAX_VALUE;
        }
        return n;
    }

    private static void mark(CellGrid3D g, boolean[] fine, int x, int y, int z, int r) {
        for (int cy = Math.max(0, y-r); cy <= Math.min(g.ny()-1, y+r); cy++)
            for (int cz = Math.max(0, z-r); cz <= Math.min(g.nz()-1, z+r); cz++)
                for (int cx = Math.max(0, x-r); cx <= Math.min(g.nx()-1, x+r); cx++)
                    fine[g.index(cx, cy, cz)] = true;
    }
}
