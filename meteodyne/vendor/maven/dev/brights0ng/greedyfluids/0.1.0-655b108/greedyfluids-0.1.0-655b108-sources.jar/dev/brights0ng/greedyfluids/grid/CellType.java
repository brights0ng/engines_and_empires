// Written by Claude.
package dev.brights0ng.greedyfluids.grid;

/** Type of one grid cell. Only {@link #SOLID} cells are not simulated; a door cell is air that can be closed. */
public enum CellType {
    AIR,
    SOLID,
    /** An air cell whose faces are closed while the door is shut. Always meshed as its own box. */
    DOOR;

    /** True for cells that hold simulated air ({@link #AIR} and {@link #DOOR}). */
    public boolean isFluid() {
        return this != SOLID;
    }
}
