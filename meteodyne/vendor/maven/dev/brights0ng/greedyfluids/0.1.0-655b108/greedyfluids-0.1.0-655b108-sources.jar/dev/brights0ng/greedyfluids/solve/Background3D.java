// Written by Claude (M7a).
// Edited by Claude: per-cell follow weights for the weather shift (M7a).
// Edited by Claude: a buoyancy reference apart from the background, and its stable form (M8b5).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;

/**
 * Background temperature, °C, per grid cell (M7; Bright, 2026-11-13): the temperature the air and walls would have
 * with no sources, edits or local flow. The host supplies it, for example the weather temperature where a cell is
 * open to the sky and the underground temperature at depth. It replaces the single SolverConfig3D.ambientT
 * wherever the solver compared with or relaxed toward ambient:
 * <ul>
 *   <li>buoyancy: a face's buoyant force is relative to the mean background of its two boxes;</li>
 *   <li>open boundaries: eddy exchange and inflow at the boundary box's background;</li>
 *   <li>wall stores of kind AMBIENT: the far side at the background of the ray's last solid cell;</li>
 *   <li>samples in solid or outside the grid, and the initial temperature of a mesh with none given;</li>
 *   <li>D3's thermal velocity gate and its velocity hold's flow test (AdaptiveMesh3D).</li>
 * </ul>
 * SolverConfig3D.ambientT stays the reference of the expansion coefficient 1/(T + 273.15).
 *
 * <p><b>Follow weights</b> (0–1 per cell, 0 when not given): how much a cell's air follows a change of its
 * background (Bright, 2026-11-13). 1 for air open to the sky, because outdoor air is the weather; 0 indoors and
 * underground, where walls buffer the change and the air catches up only through walls and openings. When a mesh
 * changes its background, each box moves by the mean of follow × (new − old background) over its cells, keeping
 * its departure from the background (a plume stays a plume); the new field's weights are used.
 *
 * <p>Immutable. Values are held as float offsets from a double reference, so a uniform field gives every box and
 * cell exactly the reference value, and a field built from a constant array matches {@link #uniform} bit for bit.
 * A box's background is the mean over its cells, from summed offsets (O(1) per box).
 *
 * <p><b>Buoyancy reference</b> (M8b5; Bright, 2026-11-17). By default buoyancy is measured against the background
 * itself, which is right where the background is the air's own resting state (outdoors). A host can give a
 * separate per-cell field to measure it against ({@link #withBuoyancy}: for example the outside air at each height,
 * where the background underground describes the rock rather than a state of the air), and/or ask for the
 * reference's <b>stable form</b> ({@link #withStableBuoyancy}): in each vertical run of air, the potential
 * temperature (T + {@link #DRY_ADIABATIC_LAPSE} · height) never decreasing upward, so a reference warmer below than
 * above (underground, deeper is warmer) no longer holds air in that unstable layering. The solver works the stable
 * form out against its graph ({@link #buoyancyBoxes}). Neither set: everything as before, bit for bit.
 */
public final class Background3D {
    /** Dry adiabatic lapse rate, °C per metre (g / cp of air): how much rising air cools. */
    public static final double DRY_ADIABATIC_LAPSE = 0.0098;
    private final int nx, ny, nz;
    private final double reference;
    private final float[] offset;
    private final double[] sums;
    private final float[] follow;
    /** The field buoyancy is measured against, when not this one (null: this). */
    private final Background3D buoyancy;
    /** Whether buoyancy takes the stable form of its field. */
    private final boolean stable;

    private Background3D(int nx, int ny, int nz, double reference, float[] offset, double[] sums, float[] follow) {
        this(nx, ny, nz, reference, offset, sums, follow, null, false);
    }

    private Background3D(int nx, int ny, int nz, double reference, float[] offset, double[] sums, float[] follow,
            Background3D buoyancy, boolean stable) {
        this.nx = nx; this.ny = ny; this.nz = nz; this.reference = reference; this.offset = offset; this.sums = sums;
        this.follow = follow; this.buoyancy = buoyancy; this.stable = stable;
    }

    /** One temperature, °C, for every cell of an nx×ny×nz grid. */
    public static Background3D uniform(int nx, int ny, int nz, double celsius) {
        check(nx, ny, nz);
        if (!Double.isFinite(celsius)) throw new IllegalArgumentException("background must be finite");
        return new Background3D(nx, ny, nz, celsius, null, null, null);
    }

    /**
     * A per-cell field, °C, in grid index order (y·nz + z)·nx + x; the array is copied. The reference is the first
     * cell's value; a constant array gives a uniform field.
     */
    public static Background3D of(int nx, int ny, int nz, float[] celsius) {
        check(nx, ny, nz);
        if (celsius.length != nx * ny * nz) throw new IllegalArgumentException("expected one value per cell");
        double ref = celsius[0];
        boolean flat = true;
        for (float t : celsius) {
            if (!Float.isFinite(t)) throw new IllegalArgumentException("background must be finite");
            if (t != celsius[0]) flat = false;
        }
        if (flat) return new Background3D(nx, ny, nz, ref, null, null, null);
        float[] off = new float[celsius.length];
        for (int i = 0; i < off.length; i++) off[i] = (float) (celsius[i] - ref);
        int px = nx + 1, pz = nz + 1;
        double[] s = new double[px * (ny + 1) * pz];
        for (int y = 0; y < ny; y++) for (int z = 0; z < nz; z++) for (int x = 0; x < nx; x++) {
            int p = ((y + 1) * pz + (z + 1)) * px + (x + 1);
            s[p] = off[(y * nz + z) * nx + x]
                    + s[p - 1] + s[p - px] + s[p - px * pz]
                    - s[p - 1 - px] - s[p - 1 - px * pz] - s[p - px - px * pz]
                    + s[p - 1 - px - px * pz];
        }
        return new Background3D(nx, ny, nz, ref, off, s, null);
    }

    /** A per-cell field with follow weights (0–1 per cell, grid index order); both arrays are copied. */
    public static Background3D of(int nx, int ny, int nz, float[] celsius, float[] follow) {
        return of(nx, ny, nz, celsius).withFollow(follow);
    }

    /** This field with follow weights (0–1 per cell, grid index order; copied), or none for null. */
    public Background3D withFollow(float[] weights) {
        if (weights == null) return new Background3D(nx, ny, nz, reference, offset, sums, null, buoyancy, stable);
        if (weights.length != nx * ny * nz) throw new IllegalArgumentException("expected one follow weight per cell");
        for (float w : weights) if (!(w >= 0 && w <= 1)) throw new IllegalArgumentException("follow weights must be in [0, 1]");
        return new Background3D(nx, ny, nz, reference, offset, sums, weights.clone(), buoyancy, stable);
    }

    /**
     * This field with buoyancy measured against {@code celsius} (per cell, grid index order; copied) instead of
     * itself, or against itself again for null (M8b5).
     */
    public Background3D withBuoyancy(float[] celsius) {
        return new Background3D(nx, ny, nz, reference, offset, sums, follow,
                celsius == null ? null : of(nx, ny, nz, celsius), stable);
    }

    /** This field with buoyancy measured against the stable form of its reference, or not (M8b5). */
    public Background3D withStableBuoyancy(boolean on) {
        return new Background3D(nx, ny, nz, reference, offset, sums, follow, buoyancy, on);
    }

    /** Whether buoyancy is measured against this field as it is (the default). */
    public boolean plainBuoyancy() { return buoyancy == null && !stable; }

    /** Whether buoyancy takes the stable form of its reference. */
    public boolean stableBuoyancy() { return stable; }

    /** The field buoyancy is measured against before any stable form: the host's, or this one. */
    public Background3D buoyancyField() { return buoyancy == null ? this : buoyancy; }

    /**
     * Fills out[b] with each box's buoyancy reference, °C: the mean over its cells of {@link #buoyancyField}, or of
     * its stable form when asked for. The stable form, in each vertical run of air cells (cells of no box break a
     * run), takes the running maximum of potential temperature from the run's bottom up and turns it back into
     * temperature at each height.
     */
    public void buoyancyBoxes(BoxGraph3D g, double[] out) {
        Background3D f = buoyancyField();
        if (!stable) { f.boxes(g, out); return; }
        float[] cells = new float[nx * ny * nz];
        for (int z = 0; z < nz; z++) for (int x = 0; x < nx; x++) {
            double run = Double.NEGATIVE_INFINITY;
            for (int y = 0; y < ny; y++) {
                int i = (y * nz + z) * nx + x;
                double t = f.cell(i);
                if (g.boxOfCell(x, y, z) < 0) { run = Double.NEGATIVE_INFINITY; cells[i] = (float) t; continue; }
                run = Math.max(run, t + DRY_ADIABATIC_LAPSE * y);
                cells[i] = (float) (run - DRY_ADIABATIC_LAPSE * y);
            }
        }
        of(nx, ny, nz, cells).boxes(g, out);
    }

    /** Whether any follow weights are set. */
    public boolean follows() { return follow != null; }

    /** Follow weight of a cell by grid index, 0–1. */
    public double follow(int index) { return follow == null ? 0 : follow[index]; }

    private static void check(int nx, int ny, int nz) {
        if (nx < 1 || ny < 1 || nz < 1) throw new IllegalArgumentException("grid dimensions must be positive");
    }

    /** Grid size along x, cells. */
    public int nx() { return nx; }
    /** Grid size along y, cells. */
    public int ny() { return ny; }
    /** Grid size along z, cells. */
    public int nz() { return nz; }
    /** Whether every cell has the reference value. */
    public boolean isUniform() { return offset == null; }
    /** Reference temperature, °C: the uniform value, or the first cell's. */
    public double reference() { return reference; }
    /** Whether this field is for an nx×ny×nz grid. */
    public boolean fits(int nx, int ny, int nz) { return this.nx == nx && this.ny == ny && this.nz == nz; }

    /** Background of a cell by grid index, °C. */
    public double cell(int index) { return offset == null ? reference : reference + offset[index]; }

    /** Background of cell (x, y, z), °C; the reference outside the grid. */
    public double at(int x, int y, int z) {
        if (x < 0 || y < 0 || z < 0 || x >= nx || y >= ny || z >= nz) return reference;
        return cell((y * nz + z) * nx + x);
    }

    /** Mean background over the cells of box b, °C. */
    public double box(BoxGraph3D g, int b) {
        if (offset == null) return reference;
        int x0 = g.boxX0(b), y0 = g.boxY0(b), z0 = g.boxZ0(b);
        int x1 = x0 + g.boxSx(b), y1 = y0 + g.boxSy(b), z1 = z0 + g.boxSz(b);
        double sum = s(x1, y1, z1) - s(x0, y1, z1) - s(x1, y0, z1) - s(x1, y1, z0)
                + s(x0, y0, z1) + s(x0, y1, z0) + s(x1, y0, z0) - s(x0, y0, z0);
        return reference + sum / ((double) g.boxSx(b) * g.boxSy(b) * g.boxSz(b));
    }

    /** Fills out[b] with each box's mean background, °C. */
    public void boxes(BoxGraph3D g, double[] out) {
        if (out.length != g.boxCount()) throw new IllegalArgumentException("expected one value per box");
        for (int b = 0; b < out.length; b++) out[b] = box(g, b);
    }

    private double s(int x, int y, int z) { return sums[(y * (nz + 1) + z) * (nx + 1) + x]; }
}
