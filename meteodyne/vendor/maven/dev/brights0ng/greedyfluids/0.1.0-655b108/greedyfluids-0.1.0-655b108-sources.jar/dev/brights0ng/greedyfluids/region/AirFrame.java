// Written by Claude (M7a).
// Edited by Claude: box extents, for the far distance of a tile border (M8b).
package dev.brights0ng.greedyfluids.region;

import dev.brights0ng.greedyfluids.solve.Background3D;

/**
 * A read-only copy of a region's air at one moment, for queries from other threads (M7a). The air thread makes one
 * with {@link AirRegion#publish} and hands it over through a volatile reference; every field is final and no array
 * is written after construction, so any thread may read it. Temperatures and velocities are per box; the
 * cell-to-box map and the box extents are shared between frames while the mesh is unchanged. Positions are region
 * metres.
 */
public final class AirFrame {
    private final double time;
    private final int nx, ny, nz;
    private final int[] boxOf, extents;
    private final float[] t, u, v, w;
    private final Background3D background;

    AirFrame(double time, int nx, int ny, int nz, int[] boxOf, int[] extents, float[] t, float[] u, float[] v,
            float[] w, Background3D background) {
        this.time = time; this.nx = nx; this.ny = ny; this.nz = nz; this.boxOf = boxOf; this.extents = extents;
        this.t = t; this.u = u; this.v = v; this.w = w; this.background = background;
    }

    /** Simulated time of the frame, s. */
    public double time() { return time; }
    public int nx() { return nx; }
    public int ny() { return ny; }
    public int nz() { return nz; }
    /** The background field in force, °C per cell. */
    public Background3D background() { return background; }

    /** Whether (x, y, z), region metres, is air in this frame. */
    public boolean isAir(double x, double y, double z) { return box(x, y, z) >= 0; }

    /** Air temperature, °C, at a point; the background in solid, the reference outside the grid. */
    public double temperature(double x, double y, double z) {
        int b = box(x, y, z);
        if (b >= 0) return t[b];
        return background.at((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
    }

    /** The extent of the point's box along an axis (0 x, 1 y, 2 z), cells (= m); 0 in solid or outside (M8b). */
    public int extent(double x, double y, double z, int axis) {
        int b = box(x, y, z);
        return b < 0 ? 0 : extents[3 * b + axis];
    }

    /** Air velocity of the point's box into out[3], m/s; false (out unchanged) in solid or outside. */
    public boolean velocity(double x, double y, double z, double[] out) {
        int b = box(x, y, z);
        if (b < 0) return false;
        out[0] = u[b]; out[1] = v[b]; out[2] = w[b];
        return true;
    }

    private int box(double x, double y, double z) {
        int cx = (int) Math.floor(x), cy = (int) Math.floor(y), cz = (int) Math.floor(z);
        if (cx < 0 || cy < 0 || cz < 0 || cx >= nx || cy >= ny || cz >= nz) return -1;
        return boxOf[(cy * nz + cz) * nx + cx];
    }
}
