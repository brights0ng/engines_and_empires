// Edited by Claude: heat out through EXCHANGE faces (M8b).
// Edited by Claude: clamps counted before the projection (M6d2).
// Edited by ChatGPT: copy per-step box-budget scale and change flag (M3d).
// Edited by ChatGPT: report-only edit wait and HYBRID decision counters (M3c part 4).
// Edited by ChatGPT: report-only remap projection variants (M3c part 2b).
// Edited by ChatGPT: report prep sub-times and edit/indicator remesh scope counts (M3c part 2a).
// Edited by ChatGPT: remove stopgap metrics and account for edit phases and remesh locality (M3c part 1).
// Edited by ChatGPT: report pending edits, placement stopgaps, delay flow proxies and batch costs (M3b).
// Edited by ChatGPT: report edit energy and fallback/application counts separately from the step ledger (M3b).
// Written by Claude.
// Edited by Gemini: add report-only sealed-component and topology-change pressure stats (M3a).
// Edited by Claude: remove pcgToleranceUsed with the TIGHT option (M3a).
// Edited by ChatGPT: remove look-ahead metrics; report and copy indicator evaluation (M2i).
// Edited by ChatGPT: reset and copy look-ahead merge rejection/retry diagnostics (M2h).
// Edited by ChatGPT: remove carriedEdges and its reset/copy code (M2g).
// Edited by ChatGPT: copy and reset report-only remap churn, drift and kinetic-energy proxies (M2f).
// Edited by ChatGPT: report and copy pressure exit and optional true residual (M2f).
// Edited by ChatGPT: allocation-free step-phase timings (M2e).
// Edited by ChatGPT: factor cost and pivot-fix counts, including remap solves (M2d).
// Edited by ChatGPT: copy separate greedy and grading phase times (M2d).
// Edited by ChatGPT: remesh phase and pressure-factor timings (M2d).
// Edited by ChatGPT: deferred-correction Courant cap and singular-gradient statistics (M2c).
// Edited by Claude: box count and the adaptive mesh's remesh statistics (M2a); skipped remeshes (M2b).
// Edited by Claude: pruned to the fields the 3D solver and mesh use, after the 2D removal (M5e3).
// Edited by Claude: indicator and solver-build timers for profiling (M5f).
// Edited by ChatGPT from Claude's M6a spec.
// Edited by ChatGPT from Claude's M6b1 spec.
package dev.brights0ng.greedyfluids.solve;

/**
 * Statistics of the last {@link BoxSolver3D#step()}. Owned and overwritten by the solver each step (so stepping
 * allocates nothing); copy the values if you need to keep them.
 */
public final class StepStats {
    /** Edit heat change since the previous step, J; excluded from the per-step residual. */
    public double editEnergy;
    /** Edit applications and fallback air/block cell counts since the previous step (report-only). */
    public int editApplications, editFallbackAirCells, editFallbackBlocks;
    /** Remap projection wall time, ms; included in remapMs. */
    public double remapProjectMs;
    /** Step-phase wall times, ms. pcgMs is nested inside projectMs; otherMs excludes remeshMs. */
    public double advectMs, dampBuoyMs, projectMs, pcgMs, gradientMs, heatMs, otherMs;
    /** Pressure solve iterations. */
    public int pcgIterations;
    /** Scaled initial/final pressure residuals (1/s), and initial remap residual (NaN without remap). */
    public double pcgInitialResidual = Double.NaN, pcgFinalResidual = Double.NaN, remapPcgInitialResidual = Double.NaN;
    /** First PCG iteration below 1e-4, 1e-5 and 1e-6 1/s; −1 if never, 0 if initially below. */
    public int pcgItBelow4 = -1, pcgItBelow5 = -1, pcgItBelow6 = -1;
    /** Max |net flux / volume| after the projection, 1/s. */
    public double maxDivergence;
    /** Heat solve Gauss–Seidel sweeps. */
    public int thermalSweeps;
    /** |ΔE − (sources − ambient loss − boundary advection)| relative to the step's gross energy terms. */
    public double energyResidual;
    /** Max |normal edge velocity| after the projection, m/s; may exceed the cap. */
    public double maxSpeed;
    /** Edges clamped to the speed cap before this step's projection (BoxSolver3D.speedCap). */
    public int clamps;
    /** Wall-clock time of the step, ms. */
    public double ms;
    /** Energy budget terms of the step, J: sources, loss to ambient (walls, eddy at open edges), net advection out. */
    public double sourceEnergy;
    public double ambientLoss;
    public double advectedOut;
    /** Heat out through EXCHANGE faces to their far sides over the step, J (M8b). */
    public double exchangeOut;
    /** Change in stored heat (relative to 0 °C) over the step, J. */
    public double deltaEnergy;
    /** Boxes after the step. */
    public int boxes;
    /** Singular/near-singular gradient boxes in the mesh on which the heat step ran, boxes. */
    public int singularGradientBoxes;
    /** Fraction of interior (including zero-flux) and open-outflow transport edges with beta < 1, dimensionless. */
    public double correctionLimitedFraction;
    /** Mean Courant correction factor over those edges, dimensionless; 1 if there are none. */
    public double meanCorrectionBeta = 1;
    /** True if refinement indicators were evaluated this step. */
    public boolean indicatorsEvaluated;
    /** True if the step ended with a remesh that changed the boxes. */
    public boolean remeshed;
    /** Boxes whose cell limits were lowered this step (split requests). */
    public int splits;
    /** Boxes with at least one cell whose limits were raised this step (merge permissions). */
    public int merges;
    /** Wall-clock time of the remesh (mesher, remap and projection), ms. */
    public double remeshMs;
    /** Remesh phase wall times, ms; their sum is remeshMs. meshMs includes the box graph build. */
    public double rasterMs, meshMs, remapMs;
    /** Replacement solver construction inside remapMs (state, operators, pressure pattern), ms. */
    public double solverBuildMs;
    /** Adaptive cadence work outside the remesh: indicator evaluation and limit updates, ms; excluded from otherMs. */
    public double indicatorMs;
    /** Pressure preconditioner factor time, ms, including remap projection; zero for Jacobi. */
    public double pcgFactorMs;
    /** IC(0) pivot fixes this step, including remap projection (count). */
    public int pcgPivotFixes;
    /** Max |(b − A · phi)_i / volume_i| after the pressure solve, 1/s; NaN when checking is off. */
    public double pcgTrueResidual = Double.NaN;
    /** Sealed connected components in the last pressure solve (count). */
    public int sealedComponents;
    /** Total fluid volume of sealed components in the last pressure solve, m³. */
    public int sealedVolume;
    /** Inflow pockets opened by rule (a), count. */
    public int pocketCount;
    /** Total pocket fluid volume, m³ (integer unit cells). */
    public int pocketVolume;
    /** Declared-INFLOW faces currently opened by the pocket rule, count. */
    public int openedInflowFaces;
    /** INFLOW side-wall faces declared OPEN by the roofed-inflow rule, count. */
    public int roofedInflowFaces;
    /** Total declared inflow into pockets, m³/s. */
    public double pocketInflow;
    /** Maximum declared inflow / OPEN area over non-pocket components, m/s; 0 if none. */
    public double maxOutflowSpeed;
    /** Max over sealed components of |volume-weighted mean phi| after the pressure solve, m²/s; 0 if none. */
    public double maxSealedMeanPhi;
    /** Max over sealed components of |Σ rhs| / Σ |rhs| in the pressure solve, dimensionless; 0 if none or Σ |rhs| = 0. */
    public double maxSealedRhsImbalance;
    /** True if the last step's pressure solve followed a flow-topology change. */
    public boolean topologyChanged;
    /** Max |net flux / volume| immediately after an indicator remap, 1/s; NaN without a remap. */
    public double divergenceAfterRemap = Double.NaN;
    /** PCG iterations of the projection after the remap. */
    public int remapPcgIterations;
    /** 1 if this was a merge-cadence step whose remesh was skipped (no limit changed), else 0. */
    public int skippedRemeshes;
    /** New boxes whose x0, y0, width or height changed, and new boxes with identical old geometry (counts). */
    public int changedBoxes, unchangedBoxes;
    public Pcg.Exit pcgExit;

    /** Copies every field from o. */
    public void copyFrom(StepStats o) {
        editEnergy = o.editEnergy;
        editApplications = o.editApplications;
        editFallbackAirCells = o.editFallbackAirCells;
        editFallbackBlocks = o.editFallbackBlocks;
        remapProjectMs = o.remapProjectMs;
        advectMs = o.advectMs;
        dampBuoyMs = o.dampBuoyMs;
        projectMs = o.projectMs;
        pcgMs = o.pcgMs;
        gradientMs = o.gradientMs;
        heatMs = o.heatMs;
        otherMs = o.otherMs;
        pcgIterations = o.pcgIterations;
        pcgInitialResidual = o.pcgInitialResidual;
        pcgFinalResidual = o.pcgFinalResidual;
        remapPcgInitialResidual = o.remapPcgInitialResidual;
        pcgItBelow4 = o.pcgItBelow4;
        pcgItBelow5 = o.pcgItBelow5;
        pcgItBelow6 = o.pcgItBelow6;
        maxDivergence = o.maxDivergence;
        thermalSweeps = o.thermalSweeps;
        energyResidual = o.energyResidual;
        maxSpeed = o.maxSpeed;
        clamps = o.clamps;
        ms = o.ms;
        sourceEnergy = o.sourceEnergy;
        ambientLoss = o.ambientLoss;
        advectedOut = o.advectedOut;
        exchangeOut = o.exchangeOut;
        deltaEnergy = o.deltaEnergy;
        boxes = o.boxes;
        singularGradientBoxes = o.singularGradientBoxes;
        correctionLimitedFraction = o.correctionLimitedFraction;
        meanCorrectionBeta = o.meanCorrectionBeta;
        indicatorsEvaluated = o.indicatorsEvaluated;
        remeshed = o.remeshed;
        splits = o.splits;
        merges = o.merges;
        remeshMs = o.remeshMs;
        rasterMs = o.rasterMs;
        meshMs = o.meshMs;
        remapMs = o.remapMs;
        solverBuildMs = o.solverBuildMs;
        indicatorMs = o.indicatorMs;
        pcgFactorMs = o.pcgFactorMs;
        pcgPivotFixes = o.pcgPivotFixes;
        pcgTrueResidual = o.pcgTrueResidual;
        sealedComponents = o.sealedComponents;
        sealedVolume = o.sealedVolume;
        pocketCount = o.pocketCount;
        pocketVolume = o.pocketVolume;
        openedInflowFaces = o.openedInflowFaces;
        roofedInflowFaces = o.roofedInflowFaces;
        pocketInflow = o.pocketInflow;
        maxOutflowSpeed = o.maxOutflowSpeed;
        maxSealedMeanPhi = o.maxSealedMeanPhi;
        maxSealedRhsImbalance = o.maxSealedRhsImbalance;
        topologyChanged = o.topologyChanged;
        divergenceAfterRemap = o.divergenceAfterRemap;
        remapPcgIterations = o.remapPcgIterations;
        skippedRemeshes = o.skippedRemeshes;
        changedBoxes = o.changedBoxes;
        unchangedBoxes = o.unchangedBoxes;
        pcgExit = o.pcgExit;
    }
}
