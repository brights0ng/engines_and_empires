// Written by ChatGPT from Claude's M5b spec.
// Edited by Claude: sub-stepped backtraces sized by distance to solids; leaving the domain takes the background
// wind (M6d2).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D.BoundaryKind;

/**
 * Semi-Lagrangian RK2 transport of normal velocities (m/s). A face whose own normal speed carries it more than
 * {@link #MIN_STEP} in dt is traced in RK2 steps of max(MIN_STEP, distance to the nearest solid − 1) m, so it follows
 * curved streamlines near solids and crosses open air in few steps; any other face takes one RK2 step over dt, as
 * before M6d2. (Sizing the test by the full velocity instead gave the same S14-wind accuracy at 15 m/s for about 10 %
 * more step cost; M6d2 container check.) A path that
 * leaves the domain through an OPEN or INFLOW side takes the background wind component (air entering from outside).
 * One that enters a solid or leaves through a CLOSED side stops at its last fluid point, and one stopped before its
 * first step keeps the face's own velocity.
 */
final class Advection3D {
    /** Shortest sub-step, m: one cell, so a path samples at least every half cell and cannot step over a wall. */
    static final double MIN_STEP = 1.0;
    /** Sub-step bound per backtrace (reached only above about 2 × MAX_STEPS m/s at dt 0.5 s): the path stops there. */
    static final int MAX_STEPS = 64;
    private final BoxGraph3D g;
    private final Reconstruction3D reconstruction;
    private final SolidDistance3D distance;
    private final double dt;
    private final double[][] facePoint, boundaryPoint;
    private final double[] next, boundaryNext, sample;
    /** Per domain side (CellGrid3D.Side order): whether air can enter through it (it has boundary faces). */
    private final boolean[] openSide = new boolean[6];
    Advection3D(BoxGraph3D graph, SolverConfig3D config, Reconstruction3D reconstruction, SolidDistance3D distance) {
        g = graph; dt = config.dt(); this.reconstruction = reconstruction; this.distance = distance;
        for (int k = 0; k < g.boundaryCount(); k++) openSide[2 * g.boundaryAxis(k) + g.boundarySide(k)] = true;
        next = new double[g.faceCount()]; boundaryNext = new double[g.boundaryCount()]; sample = new double[3];
        facePoint = new double[g.faceCount()][3]; boundaryPoint = new double[g.boundaryCount()][3];
        for (int f = 0; f < g.faceCount(); f++)
            point(facePoint[f], g.faceAxis(f), Reconstruction3D.low(g, g.faceB(f), g.faceAxis(f)),
                    0.5 * (g.faceU0(f) + g.faceU1(f)), 0.5 * (g.faceV0(f) + g.faceV1(f)));
        for (int k = 0; k < g.boundaryCount(); k++) {
            int b = g.boundaryBox(k), axis = g.boundaryAxis(k);
            point(boundaryPoint[k], axis, Reconstruction3D.low(g, b, axis)
                            + g.boundarySide(k) * Reconstruction3D.extent(g, b, axis),
                    0.5 * (g.boundaryU0(k) + g.boundaryU1(k)), 0.5 * (g.boundaryV0(k) + g.boundaryV1(k)));
        }
    }
    void advect(FlowState3D s) {
        for (int f = 0; f < next.length; f++) next[f] = backtrace(facePoint[f], g.faceAxis(f), s.u[f], s.uBg[f]);
        for (int k = 0; k < boundaryNext.length; k++) boundaryNext[k] = g.boundaryKind(k) == BoundaryKind.OPEN
                ? backtrace(boundaryPoint[k], g.boundaryAxis(k), s.ub[k], s.ubBg[k]) : s.ub[k];
        System.arraycopy(next, 0, s.u, 0, next.length);
        System.arraycopy(boundaryNext, 0, s.ub, 0, boundaryNext.length);
    }
    private double backtrace(double[] p, int axis, double own, double background) {
        double x = p[0], y = p[1], z = p[2], left = dt;
        boolean moved = false, single = Math.abs(own) * dt <= MIN_STEP;
        for (int steps = 0; left > 0 && steps < MAX_STEPS; steps++) {
            if (!reconstruction.sample(x, y, z, sample)) break;
            double speed = Math.sqrt(sample[0] * sample[0] + sample[1] * sample[1] + sample[2] * sample[2]);
            if (speed == 0) break;
            double h = single ? left : Math.min(left, Math.max(MIN_STEP, distance.at(x, y, z) - 1.0) / speed);
            double mx = x - 0.5 * h * sample[0], my = y - 0.5 * h * sample[1], mz = z - 0.5 * h * sample[2];
            int exit = exit(mx, my, mz);
            if (exit == ENTERS) return background;
            if (exit == BLOCKED || !reconstruction.sample(mx, my, mz, sample)) break;
            double dx = x - h * sample[0], dy = y - h * sample[1], dz = z - h * sample[2];
            exit = exit(dx, dy, dz);
            if (exit == ENTERS) return background;
            if (exit == BLOCKED || g.boxAt(dx, dy, dz) < 0) break;
            x = dx; y = dy; z = dz; left -= h; moved = true;
        }
        if (!moved || !reconstruction.sample(x, y, z, sample)) return own;
        return sample[axis];
    }
    private static final int INSIDE = 0, ENTERS = 1, BLOCKED = 2;
    /** INSIDE the domain; outside only past sides air can enter through (ENTERS); or past a CLOSED side (BLOCKED). */
    private int exit(double x, double y, double z) {
        if (x >= 0 && y >= 0 && z >= 0 && x <= g.nx() && y <= g.ny() && z <= g.nz()) return INSIDE;
        if ((x < 0 && !openSide[0]) || (x > g.nx() && !openSide[1]) || (y < 0 && !openSide[2])
                || (y > g.ny() && !openSide[3]) || (z < 0 && !openSide[4]) || (z > g.nz() && !openSide[5]))
            return BLOCKED;
        return ENTERS;
    }
    static void point(double[] out, int axis, double normal, double u, double v) {
        out[0] = axis == 0 ? normal : u;
        out[1] = axis == 1 ? normal : axis == 0 ? u : v;
        out[2] = axis == 2 ? normal : v;
    }
}
