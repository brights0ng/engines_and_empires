// Edited by Claude: coarsest-level rows without couplings solved on the diagonal, outside the dense factor and its 512-row cap;
//   stalled pairwise coarsening above the cap absorbs singletons into their strongest neighbour's aggregate (M5f).
// Edited by ChatGPT: Bright's fused zero-start sweep and upper-only residual (M3.5 part b1).
// Written by ChatGPT: Bright's aggregation/Galerkin design, including Claude's null-scale rule (M3.5).
package dev.brights0ng.greedyfluids.solve;

import java.util.Arrays;

/**
 * Symmetric aggregation V-cycle. Coordinates are metres; matrices and summed finest-diagonal scales
 * have the input operator's units. Residuals have RHS units; corrections have solution units.
 * Setup owns all allocation; apply reuses primitive work arrays and is not reentrant.
 */
final class AggregationMg {
    private static final double NULL_RATIO = 1e-10;
    private final MgSettings settings;
    private Level[] levels;
    boolean fusedKernel = true; // Tests may select the a1 reference kernel.

    private static final class Level {
        final int n;
        final int[] ptr, cols, diag;
        final double[] a, scale, rhs, correction, residual;
        final boolean[] active;
        double[] x, y, cholesky, isolatedRoot;
        boolean[] nullPivot;
        int[] coupled;
        int[] agg;

        Level(int[] ptr, int[] cols, double[] a, double[] scale, boolean finest) {
            this.n = ptr.length - 1;
            this.ptr = ptr;
            this.cols = cols;
            this.a = a;
            this.scale = scale;
            diag = new int[n];
            active = new boolean[n];
            rhs = new double[n];
            correction = new double[n];
            residual = new double[n];
            for (int i = 0; i < n; i++) {
                diag[i] = Arrays.binarySearch(cols, ptr[i], ptr[i + 1], i);
                double d = a[diag[i]];
                if (finest) scale[i] = d;
                active[i] = finest ? d > 0 : d > NULL_RATIO * scale[i];
            }
        }
    }

    AggregationMg(MgSettings settings) { this.settings = settings; }

    /** Builds from sorted CSR; x/y are metres and may be null for pairwise aggregation. */
    void setup(int[] rowPtr, int[] cols, double[] values, double[] x, double[] y) {
        if (settings.aggregation() == MgSettings.Aggregation.GEOMETRIC && (x == null || y == null)) {
            throw new IllegalStateException("geometric aggregation requires coordinates in metres");
        }
        Level current = new Level(rowPtr.clone(), cols.clone(), values.clone(), new double[rowPtr.length - 1], true);
        current.x = x;
        current.y = y;
        Level[] built = new Level[32];
        int count = 0, exponent = 1;
        while (true) {
            if (count == built.length) built = Arrays.copyOf(built, count * 2);
            built[count++] = current;
            if (current.n <= settings.coarsestMax()) break;
            int[] map;
            int aggregates;
            if (settings.aggregation() == MgSettings.Aggregation.PAIRWISE) {
                int[] first = pairwise(current);
                Level middle = galerkin(current, first);
                int[] second = pairwise(middle);
                map = new int[current.n];
                for (int i = 0; i < map.length; i++) map[i] = first[i] < 0 ? -1 : second[first[i]];
                aggregates = aggregateCount(map);
                if (aggregates > 0.9 * current.n && current.n > 512) aggregates = absorbSingletons(current, map);
                if (aggregates > 0.9 * current.n) break;
            } else {
                map = null;
                aggregates = current.n;
                while (exponent <= 30) {
                    map = geometric(current, Math.scalb(1.0, exponent++));
                    aggregates = aggregateCount(map);
                    if (aggregates <= 0.8 * current.n) break;
                }
                if (aggregates > 0.8 * current.n) break;
            }
            current.agg = map;
            Level coarse = galerkin(current, map);
            if (settings.aggregation() == MgSettings.Aggregation.GEOMETRIC) {
                coarse.x = new double[aggregates];
                coarse.y = new double[aggregates];
                int[] members = new int[aggregates];
                for (int i = 0; i < current.n; i++) if (map[i] >= 0) {
                    int a = map[i];
                    coarse.x[a] += current.x[i];
                    coarse.y[a] += current.y[i];
                    members[a]++;
                }
                for (int i = 0; i < aggregates; i++) {
                    coarse.x[i] /= members[i];
                    coarse.y[i] /= members[i];
                }
            }
            current = coarse;
        }
        levels = Arrays.copyOf(built, count);
        factor(current);
    }

    /**
     * Stalled pairwise coarsening (star-shaped coarse graphs: one large air region weakly linked to many pockets,
     * whose leaves can pair with the hub only once). Each active singleton aggregate joins the aggregate of its
     * most strongly coupled active neighbour; aggregates are then renumbered in first-use order. Used only above
     * the dense cap, where setup would otherwise fail, so every hierarchy that built before is unchanged.
     * Returns the new aggregate count.
     */
    private static int absorbSingletons(Level l, int[] map) {
        int[] size = new int[aggregateCount(map)];
        for (int a : map) if (a >= 0) size[a]++;
        int[] target = map.clone();
        for (int i = 0; i < l.n; i++) {
            if (map[i] < 0 || size[map[i]] != 1) continue;
            int best = -1; double strength = 0;
            for (int k = l.ptr[i]; k < l.ptr[i + 1]; k++) {
                int j = l.cols[k];
                double c = -l.a[k];
                if (j != i && l.active[j] && map[j] >= 0 && size[map[j]] > 1 && c > strength) { best = j; strength = c; }
            }
            if (best >= 0) target[i] = map[best];
        }
        int[] renumber = new int[size.length];
        Arrays.fill(renumber, -1);
        int next = 0;
        for (int i = 0; i < l.n; i++) if (target[i] >= 0) {
            if (renumber[target[i]] < 0) renumber[target[i]] = next++;
            map[i] = renumber[target[i]];
        }
        return next;
    }

    private static int aggregateCount(int[] map) {
        int n = 0;
        for (int a : map) n = Math.max(n, a + 1);
        return n;
    }

    private static int[] pairwise(Level l) {
        int[] map = new int[l.n];
        Arrays.fill(map, -1);
        int next = 0;
        for (int i = 0; i < l.n; i++) if (l.active[i] && map[i] < 0) {
            double max = 0;
            for (int k = l.ptr[i]; k < l.ptr[i + 1]; k++) if (l.cols[k] != i) max = Math.max(max, -l.a[k]);
            int best = -1;
            double strength = 0;
            for (int k = l.ptr[i]; k < l.ptr[i + 1]; k++) {
                int j = l.cols[k];
                double c = Math.max(0, -l.a[k]);
                if (j != i && l.active[j] && map[j] < 0 && c > 0 && c >= 0.25 * max
                        && (c > strength || c == strength && j < best)) {
                    best = j;
                    strength = c;
                }
            }
            map[i] = next;
            if (best >= 0) map[best] = next;
            next++;
        }
        return map;
    }

    private static int[] geometric(Level l, double block) {
        int[] map = new int[l.n], stack = new int[l.n];
        double[] keyX = new double[l.n], keyY = new double[l.n];
        Arrays.fill(map, -1);
        for (int i = 0; i < l.n; i++) {
            keyX[i] = Math.floor(l.x[i] / block);
            keyY[i] = Math.floor(l.y[i] / block);
        }
        int next = 0;
        for (int i = 0; i < l.n; i++) if (l.active[i] && map[i] < 0) {
            int size = 0;
            stack[size++] = i;
            map[i] = next;
            while (size > 0) {
                int node = stack[--size];
                for (int k = l.ptr[node]; k < l.ptr[node + 1]; k++) {
                    int j = l.cols[k];
                    if (j != node && l.a[k] < 0 && l.active[j] && map[j] < 0
                            && keyX[j] == keyX[i] && keyY[j] == keyY[i]) {
                        map[j] = next;
                        stack[size++] = j;
                    }
                }
            }
            next++;
        }
        return map;
    }

    /** Sparse assembly: group fine rows, sum in their CSR order, then sort each coarse row. */
    private static Level galerkin(Level fine, int[] map) {
        int n = aggregateCount(map);
        int[] ptr = new int[n + 1];
        double[] scale = new double[n];
        // Group fine rows by aggregate, preserving their index order for deterministic sums.
        for (int a : map) if (a >= 0) ptr[a + 1]++;
        for (int i = 0; i < n; i++) ptr[i + 1] += ptr[i];
        int[] members = new int[ptr[n]], fill = ptr.clone();
        for (int i = 0; i < fine.n; i++) if (map[i] >= 0) {
            members[fill[map[i]]++] = i;
            scale[map[i]] += fine.scale[i];
        }
        int[] outPtr = new int[n + 1], outCols = new int[fine.a.length + n];
        double[] outValues = new double[outCols.length], sums = new double[n];
        boolean[] touched = new boolean[n];
        int[] columns = new int[n];
        int at = 0;
        for (int row = 0; row < n; row++) {
            int used = 1;
            columns[0] = row;
            touched[row] = true;
            for (int m = ptr[row]; m < ptr[row + 1]; m++) {
                int i = members[m];
                for (int k = fine.ptr[i]; k < fine.ptr[i + 1]; k++) {
                    int j = map[fine.cols[k]];
                    if (j < 0) continue;
                    if (!touched[j]) { touched[j] = true; columns[used++] = j; }
                    sums[j] += fine.a[k];
                }
            }
            Arrays.sort(columns, 0, used);
            for (int k = 0; k < used; k++) {
                int j = columns[k];
                if (j == row || sums[j] != 0) {
                    outCols[at] = j;
                    outValues[at++] = sums[j];
                }
                touched[j] = false;
                sums[j] = 0;
            }
            outPtr[row + 1] = at;
        }
        return new Level(outPtr, Arrays.copyOf(outCols, at), Arrays.copyOf(outValues, at), scale, false);
    }

    /**
     * Dense Cholesky of the coarsest level's coupled rows. Rows without off-diagonal couplings (sealed pockets
     * that aggregation cannot merge) are solved on the diagonal instead, so real terrain with many pockets does
     * not hit the dense cap; on rows with couplings the factor equals the full one, because uncoupled rows add
     * only zero entries.
     */
    private void factor(Level l) {
        int n = l.n, m = 0;
        int[] coupled = new int[n];
        l.nullPivot = new boolean[n];
        l.isolatedRoot = new double[n];
        for (int i = 0; i < n; i++) {
            boolean couples = false;
            for (int k = l.ptr[i]; k < l.ptr[i + 1]; k++) if (l.cols[k] != i && l.a[k] != 0) { couples = true; break; }
            if (couples) { coupled[m++] = i; continue; }
            double d = l.a[l.diag[i]];
            if (!l.active[i] || d <= NULL_RATIO * l.scale[i]) l.nullPivot[i] = true;
            else l.isolatedRoot[i] = Math.sqrt(d);
        }
        if (m > 512) throw new IllegalStateException("MG coarsest has " + m + " coupled rows (cap 512): "
                + Arrays.toString(levelSizes()));
        l.coupled = Arrays.copyOf(coupled, m);
        int[] local = new int[n];
        Arrays.fill(local, -1);
        for (int r = 0; r < m; r++) local[l.coupled[r]] = r;
        double[] f = l.cholesky = new double[m * m];
        for (int r = 0; r < m; r++) {
            int i = l.coupled[r];
            for (int k = l.ptr[i]; k < l.ptr[i + 1]; k++) if (local[l.cols[k]] >= 0) f[r * m + local[l.cols[k]]] = l.a[k];
        }
        for (int k = 0; k < m; k++) {
            int row = l.coupled[k];
            double pivot = f[k * m + k];
            for (int j = 0; j < k; j++) pivot -= f[k * m + j] * f[k * m + j];
            if (!l.active[row] || pivot <= NULL_RATIO * l.scale[row]) {
                l.nullPivot[row] = true;
                for (int j = 0; j < m; j++) { f[k * m + j] = 0; f[j * m + k] = 0; }
                continue;
            }
            f[k * m + k] = Math.sqrt(pivot);
            for (int i = k + 1; i < m; i++) {
                double a = f[i * m + k];
                for (int j = 0; j < k; j++) a -= f[i * m + j] * f[k * m + j];
                f[i * m + k] = a / f[k * m + k];
            }
        }
    }

    void apply(double[] r, double[] z) { cycle(0, r, z); }

    private void cycle(int index, double[] b, double[] x) {
        Level l = levels[index];
        Arrays.fill(x, 0);
        if (index == levels.length - 1) {
            int n = l.n, m = l.coupled.length;
            int[] c = l.coupled;
            for (int i = 0; i < n; i++) if (l.isolatedRoot[i] > 0) x[i] = b[i] / l.isolatedRoot[i] / l.isolatedRoot[i];
            for (int r = 0; r < m; r++) {
                if (l.nullPivot[c[r]]) continue;
                double sum = b[c[r]];
                for (int j = 0; j < r; j++) sum -= l.cholesky[r * m + j] * x[c[j]];
                x[c[r]] = sum / l.cholesky[r * m + r];
            }
            for (int r = m - 1; r >= 0; r--) {
                if (l.nullPivot[c[r]]) continue;
                double sum = x[c[r]];
                for (int j = r + 1; j < m; j++) sum -= l.cholesky[j * m + r] * x[c[j]];
                x[c[r]] = sum / l.cholesky[r * m + r];
            }
            return;
        }
        if (fusedKernel) {
            // Sorted rows and zero-start x leave only the lower triangle in the first sweep.
            for (int i = 0; i < l.n; i++) if (l.active[i]) {
                double sum = 0;
                for (int k = l.ptr[i]; k < l.diag[i]; k++) sum += l.a[k] * x[l.cols[k]];
                x[i] = (b[i] - sum) / l.a[l.diag[i]];
            }
            for (int s = 1; s < settings.sweeps(); s++) smooth(l, b, x, true);
        } else {
            for (int s = 0; s < settings.sweeps(); s++) smooth(l, b, x, true);
        }
        Level coarse = levels[index + 1];
        Arrays.fill(coarse.rhs, 0);
        if (fusedKernel && settings.sweeps() == 1) {
            // The first forward sweep satisfies (D + L)x = b; restrict r = -Ux.
            for (int i = 0; i < l.n; i++) if (l.agg[i] >= 0) {
                double sum = 0;
                for (int k = l.diag[i] + 1; k < l.ptr[i + 1]; k++) sum += l.a[k] * x[l.cols[k]];
                l.residual[i] = -sum;
                coarse.rhs[l.agg[i]] += l.residual[i];
            }
        } else {
            for (int i = 0; i < l.n; i++) {
                double sum = 0;
                for (int k = l.ptr[i]; k < l.ptr[i + 1]; k++) sum += l.a[k] * x[l.cols[k]];
                l.residual[i] = b[i] - sum;
                if (l.agg[i] >= 0) coarse.rhs[l.agg[i]] += l.residual[i];
            }
        }
        cycle(index + 1, coarse.rhs, coarse.correction);
        for (int i = 0; i < l.n; i++) if (l.agg[i] >= 0) x[i] += settings.coarseScale() * coarse.correction[l.agg[i]];
        for (int s = 0; s < settings.sweeps(); s++) smooth(l, b, x, false);
    }

    private static void smooth(Level l, double[] b, double[] x, boolean forward) {
        for (int row = 0; row < l.n; row++) {
            int i = forward ? row : l.n - 1 - row;
            if (!l.active[i]) continue;
            double sum = 0;
            for (int k = l.ptr[i]; k < l.ptr[i + 1]; k++) sum += l.a[k] * x[l.cols[k]];
            x[i] += (b[i] - sum) / l.a[l.diag[i]];
        }
    }

    int[] levelSizes() {
        int[] result = new int[levels.length];
        for (int i = 0; i < result.length; i++) result[i] = levels[i].n;
        return result;
    }

    int[] levelNnz() {
        int[] result = new int[levels.length];
        for (int i = 0; i < result.length; i++) result[i] = levels[i].a.length;
        return result;
    }

    int[] firstLevelAggregates() { return levels.length == 1 ? new int[0] : levels[0].agg.clone(); }
}
