// Written by Claude.
// Edited by ChatGPT: default refinement to M32-S8-h16 after M2j (Bright, 2026-10-30).
// Edited by ChatGPT: remove residual-fraction and look-ahead options; add split cadence (M2i).
// Edited by ChatGPT: configurable merge residual fraction and opt-in look-ahead merge guard (M2h).
// Edited by ChatGPT: remove carryUnchanged and its compatibility constructor (M2g).
// Edited by ChatGPT: opt-in exact state carry for unchanged boxes (M2f).
// Edited by ChatGPT: k = 2 default thresholds for the M2c cost-lever confirmation.
package dev.brights0ng.greedyfluids.refine;

/**
 * Thresholds and timing of the dynamic refinement ({@link Indicators}, {@link AdaptiveMesh}). {@link #DEFAULT} holds
 * the M32-S8-h16 values decided by Bright on 2026-10-30 after M2j: indicators and splits every 8 steps
 * (4 s), merges every 32 steps (16 s), and a hold of 16 steps (8 s). Edits remesh immediately and locally.
 *
 * @param epsT         temperature face-jump indicator threshold ε_T, °C
 * @param epsU         velocity face-jump indicator threshold ε_u, m/s
 * @param epsS         unstable-layering threshold ε_s (warmer below than above across a box), °C
 * @param holdSteps    steps every indicator must stay below half its threshold before a cell may coarsen
 * @param mergeCadence coarsening runs every this many steps
 * @param maxExtent    largest allowed box extent per axis, cells (limits start here and never exceed it)
 * @param splitCadence indicators are evaluated, and splits applied, every splitCadence steps;
 *                     merge-cadence steps also evaluate indicators and apply splits
 */
public record RefineSettings(double epsT, double epsU, double epsS, int holdSteps, int mergeCadence, int maxExtent,
        int splitCadence) {
    public static final RefineSettings DEFAULT = new RefineSettings(2.0, 0.5, 0.6, 16, 32, 16, 8);

    /** Existing constructor evaluates indicators and applies splits every step. */
    public RefineSettings(double epsT, double epsU, double epsS, int holdSteps, int mergeCadence, int maxExtent) {
        this(epsT, epsU, epsS, holdSteps, mergeCadence, maxExtent, 1);
    }

    public RefineSettings {
        if (splitCadence < 1) {
            throw new IllegalArgumentException("splitCadence must be positive");
        }
        if (holdSteps < 1 || mergeCadence < 1 || maxExtent < 1) {
            throw new IllegalArgumentException("holdSteps, mergeCadence and maxExtent must be positive");
        }
    }
}
