// Written by ChatGPT from Claude's M5b spec.
// Edited by Claude: graph accessor for one shared instance per graph (M6c1).
// Edited by Claude: per-box gradient and limit, bitwise equal to the whole-graph passes (M6c3).
// Edited by Claude: closed-form inverse for well-conditioned boxes; pseudoinverses in one flat array (M6e1).
// Edited by Claude: limit point offsets precomputed (M6e3).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import java.util.Arrays;

/**
 * Allocation-free weighted least squares and Barth–Jespersen limiting, using all interior faces
 * regardless of aperture. Weight is face area (m²) / squared centre distance (m²).
 * A symmetric normal matrix is pseudoinverted once, dropping eigenpairs below 1e-9 times its
 * largest eigenvalue. Dropped directions have zero gradient. Singularity means retained rank
 * below the domain dimension (number of axes with more than one cell), generalising 2D's
 * det/trace² rule, the 2D grid being a domain with D = 2.
 * <p>A well-conditioned matrix (det ≥ {@link #CLOSED_FORM_FLOOR} · trace³, which bounds its smallest eigenvalue
 * below by that fraction of its largest, so no eigenpair is dropped) is inverted in closed form by cofactors; the
 * rest, the rank-deficient boxes among them, take the Jacobi eigendecomposition. The two agree to roundoff.
 * Bounds include this box and its interior neighbours; limit points include every unit cell
 * centre and every interior/boundary face rectangle centre. Scratch arrays are reused per call.
 */
public final class BoxGradients3D {
    /** Relative eigenvalue floor, dimensionless. */
    public static final double RELATIVE_EIGEN_FLOOR = 1e-9;
    /**
     * Least det / trace³ (dimensionless) for the closed-form inverse. For a symmetric positive semidefinite 3×3
     * matrix, λmin / λmax ≥ det / trace³, so above this floor every eigenvalue is at least 1e-6 of the largest:
     * far above RELATIVE_EIGEN_FLOOR, and a condition number of at most 1e6 for the cofactor inverse. On meshed
     * builds (M6e1) full-rank boxes measure 8e-5 or more and rank-deficient ones 1e-13 or less.
     */
    public static final double CLOSED_FORM_FLOOR = 1e-6;
    private final BoxGraph3D g;
    private final int n, dimension, singularCount, eigenCount;
    /** Row-major 3×3 pseudoinverse of box i at [9i, 9i + 9), m². */
    private final double[] inverse;
    private final double[][] weights, rhs;
    private final double[] minimum, maximum, factor;
    /** Limit point offsets from box centres, m: per face [6f, 6f + 6) for boxes A then B; then three per boundary. */
    private final double[] limitOffset;
    private final boolean[] singular;

    /** Precomputes geometry (m) and normal pseudoinverses for a fixed graph. */
    public BoxGradients3D(BoxGraph3D graph) {
        g = graph; n = g.boxCount();
        dimension = (g.nx() > 1 ? 1 : 0) + (g.ny() > 1 ? 1 : 0) + (g.nz() > 1 ? 1 : 0);
        inverse = new double[9 * n]; weights = new double[3][g.faceCount()]; rhs = new double[3][n];
        minimum = new double[n]; maximum = new double[n]; factor = new double[n]; singular = new boolean[n];
        // Normal matrices, entry (i, j) = Σ (w·d_i)·d_j over the box's faces in face order.
        for (int f = 0; f < g.faceCount(); f++) {
            int a = 9 * g.faceA(f), b = 9 * g.faceB(f);
            double dx = g.boxCx(g.faceB(f)) - g.boxCx(g.faceA(f)), dy = g.boxCy(g.faceB(f)) - g.boxCy(g.faceA(f)),
                    dz = g.boxCz(g.faceB(f)) - g.boxCz(g.faceA(f));
            double w = g.faceArea(f) / (dx * dx + dy * dy + dz * dz);
            double wx = w * dx, wy = w * dy, wz = w * dz;
            weights[0][f] = wx; weights[1][f] = wy; weights[2][f] = wz;
            double xx = wx * dx, xy = wx * dy, xz = wx * dz, yx = wy * dx, yy = wy * dy, yz = wy * dz,
                    zx = wz * dx, zy = wz * dy, zz = wz * dz;
            inverse[a] += xx; inverse[a + 1] += xy; inverse[a + 2] += xz; inverse[a + 3] += yx; inverse[a + 4] += yy;
            inverse[a + 5] += yz; inverse[a + 6] += zx; inverse[a + 7] += zy; inverse[a + 8] += zz;
            inverse[b] += xx; inverse[b + 1] += xy; inverse[b + 2] += xz; inverse[b + 3] += yx; inverse[b + 4] += yy;
            inverse[b + 5] += yz; inverse[b + 6] += zx; inverse[b + 7] += zy; inverse[b + 8] += zz;
        }
        double[] matrix = new double[9], vectors = new double[9];
        int count = 0, eigen = 0;
        for (int box = 0; box < n; box++) {
            int o = 9 * box;
            // Closed form from the upper triangle [a b c; b d e; c e f]: cofactors over the determinant.
            double a = inverse[o], b = inverse[o + 1], c = inverse[o + 2], d = inverse[o + 4], e = inverse[o + 5],
                    f = inverse[o + 8];
            double ca = d * f - e * e, cb = c * e - b * f, cc = b * e - c * d;
            double det = a * ca + b * cb + c * cc, trace = a + d + f;
            if (trace > 0 && det >= CLOSED_FORM_FLOOR * trace * trace * trace) {
                double cd = a * f - c * c, ce = b * c - a * e, cf = a * d - b * b;
                inverse[o] = ca / det; inverse[o + 1] = inverse[o + 3] = cb / det; inverse[o + 2] = inverse[o + 6] = cc / det;
                inverse[o + 4] = cd / det; inverse[o + 5] = inverse[o + 7] = ce / det; inverse[o + 8] = cf / det;
                singular[box] = 3 < dimension;
                continue;
            }
            eigen++;
            System.arraycopy(inverse, o, matrix, 0, 9);
            Arrays.fill(vectors, 0); vectors[0] = vectors[4] = vectors[8] = 1;
            // Cyclic Jacobi: orthogonal rotations of a real symmetric 3x3 matrix.
            for (int sweep = 0; sweep < 32; sweep++) {
                boolean changed = false;
                for (int p = 0; p < 2; p++) for (int q = p + 1; q < 3; q++) {
                    double apq = matrix[3 * p + q];
                    if (apq == 0) continue;
                    double tau = (matrix[3 * q + q] - matrix[3 * p + p]) / (2 * apq);
                    double t = Math.copySign(1 / (Math.abs(tau) + Math.hypot(1, tau)), tau);
                    if (t == 0) { matrix[3 * p + q] = matrix[3 * q + p] = 0; continue; }
                    double cs = 1 / Math.sqrt(1 + t * t), sn = t * cs;
                    matrix[3 * p + p] -= t * apq; matrix[3 * q + q] += t * apq;
                    matrix[3 * p + q] = matrix[3 * q + p] = 0;
                    for (int r = 0; r < 3; r++) {
                        if (r != p && r != q) {
                            double rp = matrix[3 * r + p], rq = matrix[3 * r + q];
                            matrix[3 * r + p] = matrix[3 * p + r] = cs * rp - sn * rq;
                            matrix[3 * r + q] = matrix[3 * q + r] = sn * rp + cs * rq;
                        }
                        double vp = vectors[3 * r + p], vq = vectors[3 * r + q];
                        vectors[3 * r + p] = cs * vp - sn * vq;
                        vectors[3 * r + q] = sn * vp + cs * vq;
                    }
                    changed = true;
                }
                if (!changed) break;
            }
            double largest = Math.max(matrix[0], Math.max(matrix[4], matrix[8]));
            Arrays.fill(inverse, o, o + 9, 0);
            int rank = 0;
            for (int k = 0; k < 3; k++) {
                double lambda = matrix[4 * k];
                if (lambda <= 0 || lambda < RELATIVE_EIGEN_FLOOR * largest) continue;
                rank++;
                for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++)
                    inverse[o + 3 * i + j] += vectors[3 * i + k] * vectors[3 * j + k] / lambda;
            }
            singular[box] = rank < dimension;
            if (singular[box]) count++;
        }
        singularCount = count; eigenCount = eigen;
        // Limit points relative to box centres: the two boxes of each face centre, then each boundary's box.
        limitOffset = new double[6 * g.faceCount() + 3 * g.boundaryCount()];
        for (int f = 0, k = 0; f < g.faceCount(); f++, k += 6) {
            int a = g.faceA(f), b = g.faceB(f), axis = g.faceAxis(f);
            double normal = axis == 0 ? g.boxX0(b) : axis == 1 ? g.boxY0(b) : g.boxZ0(b);
            double u = 0.5 * (g.faceU0(f) + g.faceU1(f)), v = 0.5 * (g.faceV0(f) + g.faceV1(f));
            double x = axis == 0 ? normal : u, y = axis == 1 ? normal : axis == 0 ? u : v, z = axis == 2 ? normal : v;
            limitOffset[k] = x - g.boxCx(a); limitOffset[k + 1] = y - g.boxCy(a); limitOffset[k + 2] = z - g.boxCz(a);
            limitOffset[k + 3] = x - g.boxCx(b); limitOffset[k + 4] = y - g.boxCy(b); limitOffset[k + 5] = z - g.boxCz(b);
        }
        for (int e = 0, k = 6 * g.faceCount(); e < g.boundaryCount(); e++, k += 3) {
            int i = g.boundaryBox(e), axis = g.boundaryAxis(e), side = g.boundarySide(e);
            double normal = axis == 0 ? g.boxX0(i) + side * g.boxSx(i)
                    : axis == 1 ? g.boxY0(i) + side * g.boxSy(i) : g.boxZ0(i) + side * g.boxSz(i);
            double u = 0.5 * (g.boundaryU0(e) + g.boundaryU1(e)), v = 0.5 * (g.boundaryV0(e) + g.boundaryV1(e));
            double x = axis == 0 ? normal : u, y = axis == 1 ? normal : axis == 0 ? u : v, z = axis == 2 ? normal : v;
            limitOffset[k] = x - g.boxCx(i); limitOffset[k + 1] = y - g.boxCy(i); limitOffset[k + 2] = z - g.boxCz(i);
        }
    }
    /** Boxes pseudoinverted by eigendecomposition instead of the closed form (rank-deficient or ill-conditioned). */
    public int eigenBoxes() { return eigenCount; }
    /** The graph this instance was built for; its gradients may be shared by every user of that graph. */
    public BoxGraph3D graph() { return g; }
    /** Number of axes with domain extent greater than one cell (0..3). */
    public int domainDimension() { return dimension; }
    /** Whether retained rank is below the domain dimension. */
    public boolean singular(int box) { return singular[box]; }
    /** Number of boxes whose retained rank is below domain dimension. */
    public int singularBoxes() { return singularCount; }
    /** Unlimited gradient of q, field units/m, into gx, gy, gz; allocates nothing. */
    public void gradient(double[] q, double[] gx, double[] gy, double[] gz) {
        for (double[] r : rhs) Arrays.fill(r, 0);
        for (int f = 0; f < g.faceCount(); f++) {
            int a = g.faceA(f), b = g.faceB(f);
            double delta = q[b] - q[a];
            for (int i = 0; i < 3; i++) {
                double value = weights[i][f] * delta;
                rhs[i][a] += value; rhs[i][b] += value;
            }
        }
        double[] m = inverse;
        for (int i = 0, o = 0; i < n; i++, o += 9) {
            // Inactive domain axes are unobserved; preserve an exact positive zero there.
            gx[i] = g.nx() == 1 ? 0 : m[o] * rhs[0][i] + m[o + 1] * rhs[1][i] + m[o + 2] * rhs[2][i];
            gy[i] = g.ny() == 1 ? 0 : m[o + 3] * rhs[0][i] + m[o + 4] * rhs[1][i] + m[o + 5] * rhs[2][i];
            gz[i] = g.nz() == 1 ? 0 : m[o + 6] * rhs[0][i] + m[o + 7] * rhs[1][i] + m[o + 8] * rhs[2][i];
        }
    }
    /** Barth–Jespersen limited gradient of q into lx,ly,lz (field units/m); allocates nothing. */
    public void limit(double[] q, double[] gx, double[] gy, double[] gz,
            double[] lx, double[] ly, double[] lz) {
        for (int i = 0; i < n; i++) { minimum[i] = maximum[i] = q[i]; }
        for (int f = 0; f < g.faceCount(); f++) {
            int a = g.faceA(f), b = g.faceB(f);
            minimum[a] = Math.min(minimum[a], q[b]); maximum[a] = Math.max(maximum[a], q[b]);
            minimum[b] = Math.min(minimum[b], q[a]); maximum[b] = Math.max(maximum[b], q[a]);
        }
        for (int i = 0; i < n; i++) {
            double reach = 0.5 * (Math.abs(gx[i]) * (g.boxSx(i) - 1)
                    + Math.abs(gy[i]) * (g.boxSy(i) - 1) + Math.abs(gz[i]) * (g.boxSz(i) - 1));
            factor[i] = reach > 0 ? Math.max(0, Math.min(1,
                    Math.min((maximum[i] - q[i]) / reach, (q[i] - minimum[i]) / reach))) : 1;
        }
        double[] o = limitOffset;
        for (int f = 0, k = 0; f < g.faceCount(); f++, k += 6) {
            limitPoint(g.faceA(f), o[k], o[k + 1], o[k + 2], q, gx, gy, gz);
            limitPoint(g.faceB(f), o[k + 3], o[k + 4], o[k + 5], q, gx, gy, gz);
        }
        for (int e = 0, k = 6 * g.faceCount(); e < g.boundaryCount(); e++, k += 3)
            limitPoint(g.boundaryBox(e), o[k], o[k + 1], o[k + 2], q, gx, gy, gz);
        for (int i = 0; i < n; i++) {
            lx[i] = g.nx() == 1 ? 0 : factor[i] * gx[i];
            ly[i] = g.ny() == 1 ? 0 : factor[i] * gy[i];
            lz[i] = g.nz() == 1 ? 0 : factor[i] * gz[i];
        }
    }
    /**
     * Box i's unlimited gradient into out[0..2], bitwise equal to {@link #gradient}'s value for i: the same face
     * terms summed in the same (ascending face) order from zero. Allocates nothing.
     */
    public void gradientBox(int i, double[] q, double[] out) {
        double r0 = 0, r1 = 0, r2 = 0;
        for (int k = g.facesStart(i); k < g.facesEnd(i); k++) {
            int f = g.faceAt(k);
            double delta = q[g.faceB(f)] - q[g.faceA(f)];
            r0 += weights[0][f] * delta; r1 += weights[1][f] * delta; r2 += weights[2][f] * delta;
        }
        double[] m = inverse;
        int o = 9 * i;
        out[0] = g.nx() == 1 ? 0 : m[o] * r0 + m[o + 1] * r1 + m[o + 2] * r2;
        out[1] = g.ny() == 1 ? 0 : m[o + 3] * r0 + m[o + 4] * r1 + m[o + 5] * r2;
        out[2] = g.nz() == 1 ? 0 : m[o + 6] * r0 + m[o + 7] * r1 + m[o + 8] * r2;
    }
    /**
     * Box i's Barth–Jespersen limited gradient into out[0..2] from its unlimited gradient grad[0..2], bitwise equal
     * to {@link #limit}'s value for i (min/max over the same neighbours; the same face and boundary limits in the
     * same order). Needs only q of i's neighbours, not their gradients. Allocates nothing.
     */
    public void limitBox(int i, double[] q, double[] grad, double[] out) {
        double lo = q[i], hi = q[i];
        for (int k = g.facesStart(i); k < g.facesEnd(i); k++) {
            int f = g.faceAt(k);
            int other = g.faceA(f) == i ? g.faceB(f) : g.faceA(f);
            lo = Math.min(lo, q[other]); hi = Math.max(hi, q[other]);
        }
        double gx = grad[0], gy = grad[1], gz = grad[2];
        double reach = 0.5 * (Math.abs(gx) * (g.boxSx(i) - 1)
                + Math.abs(gy) * (g.boxSy(i) - 1) + Math.abs(gz) * (g.boxSz(i) - 1));
        double fac = reach > 0 ? Math.max(0, Math.min(1, Math.min((hi - q[i]) / reach, (q[i] - lo) / reach))) : 1;
        for (int k = g.facesStart(i); k < g.facesEnd(i); k++) {
            int f = g.faceAt(k), b = g.faceB(f), axis = g.faceAxis(f);
            double normal = axis == 0 ? g.boxX0(b) : axis == 1 ? g.boxY0(b) : g.boxZ0(b);
            double u = 0.5 * (g.faceU0(f) + g.faceU1(f)), v = 0.5 * (g.faceV0(f) + g.faceV1(f));
            fac = limitFactor(fac, i, axis, normal, u, v, q, gx, gy, gz, lo, hi);
        }
        for (int k = g.boundariesStart(i); k < g.boundariesEnd(i); k++) {
            int e = g.boundaryAt(k), axis = g.boundaryAxis(e), side = g.boundarySide(e);
            double normal = axis == 0 ? g.boxX0(i) + side * g.boxSx(i)
                    : axis == 1 ? g.boxY0(i) + side * g.boxSy(i) : g.boxZ0(i) + side * g.boxSz(i);
            fac = limitFactor(fac, i, axis, normal, 0.5 * (g.boundaryU0(e) + g.boundaryU1(e)),
                    0.5 * (g.boundaryV0(e) + g.boundaryV1(e)), q, gx, gy, gz, lo, hi);
        }
        out[0] = g.nx() == 1 ? 0 : fac * gx;
        out[1] = g.ny() == 1 ? 0 : fac * gy;
        out[2] = g.nz() == 1 ? 0 : fac * gz;
    }
    private double limitFactor(double fac, int i, int axis, double normal, double u, double v, double[] q,
            double gx, double gy, double gz, double lo, double hi) {
        double x = axis == 0 ? normal : u;
        double y = axis == 1 ? normal : axis == 0 ? u : v;
        double z = axis == 2 ? normal : v;
        double delta = gx * (x - g.boxCx(i)) + gy * (y - g.boxCy(i)) + gz * (z - g.boxCz(i));
        if (delta > 0) return Math.min(fac, (hi - q[i]) / delta);
        if (delta < 0) return Math.min(fac, (lo - q[i]) / delta);
        return fac;
    }
    /** Limits box i at a point given by its offset (m) from the box centre. */
    private void limitPoint(int i, double dx, double dy, double dz, double[] q, double[] gx, double[] gy, double[] gz) {
        double delta = gx[i] * dx + gy[i] * dy + gz[i] * dz;
        if (delta > 0) factor[i] = Math.min(factor[i], (maximum[i] - q[i]) / delta);
        else if (delta < 0) factor[i] = Math.min(factor[i], (minimum[i] - q[i]) / delta);
    }
}
