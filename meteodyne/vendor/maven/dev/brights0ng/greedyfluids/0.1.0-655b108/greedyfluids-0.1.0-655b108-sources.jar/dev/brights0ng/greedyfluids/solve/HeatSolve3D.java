// Written by ChatGPT from Claude's M5b spec.
// Edited by Claude: gradients accessor for sharing (M6c1).
// Edited by Claude: open boundaries and AMBIENT wall stores relax toward the per-cell background (M7a).
// Edited by Claude: fixed-temperature stores stay put and count as sources in the ledger (M7c).
// Edited by Claude: EXCHANGE faces conduct to their far-side temperatures, across the host's far distance (M8b).
// Edited by Claude: wall couplings refreshed after a fixed wall's change (M8e).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.grid.CellGrid3D.Side;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D.BoundaryKind;

/** Implicit upwind/diffusion heat solve with deferred MUSCL correction and coupled wall stores. */
final class HeatSolve3D {
    private final BoxGraph3D g;
    private final WallStore3D walls;
    private final SolverConfig3D c;
    private final BoxGradients3D gradients;
    private final int[] rows, cols, ab, ba, wallA, wallB, wallRows, wallIds;
    private final double[] values, diagonal, rhs, capacity, previous, previousWall, wallG;
    private final double[] gx, gy, gz, lx, ly, lz;
    // Area/dn geometry stays separate so fractional apertures retain the specified product order.
    private final double[] faceArea, faceDn, boundaryArea;
    // Background temperatures, °C: per boundary (its box's) and per wall store (an AMBIENT store's far side).
    private final double[] boundaryBg, storeBg;
    private final double[][] facePoint, boundaryPoint;
    /** Per EXCHANGE face, half its box's depth along the normal, m: the near half of the centre distance (M8b). */
    private final double[] exchangeHalf;
    /** Far-side temperatures of the EXCHANGE faces; null: all insulated. */
    private ExchangeTemperatures exchange;
    private int betaEdges, betaLimited;
    private double betaSum;

    /**
     * Re-reads the wall stores' couplings into this solve (M8e): after {@link WallStore3D#refreshFixed} changed them,
     * in the order the constructor laid them out.
     */
    void refreshWallCouplings() {
        int[] fill = java.util.Arrays.copyOf(wallRows, wallRows.length - 1);
        for (int i = 0; i < wallA.length; i++) {
            wallG[fill[wallA[i]]++] = walls.gA(i);
            if (wallB[i] >= 0) wallG[fill[wallB[i]]++] = walls.gB(i);
        }
    }

    /** Gradient workspace of this graph; gradient() and limit() keep no state between calls. */
    BoxGradients3D gradients() { return gradients; }

    HeatSolve3D(BoxGraph3D graph, WallStore3D walls, SolverConfig3D config) {
        g = graph; this.walls = walls; c = config;
        int n = g.boxCount(), nf = g.faceCount(), nw = walls.count();
        gradients = new BoxGradients3D(g);
        rows = new int[n + 1];
        for (int i = 0; i < n; i++) rows[i + 1] = rows[i] + g.facesEnd(i) - g.facesStart(i);
        cols = new int[rows[n]]; values = new double[rows[n]];
        int[] fill = rows.clone();
        ab = new int[nf]; ba = new int[nf];
        for (int f = 0; f < nf; f++) {
            int a = g.faceA(f), b = g.faceB(f);
            ab[f] = fill[a]; cols[fill[a]++] = b;
            ba[f] = fill[b]; cols[fill[b]++] = a;
        }
        diagonal = new double[n]; rhs = new double[n]; capacity = new double[n]; previous = new double[n];
        gx = new double[n]; gy = new double[n]; gz = new double[n];
        lx = new double[n]; ly = new double[n]; lz = new double[n];
        for (int i = 0; i < n; i++) capacity[i] = c.rhoCp() * g.boxVolume(i);
        wallA = new int[nw]; wallB = new int[nw]; previousWall = new double[nw]; wallRows = new int[n + 1];
        for (int i = 0; i < nw; i++) {
            wallA[i] = fluidBox(walls.cellA(i));
            wallB[i] = walls.cellB(i) < 0 ? -1 : fluidBox(walls.cellB(i));
            wallRows[wallA[i] + 1]++;
            if (wallB[i] >= 0) wallRows[wallB[i] + 1]++;
        }
        for (int i = 0; i < n; i++) wallRows[i + 1] += wallRows[i];
        wallIds = new int[wallRows[n]]; wallG = new double[wallIds.length];
        System.arraycopy(wallRows, 0, fill, 0, n);
        for (int i = 0; i < nw; i++) {
            int k = fill[wallA[i]]++; wallIds[k] = i; wallG[k] = walls.gA(i);
            if (wallB[i] >= 0) { k = fill[wallB[i]]++; wallIds[k] = i; wallG[k] = walls.gB(i); }
        }
        facePoint = new double[nf][3]; boundaryPoint = new double[g.boundaryCount()][3];
        faceArea = new double[nf]; faceDn = new double[nf]; boundaryArea = new double[g.boundaryCount()];
        boundaryBg = new double[g.boundaryCount()]; storeBg = new double[nw];
        java.util.Arrays.fill(boundaryBg, c.ambientT()); java.util.Arrays.fill(storeBg, c.ambientT());
        for (int f = 0; f < nf; f++) {
            faceArea[f] = g.faceArea(f); faceDn[f] = g.faceDn(f);
            Advection3D.point(facePoint[f], g.faceAxis(f), Reconstruction3D.low(g, g.faceB(f), g.faceAxis(f)),
                    0.5 * (g.faceU0(f) + g.faceU1(f)), 0.5 * (g.faceV0(f) + g.faceV1(f)));
        }
        exchangeHalf = new double[g.exchangeCount()];
        for (int e = 0; e < exchangeHalf.length; e++) {
            int b = g.exchangeBox(e), axis = g.exchangeAxis(e);
            exchangeHalf[e] = 0.5 * (axis == 0 ? g.boxSx(b) : axis == 1 ? g.boxSy(b) : g.boxSz(b));
        }
        for (int k = 0; k < g.boundaryCount(); k++) {
            boundaryArea[k] = g.boundaryArea(k);
            int b = g.boundaryBox(k), axis = g.boundaryAxis(k);
            Advection3D.point(boundaryPoint[k], axis, Reconstruction3D.low(g, b, axis)
                            + g.boundarySide(k) * Reconstruction3D.extent(g, b, axis),
                    0.5 * (g.boundaryU0(k) + g.boundaryU1(k)), 0.5 * (g.boundaryV0(k) + g.boundaryV1(k)));
        }
    }
    /**
     * Sets background temperatures, °C: each boundary takes its box's (boxBg), and each AMBIENT wall store's far
     * side takes the background of the last solid cell of its ray.
     */
    void setBackground(Background3D bg, double[] boxBg) {
        for (int k = 0; k < boundaryBg.length; k++) boundaryBg[k] = boxBg[g.boundaryBox(k)];
        for (int i = 0; i < storeBg.length; i++)
            storeBg[i] = walls.kind(i) == WallStore3D.AMBIENT ? bg.cell(walls.blockCell(walls.blockStart(i + 1) - 1))
                    : bg.reference();
    }
    /**
     * One cell of EXCHANGE face e, W/K: the solver's air-to-air diffusion over 1 m² (Bright, 2026-11-16), across the
     * distance from this box's centre to the far air's (half the box's depth along the normal, plus the far half the
     * host gives, half a cell unless set). Two live tiles that each give the other's half use the same conductance.
     */
    private double exchangeConductance(int e, Side side, int cell) {
        return c.rhoCp() * c.kappa() / (exchangeHalf[e] + exchange.distance(side, cell));
    }
    /** Sets the EXCHANGE faces' far-side temperatures (null: all insulated); read at each solve. */
    void setExchange(ExchangeTemperatures temperatures) { exchange = temperatures; }
    /** Far-side background of wall store i, °C (used by AMBIENT stores only). */
    double storeBackground(int i) { return storeBg[i]; }
    private int fluidBox(int cell) {
        if (cell < 0 || cell >= g.nx() * g.ny() * g.nz() || g.boxOfCellIndex(cell) < 0)
            throw new IllegalArgumentException("wall store endpoint is not a graph fluid cell");
        return g.boxOfCellIndex(cell);
    }
    void solve(FlowState3D s, double[] sourceWatts, StepStats stats) {
        double dt = c.dt(), rc = c.rhoCp();
        System.arraycopy(s.T, 0, previous, 0, previous.length);
        for (int i = 0; i < walls.count(); i++) previousWall[i] = walls.temperature(i);
        stats.singularGradientBoxes = gradients.singularBoxes();
        long start = System.nanoTime();
        gradients.gradient(previous, gx, gy, gz);
        stats.gradientMs = (System.nanoTime() - start) * 1e-6;
        gradients.limit(previous, gx, gy, gz, lx, ly, lz);
        betaSum = 0; betaEdges = 0; betaLimited = 0;
        double source = 0;
        for (int i = 0; i < g.boxCount(); i++) {
            diagonal[i] = capacity[i] / dt;
            rhs[i] = capacity[i] / dt * s.T[i] + sourceWatts[i];
            source += sourceWatts[i];
        }
        for (int f = 0; f < g.faceCount(); f++) {
            int a = g.faceA(f), b = g.faceB(f);
            double ap = g.aperture(f), area = faceArea[f];
            double cond = rc * c.kappa() * (ap * area) / faceDn[f]
                    + g.faceClosedConductance(f) * (1 - ap) * area;
            double inA = 0, inB = 0;
            if (ap > 0) {
                double flux = s.u[f] * ap * area;
                int up = flux >= 0 ? a : b, down = flux >= 0 ? b : a;
                double correction = rc * Math.abs(flux) * correctionBeta(Math.abs(flux), up)
                        * tilt(up, facePoint[f]);
                rhs[up] -= correction; rhs[down] += correction;
                double flow = rc * flux;
                if (flow > 0) { diagonal[a] += flow; inB = flow; }
                else { diagonal[b] -= flow; inA = -flow; }
            }
            diagonal[a] += cond; diagonal[b] += cond;
            values[ab[f]] = inA + cond; values[ba[f]] = inB + cond;
        }
        for (int k = 0; k < g.boundaryCount(); k++) {
            double cond = ambientConductance(k), tBg = boundaryBg[k];
            int box = g.boundaryBox(k);
            diagonal[box] += cond; rhs[box] += cond * tBg;
            double out = advectiveOutflow(s, k);
            if (out > 0) {
                diagonal[box] += out;
                if (open(k)) rhs[box] -= out * correctionBeta(out / rc, box) * tilt(box, boundaryPoint[k]);
            } else rhs[box] -= out * tBg;
        }
        if (exchange != null)
            for (int e = 0; e < exchangeHalf.length; e++) {
                Side side = g.exchangeDomainSide(e);
                int box = g.exchangeBox(e);
                for (int k = g.exchangeCellsStart(e); k < g.exchangeCellsEnd(e); k++) {
                    int cell = g.exchangeCell(k);
                    double far = exchange.at(side, cell);
                    if (!Double.isFinite(far)) continue;
                    double gc = exchangeConductance(e, side, cell);
                    diagonal[box] += gc; rhs[box] += gc * far;
                }
            }
        for (int i = 0; i < g.boxCount(); i++)
            for (int k = wallRows[i]; k < wallRows[i + 1]; k++) diagonal[i] += wallG[k];
        stats.correctionLimitedFraction = betaEdges > 0 ? (double) betaLimited / betaEdges : 0;
        stats.meanCorrectionBeta = betaEdges > 0 ? betaSum / betaEdges : 1;
        // Successive over-relaxation when the factor is not 1; at 1 the sweep is plain Gauss–Seidel, unchanged.
        double omega = c.thermalRelaxation();
        boolean relax = omega != 1;
        int sweeps = 0;
        while (sweeps < c.thermalMaxSweeps()) {
            sweeps++;
            double maxChange = 0;
            for (int i = 0; i < g.boxCount(); i++) {
                double sum = rhs[i];
                for (int k = rows[i]; k < rows[i + 1]; k++) sum += values[k] * s.T[cols[k]];
                for (int k = wallRows[i]; k < wallRows[i + 1]; k++) sum += wallG[k] * walls.temperature(wallIds[k]);
                double t = sum / diagonal[i];
                if (relax) t = s.T[i] + omega * (t - s.T[i]);
                maxChange = Math.max(maxChange, Math.abs(t - s.T[i])); s.T[i] = t;
            }
            for (int i = 0; i < walls.count(); i++) {
                if (walls.isFixed(i)) continue;
                double cd = walls.capacity(i) / dt;
                double sum = cd * previousWall[i] + walls.gA(i) * s.T[wallA[i]];
                if (walls.kind(i) == WallStore3D.AIR) sum += walls.gB(i) * s.T[wallB[i]];
                else if (walls.kind(i) == WallStore3D.AMBIENT) sum += walls.gB(i) * storeBg[i];
                double t = sum / (cd + walls.gA(i) + walls.gB(i));
                if (relax) t = walls.temperature(i) + omega * (t - walls.temperature(i));
                maxChange = Math.max(maxChange, Math.abs(t - walls.temperature(i))); walls.setTemperature(i, t);
            }
            if (maxChange < c.thermalTolerance()) break;
        }
        stats.thermalSweeps = sweeps;
        double dE = 0, gross = 0, loss = 0;
        for (int i = 0; i < g.boxCount(); i++) {
            double d = capacity[i] * (s.T[i] - previous[i]); dE += d; gross += Math.abs(d);
        }
        double fixedIn = 0;
        for (int i = 0; i < walls.count(); i++) {
            double d = walls.capacity(i) * (walls.temperature(i) - previousWall[i]); dE += d; gross += Math.abs(d);
            if (walls.kind(i) == WallStore3D.AMBIENT) loss += walls.gB(i) * (walls.temperature(i) - storeBg[i]);
            if (walls.isFixed(i)) {
                // a fixed store gives what flows out of it on both sides (its far side's loss is counted above)
                double t = walls.temperature(i), out = walls.gA(i) * (t - s.T[wallA[i]]);
                if (walls.kind(i) == WallStore3D.AIR) out += walls.gB(i) * (t - s.T[wallB[i]]);
                else if (walls.kind(i) == WallStore3D.AMBIENT) out += walls.gB(i) * (t - storeBg[i]);
                fixedIn += out;
            }
        }
        double advected = 0;
        for (int k = 0; k < g.boundaryCount(); k++) {
            int box = g.boundaryBox(k);
            double t = s.T[box], out = advectiveOutflow(s, k), tBg = boundaryBg[k];
            loss += ambientConductance(k) * (t - tBg);
            double correction = out > 0 && open(k)
                    ? Math.min(1, 0.5 * g.boxVolume(box) / (out / rc * dt)) * tilt(box, boundaryPoint[k]) : 0;
            advected += out * (out > 0 ? t + correction : tBg);
        }
        double exchanged = 0;
        if (exchange != null)
            for (int e = 0; e < exchangeHalf.length; e++) {
                Side side = g.exchangeDomainSide(e);
                double t = s.T[g.exchangeBox(e)];
                for (int k = g.exchangeCellsStart(e); k < g.exchangeCellsEnd(e); k++) {
                    int cell = g.exchangeCell(k);
                    double far = exchange.at(side, cell);
                    if (Double.isFinite(far)) exchanged += exchangeConductance(e, side, cell) * (t - far);
                }
            }
        double sourceE = (source + fixedIn) * dt, lossE = loss * dt, advE = advected * dt, exchE = exchanged * dt;
        double residual = dE - (sourceE - lossE - advE - exchE);
        double scale = Math.max(gross, Math.abs(sourceE) + Math.abs(lossE) + Math.abs(advE) + Math.abs(exchE));
        stats.energyResidual = scale > 0 ? Math.abs(residual) / scale : 0;
        stats.deltaEnergy = dE; stats.sourceEnergy = sourceE; stats.ambientLoss = lossE; stats.advectedOut = advE;
        stats.exchangeOut = exchE;
    }
    double totalEnergy(FlowState3D s) {
        double sum = 0;
        for (int i = 0; i < g.boxCount(); i++) sum += capacity[i] * s.T[i];
        return sum + walls.energy();
    }
    private double correctionBeta(double flux, int up) {
        double courant = flux * c.dt() / g.boxVolume(up), beta = courant > 0.5 ? 0.5 / courant : 1;
        betaSum += beta; betaEdges++; if (beta < 1) betaLimited++;
        return beta;
    }
    private double tilt(int box, double[] point) {
        return lx[box] * (point[0] - g.boxCx(box)) + ly[box] * (point[1] - g.boxCy(box))
                + lz[box] * (point[2] - g.boxCz(box));
    }
    private boolean open(int k) {
        return g.boundaryKind(k) == BoundaryKind.OPEN && g.boundaryAperture(k) > 0;
    }
    private double ambientConductance(int k) {
        double ap = g.boundaryAperture(k), area = boundaryArea[k];
        double closed = g.boundaryClosedConductance(k) * (1 - ap) * area;
        return g.boundaryKind(k) == BoundaryKind.OPEN ? c.rhoCp() * c.kappa() * (ap * area) / 0.5 + closed : closed;
    }
    private double advectiveOutflow(FlowState3D s, int k) {
        return c.rhoCp() * (g.boundarySide(k) == 1 ? 1 : -1) * s.ub[k] * g.boundaryAperture(k) * boundaryArea[k];
    }
}
