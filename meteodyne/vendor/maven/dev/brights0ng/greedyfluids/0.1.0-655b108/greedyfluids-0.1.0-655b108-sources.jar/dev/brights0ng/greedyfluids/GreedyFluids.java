// Written by Claude.
package dev.brights0ng.greedyfluids;

/**
 * Entry point and version marker for GreedyFluids, an adaptive "greedy box" air-flow and heat solver.
 * <p>
 * The library knows nothing about Minecraft. Callers describe geometry as cell types on an integer grid and read
 * temperature and velocity back; meshing, refinement and the physics live here.
 */
public final class GreedyFluids {
    /** Library version; kept in step with {@code version} in gradle.properties by {@code GreedyFluidsTest}. */
    public static final String VERSION = "0.1.0";

    private GreedyFluids() { }
}
