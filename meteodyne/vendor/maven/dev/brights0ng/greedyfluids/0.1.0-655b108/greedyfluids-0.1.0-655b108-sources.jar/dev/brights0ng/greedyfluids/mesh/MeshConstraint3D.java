// Written by ChatGPT from Claude's M5d spec.
// Edited by Claude: optional axis mask for the axis-limited opening rules (M6b2).
// Edited by Claude: optional velocity mask (M6d4).
package dev.brights0ng.greedyfluids.mesh;

import dev.brights0ng.greedyfluids.grid.CellGrid3D;

/** Per-cell extent limits (cells) and maximum plane-fit residuals (field units). Arrays are live. */
public final class MeshConstraint3D {
    public final int[] limX, limY, limZ;
    public final double[][] fields;
    public final double[] bound;
    private final int nx, ny, nz;
    private byte[] axis;
    private boolean[] velocity;

    /**
     * Optional live per-cell mask for fields 1 and up (the velocity components): a candidate checks those fields
     * only if it covers at least one marked cell. Null (the default) checks every field everywhere.
     */
    public void setVelocityMask(boolean[] mask) {
        if (mask != null && mask.length != nx * ny * nz) throw new IllegalArgumentException("velocity mask length");
        velocity = mask;
    }

    /**
     * Optional live per-cell axis mask (bit 0 x, 1 y, 2 z): a box may not extend past one cell along a masked
     * axis of any cell it covers. Null (the default) checks nothing.
     */
    public void setAxisMask(byte[] mask) {
        if (mask != null && mask.length != nx * ny * nz) throw new IllegalArgumentException("axis mask length");
        axis = mask;
    }

    /** Fields are cell-indexed T (°C), u, v, w (m/s); bounds have matching units. */
    public MeshConstraint3D(CellGrid3D grid, int[] limX, int[] limY, int[] limZ,
            double[][] fields, double[] bound) {
        nx = grid.nx(); ny = grid.ny(); nz = grid.nz();
        int cells = nx * ny * nz;
        if (limX.length != cells || limY.length != cells || limZ.length != cells
                || fields.length != bound.length) throw new IllegalArgumentException("constraint dimensions");
        for (int i = 0; i < cells; i++)
            if (limX[i] < 1 || limX[i] > 16 || limY[i] < 1 || limY[i] > 16 || limZ[i] < 1 || limZ[i] > 16)
                throw new IllegalArgumentException("extent limit outside 1..16");
        for (int f = 0; f < fields.length; f++)
            if (fields[f].length != cells || !(bound[f] >= 0) || !Double.isFinite(bound[f]))
                throw new IllegalArgumentException("field length or residual bound");
        this.limX = limX; this.limY = limY; this.limZ = limZ; this.fields = fields; this.bound = bound;
    }

    /** Checks a cuboid in cells in O(volume × fields), without allocating. Singleton cells always pass. */
    public boolean allows(int x0, int y0, int z0, int sx, int sy, int sz) {
        if (sx < 1 || sy < 1 || sz < 1 || x0 < 0 || y0 < 0 || z0 < 0
                || x0 + sx > nx || y0 + sy > ny || z0 + sz > nz)
            throw new IllegalArgumentException("candidate outside grid");
        if (sx == 1 && sy == 1 && sz == 1) return true;
        boolean checkVelocity = velocity == null;
        for (int y = y0; y < y0 + sy; y++) for (int z = z0; z < z0 + sz; z++)
            for (int x = x0; x < x0 + sx; x++) {
                int c = (y * nz + z) * nx + x;
                if (!checkVelocity && velocity[c]) checkVelocity = true;
                if (limX[c] < sx || limY[c] < sy || limZ[c] < sz) return false;
                if (axis != null && axis[c] != 0 && ((axis[c] & 1) != 0 && sx > 1
                        || (axis[c] & 2) != 0 && sy > 1 || (axis[c] & 4) != 0 && sz > 1)) return false;
            }
        double volume = (double) sx * sy * sz;
        // Centred Cartesian coordinates are orthogonal on a complete cuboid. The normal
        // equations are diagonal, including degenerate (one-cell-thick) directions.
        double cx = x0 + 0.5 * sx, cy = y0 + 0.5 * sy, cz = z0 + 0.5 * sz;
        int checked = checkVelocity ? fields.length : Math.min(1, fields.length);
        for (int f = 0; f < checked; f++) {
            double[] q = fields[f];
            double base = q[(y0 * nz + z0) * nx + x0];
            double sum = 0, mx = 0, my = 0, mz = 0;
            for (int y = y0; y < y0 + sy; y++) for (int z = z0; z < z0 + sz; z++)
                for (int x = x0; x < x0 + sx; x++) {
                    double d = q[(y * nz + z) * nx + x] - base;
                    sum += d; mx += d * (x + 0.5 - cx);
                    my += d * (y + 0.5 - cy); mz += d * (z + 0.5 - cz);
                }
            double mean = sum / volume;
            double gx = sx == 1 ? 0 : mx / (volume * (sx * sx - 1) / 12);
            double gy = sy == 1 ? 0 : my / (volume * (sy * sy - 1) / 12);
            double gz = sz == 1 ? 0 : mz / (volume * (sz * sz - 1) / 12);
            for (int y = y0; y < y0 + sy; y++) for (int z = z0; z < z0 + sz; z++)
                for (int x = x0; x < x0 + sx; x++) {
                    double residual = q[(y * nz + z) * nx + x] - base - mean
                            - gx * (x + 0.5 - cx) - gy * (y + 0.5 - cy) - gz * (z + 0.5 - cz);
                    if (!(Math.abs(residual) <= bound[f] + 1e-12)) return false;
                }
        }
        return true;
    }
}
