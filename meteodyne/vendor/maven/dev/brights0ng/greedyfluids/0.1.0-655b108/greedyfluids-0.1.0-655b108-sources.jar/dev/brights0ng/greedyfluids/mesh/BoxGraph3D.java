// Written by ChatGPT from Claude's M5b spec; edited by ChatGPT from Claude's M5b2 spec.
// Edited by Claude: effective boundary kinds for the inflow-pocket rule; roofed-inflow rule (M6b1).
// Edited by Claude: door conductances with the grid's film resistance (M8a).
// Edited by Claude: per-cell side conditions; EXCHANGE faces, kept apart from the flow's boundaries (M8b).
package dev.brights0ng.greedyfluids.mesh;

import dev.brights0ng.greedyfluids.grid.CellGrid3D;
import dev.brights0ng.greedyfluids.grid.CellGrid3D.Side;
import dev.brights0ng.greedyfluids.grid.CellGrid3D.Boundary;
import dev.brights0ng.greedyfluids.grid.CellType;
import dev.brights0ng.greedyfluids.grid.Material;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

/**
 * Fixed cuboid geometry with mutable door flags, face apertures (dimensionless, 0 or 1) and effective
 * boundary kinds (an INFLOW face may be opened by the inflow-pocket rule, see SealedComponents3D).
 * Cells are 1 m cubes. No wall conduction links are stored here.
 * Interior and boundary CSR lists use [facesStart(box), facesEnd(box)) with faceAt(offset),
 * and [boundariesStart(box), boundariesEnd(box)) with boundaryAt(offset). No accessor allocates.
 * <p>M8b: a box's face on a domain side takes that side's condition, or its cells' own one (uniform over the face:
 * the mesher keeps it so, and a mixed face is rejected). CLOSED faces carry nothing. EXCHANGE faces carry no air and
 * are not boundaries: they are listed apart ({@link #exchangeCount}), with their cells' face-plane indices, for the
 * heat solve alone.
 */
public final class BoxGraph3D {
    /** Domain flow condition. */
    public enum BoundaryKind { OPEN, INFLOW }
    private record Face(int a, int b, int axis, int u0, int u1, int v0, int v1,
                        double area, double dn, double conductance) { }
    private record Exterior(int box, int axis, int side, BoundaryKind kind,
                            int u0, int u1, int v0, int v1, double area, double inflow,
                            double conductance) { }
    private record Exchange(int box, int axis, int side, int[] cells) { }
    private final int nx, ny, nz;
    private final int[][] start, size;
    private final int[] boxOf;
    private final boolean[] door, open;
    private final Face[] faces;
    private final Exterior[] boundaries;
    private final Exchange[] exchanges;
    private final int[] exchangeStart, exchangeCells;
    private final double[] apertures, boundaryApertures;
    private final BoundaryKind[] kinds;
    private int roofedInflowFaces;
    private final int[] faceStart, faceIds, boundaryStart, boundaryIds;

    /** Builds copied cuboids (cell coordinates/extents), using rhoCp in J/(m³·K). */
    public static BoxGraph3D build(CellGrid3D grid, int[] x0, int[] y0, int[] z0,
            int[] sx, int[] sy, int[] sz, double rhoCp) {
        return new BoxGraph3D(grid, new int[][]{x0.clone(), y0.clone(), z0.clone()},
                new int[][]{sx.clone(), sy.clone(), sz.clone()}, rhoCp);
    }
    private BoxGraph3D(CellGrid3D grid, int[][] start, int[][] size, double rhoCp) {
        nx = grid.nx(); ny = grid.ny(); nz = grid.nz();
        this.start = start; this.size = size;
        int n = start[0].length;
        for (int axis = 0; axis < 3; axis++)
            if (start[axis].length != n || size[axis].length != n)
                throw new IllegalArgumentException("box arrays differ in length");
        boxOf = new int[nx * ny * nz];
        Arrays.fill(boxOf, -1);
        door = new boolean[n]; open = new boolean[n];
        double[] conductance = new double[n];
        for (int i = 0; i < n; i++) {
            for (int axis = 0; axis < 3; axis++)
                if (size[axis][i] <= 0 || start[axis][i] < 0
                        || (long) start[axis][i] + size[axis][i] > extent(axis))
                    throw new IllegalArgumentException("box empty or outside grid: " + i);
            CellType type = grid.type(boxX0(i), boxY0(i), boxZ0(i));
            for (int y = boxY0(i); y < boxY0(i) + boxSy(i); y++)
                for (int z = boxZ0(i); z < boxZ0(i) + boxSz(i); z++)
                    for (int x = boxX0(i); x < boxX0(i) + boxSx(i); x++) {
                        if (!type.isFluid() || grid.type(x, y, z) != type)
                            throw new IllegalArgumentException("box mixes types or holds solid: " + i);
                        int cell = grid.index(x, y, z);
                        if (boxOf[cell] >= 0) throw new IllegalArgumentException("cell in two boxes");
                        boxOf[cell] = i;
                    }
            door[i] = type == CellType.DOOR;
            if (door[i]) {
                if (boxSx(i) != 1 || boxSy(i) != 1 || boxSz(i) != 1)
                    throw new IllegalArgumentException("door box must be 1x1x1");
                open[i] = grid.doorOpen(boxX0(i), boxY0(i), boxZ0(i));
                Material m = grid.material(boxX0(i), boxY0(i), boxZ0(i));
                conductance[i] = (m != null ? m : Material.DOOR).conductance(1, rhoCp, grid.filmResistance());
            }
        }
        for (int y = 0; y < ny; y++) for (int z = 0; z < nz; z++) for (int x = 0; x < nx; x++)
            if (grid.type(x, y, z).isFluid() && boxOfCell(x, y, z) < 0)
                throw new IllegalArgumentException("fluid cell in no box");

        ArrayList<Face> fs = new ArrayList<>();
        ArrayList<Exterior> bs = new ArrayList<>();
        ArrayList<Exchange> es = new ArrayList<>();
        // Primitive stamped neighbour grouping, reused for every positive box surface.
        int[] stamp = new int[n], neighbours = new int[n], counts = new int[n];
        int generation = 0;
        int[] roofTops = InflowExposure3D.roofTops(grid);
        for (int a = 0; a < n; a++) for (int axis = 0; axis < 3; axis++) {
            int u = axis == 0 ? 1 : 0, v = axis == 2 ? 1 : 2;
            int plane = start[axis][a] + size[axis][a];
            if (plane < extent(axis)) {
                generation++;
                int found = 0;
                for (int cu = start[u][a]; cu < start[u][a] + size[u][a]; cu++)
                    for (int cv = start[v][a]; cv < start[v][a] + size[v][a]; cv++) {
                        int x = axis == 0 ? plane : cu;
                        int y = axis == 1 ? plane : axis == 0 ? cu : cv;
                        int z = axis == 2 ? plane : cv;
                        int b = boxOfCell(x, y, z);
                        if (b < 0) continue;
                        if (stamp[b] != generation) {
                            stamp[b] = generation; counts[b] = 0; neighbours[found++] = b;
                        }
                        counts[b]++;
                    }
                for (int k = 0; k < found; k++) {
                    int b = neighbours[k];
                    int u0 = Math.max(start[u][a], start[u][b]);
                    int u1 = Math.min(start[u][a] + size[u][a], start[u][b] + size[u][b]);
                    int v0 = Math.max(start[v][a], start[v][b]);
                    int v1 = Math.min(start[v][a] + size[v][a], start[v][b] + size[v][b]);
                    double area = (double) (u1 - u0) * (v1 - v0);
                    if (area != counts[b]) throw new AssertionError("nonrectangular face");
                    fs.add(new Face(a, b, axis, u0, u1, v0, v1, area,
                            Math.abs(centre(b, axis) - centre(a, axis)),
                            door[a] ? conductance[a] : conductance[b]));
                }
            }
            for (int side = 0; side < 2; side++) {
                if (start[axis][a] + (side == 1 ? size[axis][a] : 0) != (side == 1 ? extent(axis) : 0))
                    continue;
                Side domain = Side.values()[2 * axis + side];
                Boundary kind = grid.hasFaceBoundaries() ? FaceKinds3D.kind(grid, domain, start[0][a], start[1][a],
                        start[2][a], size[0][a], size[1][a], size[2][a], true) : grid.boundary(domain);
                if (kind == null) throw new IllegalArgumentException("box " + a + " meets " + domain + " with mixed conditions");
                if (kind == Boundary.CLOSED) continue;
                if (kind == Boundary.EXCHANGE) { es.add(new Exchange(a, axis, side, planeCells(a, axis))); continue; }
                // Roofed-inflow rule (InflowExposure3D): a side-wall INFLOW face under a roof is declared OPEN.
                if (kind == Boundary.INFLOW && axis != 1 && roofedFace(grid, roofTops, a, axis, side)) {
                    kind = Boundary.OPEN; roofedInflowFaces++;
                }
                bs.add(new Exterior(a, axis, side, kind == Boundary.OPEN ? BoundaryKind.OPEN : BoundaryKind.INFLOW,
                        start[u][a], start[u][a] + size[u][a], start[v][a], start[v][a] + size[v][a],
                        (double) size[u][a] * size[v][a], kind == Boundary.INFLOW
                                ? (side == 0 ? 1 : -1) * grid.inflowSpeed(domain) : 0,
                        conductance[a]));
            }
        }
        fs.sort(Comparator.comparingInt(Face::a).thenComparingInt(Face::axis).thenComparingInt(Face::b));
        bs.sort(Comparator.comparingInt(Exterior::box).thenComparingInt(Exterior::axis).thenComparingInt(Exterior::side));
        faces = fs.toArray(Face[]::new); boundaries = bs.toArray(Exterior[]::new);
        es.sort(Comparator.comparingInt(Exchange::box).thenComparingInt(Exchange::axis).thenComparingInt(Exchange::side));
        exchanges = es.toArray(Exchange[]::new);
        exchangeStart = new int[exchanges.length + 1];
        for (int e = 0; e < exchanges.length; e++) exchangeStart[e + 1] = exchangeStart[e] + exchanges[e].cells.length;
        exchangeCells = new int[exchangeStart[exchanges.length]];
        for (int e = 0; e < exchanges.length; e++)
            System.arraycopy(exchanges[e].cells, 0, exchangeCells, exchangeStart[e], exchanges[e].cells.length);
        apertures = new double[faces.length]; boundaryApertures = new double[boundaries.length];
        kinds = new BoundaryKind[boundaries.length];
        for (int k = 0; k < boundaries.length; k++) kinds[k] = boundaries[k].kind;
        faceStart = new int[n + 1]; boundaryStart = new int[n + 1];
        for (Face f : faces) { faceStart[f.a + 1]++; faceStart[f.b + 1]++; }
        for (Exterior b : boundaries) boundaryStart[b.box + 1]++;
        for (int i = 0; i < n; i++) { faceStart[i + 1] += faceStart[i]; boundaryStart[i + 1] += boundaryStart[i]; }
        faceIds = new int[2 * faces.length]; boundaryIds = new int[boundaries.length];
        int[] fc = faceStart.clone(), bc = boundaryStart.clone();
        for (int f = 0; f < faces.length; f++) {
            faceIds[fc[faces[f].a]++] = f; faceIds[fc[faces[f].b]++] = f;
            updateFace(f);
        }
        for (int k = 0; k < boundaries.length; k++) {
            boundaryIds[bc[boundaries[k].box]++] = k;
            boundaryApertures[k] = doorOpen(boundaries[k].box) ? 1 : 0;
        }
    }
    /**
     * Whether more than half of the face's columns are roofed. Greedy meshes keep each INFLOW face uniform, so
     * this is exact for them; the majority only decides boxes from other meshers or stale local remeshes.
     */
    private boolean roofedFace(CellGrid3D grid, int[] tops, int a, int axis, int side) {
        int along = axis == 0 ? 2 : 0, roofed = 0, columns = size[along][a];
        int fixed = side == 0 ? 0 : extent(axis) - 1;
        for (int i = 0; i < columns; i++) {
            int x = axis == 0 ? fixed : start[0][a] + i, z = axis == 0 ? start[2][a] + i : fixed;
            if (InflowExposure3D.roofed(tops, grid, x, start[1][a], z)) roofed++;
        }
        return 2 * roofed > columns;
    }
    private int extent(int axis) { return axis == 0 ? nx : axis == 1 ? ny : nz; }
    /** Face-plane indices ({@link CellGrid3D#faceIndex}) of box a's cells on a side of the given axis. */
    private int[] planeCells(int a, int axis) {
        int u = axis == 0 ? 1 : 0, v = axis == 2 ? 1 : 2;
        int[] out = new int[size[u][a] * size[v][a]];
        int k = 0;
        for (int cu = start[u][a]; cu < start[u][a] + size[u][a]; cu++)
            for (int cv = start[v][a]; cv < start[v][a] + size[v][a]; cv++)
                out[k++] = axis == 0 ? cu * nz + cv : cv * nx + cu;
        return out;
    }
    private double centre(int i, int axis) { return start[axis][i] + 0.5 * size[axis][i]; }
    private void updateFace(int f) { apertures[f] = doorOpen(faces[f].a) && doorOpen(faces[f].b) ? 1 : 0; }
    /** Number of boxes, dimensionless. */
    public int boxCount() { return door.length; }
    /** Number of interior faces, dimensionless. */
    public int faceCount() { return faces.length; }
    /** Number of OPEN/INFLOW boundary faces, dimensionless. */
    public int boundaryCount() { return boundaries.length; }
    /** Number of EXCHANGE faces (no flow; heat to a far side, M8b), dimensionless. */
    public int exchangeCount() { return exchanges.length; }
    /** Box of EXCHANGE face e. */
    public int exchangeBox(int e) { return exchanges[e].box; }
    /** Normal axis of EXCHANGE face e (0 x, 1 y, 2 z). */
    public int exchangeAxis(int e) { return exchanges[e].axis; }
    /** Side of EXCHANGE face e: 0 low, 1 high. */
    public int exchangeSide(int e) { return exchanges[e].side; }
    /** Domain side of EXCHANGE face e. */
    public Side exchangeDomainSide(int e) { return Side.values()[2 * exchanges[e].axis + exchanges[e].side]; }
    /** Area of EXCHANGE face e, m² (one per cell). */
    public double exchangeArea(int e) { return exchanges[e].cells.length; }
    /** First of EXCHANGE face e's cells in {@link #exchangeCell}. */
    public int exchangeCellsStart(int e) { return exchangeStart[e]; }
    /** One past the last of EXCHANGE face e's cells. */
    public int exchangeCellsEnd(int e) { return exchangeStart[e + 1]; }
    /** An EXCHANGE face cell's index in its side's face plane ({@link CellGrid3D#faceIndex}). */
    public int exchangeCell(int k) { return exchangeCells[k]; }
    /** Domain x extent in cells (= m). */
    public int nx() { return nx; }
    /** Domain y extent in cells (= m). */
    public int ny() { return ny; }
    /** Domain z extent in cells (= m). */
    public int nz() { return nz; }
    /** Box x low coordinate, cells (= m). */
    public int boxX0(int box) { return start[0][box]; }
    /** Box y low coordinate, cells (= m). */
    public int boxY0(int box) { return start[1][box]; }
    /** Box z low coordinate, cells (= m). */
    public int boxZ0(int box) { return start[2][box]; }
    /** Box x extent, cells (= m). */
    public int boxSx(int box) { return size[0][box]; }
    /** Box y extent, cells (= m). */
    public int boxSy(int box) { return size[1][box]; }
    /** Box z extent, cells (= m). */
    public int boxSz(int box) { return size[2][box]; }
    /** Box x centre, m. */
    public double boxCx(int box) { return centre(box, 0); }
    /** Box y centre, m. */
    public double boxCy(int box) { return centre(box, 1); }
    /** Box z centre, m. */
    public double boxCz(int box) { return centre(box, 2); }
    /** Box volume, m³. */
    public double boxVolume(int box) { return (double) boxSx(box) * boxSy(box) * boxSz(box); }
    /** Whether this box is a door. */
    public boolean isDoor(int box) { return door[box]; }
    /** True for open doors and all non-door boxes. */
    public boolean doorOpen(int box) { return !door[box] || open[box]; }
    /** Low-side box id. */
    public int faceA(int i) { return faces[i].a; }
    /** High-side box id. */
    public int faceB(int i) { return faces[i].b; }
    /** Normal axis id, 0=x, 1=y, 2=z. */
    public int faceAxis(int i) { return faces[i].axis; }
    /** Shared area, m². */
    public double faceArea(int i) { return faces[i].area; }
    /** Normal centre distance, m. */
    public double faceDn(int i) { return faces[i].dn; }
    /** Closed per-area conductance, W/(m²·K). */
    public double faceClosedConductance(int i) { return faces[i].conductance; }
    /** Tangential rectangle endpoint, cells (= m). */
    public int faceU0(int i) { return faces[i].u0; }
    /** Tangential rectangle endpoint, cells (= m). */
    public int faceU1(int i) { return faces[i].u1; }
    /** Tangential rectangle endpoint, cells (= m). */
    public int faceV0(int i) { return faces[i].v0; }
    /** Tangential rectangle endpoint, cells (= m). */
    public int faceV1(int i) { return faces[i].v1; }
    /** Box id. */
    public int boundaryBox(int i) { return boundaries[i].box; }
    /** Normal axis id, 0=x, 1=y, 2=z. */
    public int boundaryAxis(int i) { return boundaries[i].axis; }
    /** Low (0) or high (1) side. */
    public int boundarySide(int i) { return boundaries[i].side; }
    /** Effective flow condition: the declared one, or OPEN for an INFLOW face opened by the pocket rule. */
    public BoundaryKind boundaryKind(int i) { return kinds[i]; }
    /** Exterior faces on INFLOW side walls declared OPEN by the roofed-inflow rule (InflowExposure3D). */
    public int roofedInflowFaces() { return roofedInflowFaces; }
    /** Flow condition declared by the grid's side and the roofed-inflow rule (before the pocket rule). */
    public BoundaryKind declaredBoundaryKind(int i) { return boundaries[i].kind; }
    /** Whether a declared INFLOW face is currently treated as OPEN by the pocket rule. */
    public boolean inflowOpened(int i) { return kinds[i] != boundaries[i].kind; }
    /** Opens (OPEN) or restores (INFLOW) a declared INFLOW face; allocates nothing. */
    public void setInflowOpened(int i, boolean opened) {
        if (boundaries[i].kind != BoundaryKind.INFLOW) throw new IllegalArgumentException("not an INFLOW face");
        kinds[i] = opened ? BoundaryKind.OPEN : BoundaryKind.INFLOW;
    }
    /** Area, m². */
    public double boundaryArea(int i) { return boundaries[i].area; }
    /** Prescribed velocity along +axis, m/s. */
    public double boundaryInflow(int i) { return boundaries[i].inflow; }
    /** Closed per-area conductance, W/(m²·K). */
    public double boundaryClosedConductance(int i) { return boundaries[i].conductance; }
    /** Tangential rectangle endpoint, cells (= m). */
    public int boundaryU0(int i) { return boundaries[i].u0; }
    /** Tangential rectangle endpoint, cells (= m). */
    public int boundaryU1(int i) { return boundaries[i].u1; }
    /** Tangential rectangle endpoint, cells (= m). */
    public int boundaryV0(int i) { return boundaries[i].v0; }
    /** Tangential rectangle endpoint, cells (= m). */
    public int boundaryV1(int i) { return boundaries[i].v1; }
    /** Interior open area fraction, dimensionless. */
    public double aperture(int f) { return apertures[f]; }
    /** Boundary open area fraction, dimensionless. */
    public double boundaryAperture(int k) { return boundaryApertures[k]; }
    /** Opens/closes a door, updating only incident apertures through CSR adjacency; allocates nothing. */
    public void setDoorOpen(int box, boolean value) {
        if (!door[box]) throw new IllegalArgumentException("not a door box");
        open[box] = value;
        for (int k = facesStart(box); k < facesEnd(box); k++) updateFace(faceIds[k]);
        for (int k = boundariesStart(box); k < boundariesEnd(box); k++)
            boundaryApertures[boundaryIds[k]] = value ? 1 : 0;
    }
    /** Interior CSR start offset, inclusive. */
    public int facesStart(int box) { return faceStart[box]; }
    /** Interior CSR end offset, exclusive. */
    public int facesEnd(int box) { return faceStart[box + 1]; }
    /** Interior face id at CSR offset. */
    public int faceAt(int offset) { return faceIds[offset]; }
    /** Boundary CSR start offset, inclusive. */
    public int boundariesStart(int box) { return boundaryStart[box]; }
    /** Boundary CSR end offset, exclusive. */
    public int boundariesEnd(int box) { return boundaryStart[box + 1]; }
    /** Boundary face id at CSR offset. */
    public int boundaryAt(int offset) { return boundaryIds[offset]; }
    /** Box holding cell coordinates, or -1 for solid. */
    public int boxOfCell(int x, int y, int z) { return boxOf[(y * nz + z) * nx + x]; }
    /** Box holding cell index (y * nz + z) * nx + x, or -1 for solid. */
    public int boxOfCellIndex(int cell) { return boxOf[cell]; }
    /** Sums source powers (W) per box; rejects different dimensions and sources in solid cells. */
    public double[] sourcePowers(CellGrid3D grid) {
        if (grid.nx() != nx || grid.ny() != ny || grid.nz() != nz)
            throw new IllegalArgumentException("source grid dimensions differ from graph");
        double[] watts = new double[boxCount()];
        for (var source : grid.sources().entrySet()) {
            int box = boxOfCellIndex(source.getKey());
            if (box < 0 || !grid.type(source.getKey() % nx, source.getKey() / (nx * nz),
                    source.getKey() / nx % nz).isFluid())
                throw new IllegalArgumentException("source in solid cell");
            watts[box] += source.getValue();
        }
        return watts;
    }
    /** Box at point in m, or -1 outside/in solid. Upper domain faces clamp to the last cell. */
    public int boxAt(double x, double y, double z) {
        if (!(x >= 0 && y >= 0 && z >= 0 && x <= nx && y <= ny && z <= nz)) return -1;
        return boxOfCell(Math.min((int) x, nx - 1), Math.min((int) y, ny - 1), Math.min((int) z, nz - 1));
    }
}
