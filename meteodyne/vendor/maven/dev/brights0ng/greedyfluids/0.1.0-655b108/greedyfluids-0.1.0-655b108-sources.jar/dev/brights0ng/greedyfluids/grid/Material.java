// Written by Claude.
// Edited by ChatGPT: relative volumetric heat capacity for optional wall storage (M2.5).
// Edited by Claude: conductances with a given film resistance (M8a).
package dev.brights0ng.greedyfluids.grid;

/**
 * Heat-loss properties of a solid (or door) material.
 * <p>
 * A wall of {@code n} blocks between two air regions has the per-area conductance
 * {@code rhoCp / (2 * FILM_RESISTANCE + n / conductancePerBlock)} W/(m²·K), where {@code rhoCp} is the air's
 * volumetric heat capacity, and each film is the grid's ({@link CellGrid3D#filmResistance}, by default
 * {@link #FILM_RESISTANCE}). The defaults match legacy Meteodyne's {@code film} and {@code wallK}: stone has
 * {@code conductancePerBlock = 0.035 m/s} (relative conductivity 1), giving 41.77 W/(m²·K) for one block.
 *
 * @param name                display name
 * @param relHeatCapacity     volumetric heat capacity relative to air rhoCp, dimensionless, positive
 * @param conductancePerBlock per-block conductance in m/s, {@code 0.035 * relativeConductivity}
 */
public record Material(String name, double conductancePerBlock, double relHeatCapacity) {
    /** Existing material usage defaults to 3.5 times air volumetric heat capacity. */
    public Material(String name, double conductancePerBlock) {
        this(name, conductancePerBlock, 3.5);
    }
    /**
     * The default surface film resistance on each side of a wall, in s/m: legacy Meteodyne's, kept so the benches
     * stay as they were. It is about 1/1,000 of a physical still-air film (0.13 m²·K/W, 156.8 s/m at rhoCp 1206);
     * a host sets its own on the grid (M8a).
     */
    public static final double FILM_RESISTANCE = 0.15;
    /** Per-block conductance of stone (relative conductivity 1), in m/s. */
    public static final double STONE_CONDUCTANCE_PER_BLOCK = 0.035;

    public static final Material STONE = relative("stone", 1.0);
    /** Placeholder: a closed door conducts like one block of stone. */
    public static final Material DOOR = relative("door", 1.0);

    public Material {
        if (!(relHeatCapacity > 0)) {
            throw new IllegalArgumentException("relHeatCapacity must be positive: " + relHeatCapacity);
        }
        if (!(conductancePerBlock > 0)) {
            throw new IllegalArgumentException("conductancePerBlock must be positive: " + conductancePerBlock);
        }
    }

    /** A material with the given conductivity relative to stone. */
    public static Material relative(String name, double relativeConductivity) {
        return new Material(name, STONE_CONDUCTANCE_PER_BLOCK * relativeConductivity);
    }

    /** Volumetric heat capacity, J/(m³·K), for air volumetric heat capacity rhoCp in the same units. */
    public double heatCapacity(double rhoCp) {
        return relHeatCapacity * rhoCp;
    }

    /** Resistance of one block of this material, in s/m. */
    public double resistancePerBlock() {
        return 1.0 / conductancePerBlock;
    }

    /** Conductance of {@code blocks} blocks of this material with the default films, in W/(m²·K). */
    public double conductance(int blocks, double rhoCp) {
        return conductanceOfBlocks(blocks * resistancePerBlock(), rhoCp);
    }

    /** Conductance of {@code blocks} blocks of this material with films of {@code film} s/m, in W/(m²·K). */
    public double conductance(int blocks, double rhoCp, double film) {
        return conductanceOfBlocks(blocks * resistancePerBlock(), rhoCp, film);
    }

    /**
     * Conductance of a wall whose blocks sum to {@code blockResistance} s/m (mixed materials add their per-block
     * resistances), in W/(m²·K). Both surface films are included.
     */
    public static double conductanceOfBlocks(double blockResistance, double rhoCp) {
        return conductanceOfBlocks(blockResistance, rhoCp, FILM_RESISTANCE);
    }

    /** As {@link #conductanceOfBlocks(double, double)} with films of {@code film} s/m. */
    public static double conductanceOfBlocks(double blockResistance, double rhoCp, double film) {
        return rhoCp / (2 * film + blockResistance);
    }
}
