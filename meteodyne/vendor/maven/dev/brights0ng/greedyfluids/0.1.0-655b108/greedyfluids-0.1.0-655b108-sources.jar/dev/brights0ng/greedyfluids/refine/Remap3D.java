// Written by ChatGPT from Claude's M5d spec.
// Edited by Claude: clear an edited cell's unit faces (M5e1).
// Edited by Claude: optional shared gradient workspace (M6c1).
// Edited by Claude: local rasterisation per old box and a local transfer (M6c3).
// Edited by Claude: the local transfer never copies a box holding an edited cell (M7b).
package dev.brights0ng.greedyfluids.refine;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.solve.BoxGradients3D;
import dev.brights0ng.greedyfluids.solve.BoxSolver3D;
import java.util.Arrays;

/** Conservative limited cell/face-cell rasterisation and rectangle-mean transfer on a fixed domain. */
public final class Remap3D {
    private Remap3D() { }

    /** Reused workspace for one old mesh. Cells are T (°C), u, v, w (m/s); unit faces are m/s. */
    public static final class Raster {
        public final double[][] cells;
        public final double[][] unitFaces;
        private final BoxGraph3D g;
        private final BoxGradients3D gradients;
        private final double[][] q;
        private final double[][][] unlimited, limited;
        /** Local mode (M6c3): the solver prepareLocal read, and which of its boxes are rasterised so far. */
        private BoxSolver3D source;
        private final boolean[] done;
        private boolean local;
        /** Cells an edit batch wrote since the last rasterise or prepareLocal (M7b; Remap3D.markEdited). */
        private final java.util.BitSet edited = new java.util.BitSet();
        private final double[] grad = new double[3], lim = new double[3];
        private long nanos;
        /** True after prepareLocal until a full rasterise: only the boxes rasterised so far are valid. */
        public boolean isLocal() { return local; }
        /** Wall time spent rasterising into this raster since it was built, ms. */
        public double rasterMs() { return nanos * 1e-6; }

        public Raster(BoxGraph3D graph) {
            this(graph, new double[4][graph.nx() * graph.ny() * graph.nz()],
                    new double[][]{new double[(graph.nx() + 1) * graph.ny() * graph.nz()],
                        new double[graph.nx() * (graph.ny() + 1) * graph.nz()],
                        new double[graph.nx() * graph.ny() * (graph.nz() + 1)]});
        }

        /** Reuses domain-sized buffers across mesh changes. */
        public Raster(BoxGraph3D graph, double[][] cells, double[][] unitFaces) {
            this(graph, cells, unitFaces, new BoxGradients3D(graph));
        }

        /** As above, with a gradient workspace built for the same graph (for example BoxSolver3D.gradients()). */
        public Raster(BoxGraph3D graph, double[][] cells, double[][] unitFaces, BoxGradients3D shared) {
            if (shared.graph() != graph) throw new IllegalArgumentException("gradients belong to another graph");
            g = graph; this.cells = cells; this.unitFaces = unitFaces;
            gradients = shared; q = new double[4][g.boxCount()];
            unlimited = new double[4][3][g.boxCount()]; limited = new double[4][3][g.boxCount()];
            done = new boolean[g.boxCount()];
        }
    }

    /** Returned arrays match BoxSolver3D's box, interior-face and boundary setters. */
    public record Transfer(double[] temperature, double[] faceVelocity, double[] boundaryVelocity) {
        /** Installs values without projection; time, wind and doors belong to the caller. */
        public void install(BoxSolver3D to) {
            for (int i = 0; i < temperature.length; i++) to.setTemperature(i, temperature[i]);
            for (int i = 0; i < faceVelocity.length; i++) to.setFaceVelocity(i, faceVelocity[i]);
            for (int i = 0; i < boundaryVelocity.length; i++) to.setBoundaryVelocity(i, boundaryVelocity[i]);
        }
    }

    /** Limited reconstruction of all four centre fields and old unit-face velocities; allocates nothing. */
    public static void rasterise(BoxSolver3D old, Raster r) {
        if (old.graph() != r.g) throw new IllegalArgumentException("raster belongs to another mesh");
        long start = System.nanoTime();
        rasteriseAll(old, r);
        r.local = false; r.source = old; Arrays.fill(r.done, true); r.edited.clear();
        r.nanos += System.nanoTime() - start;
    }

    /**
     * Local mode (M6c3): reads old's centre fields and marks no box rasterised. rasteriseBox then fills one old
     * box's cells, interior unit faces and surface unit faces, bitwise equal to what {@link #rasterise} writes
     * there. Cells and unit faces outside rasterised boxes are stale until then.
     */
    public static void prepareLocal(BoxSolver3D old, Raster r) {
        if (old.graph() != r.g) throw new IllegalArgumentException("raster belongs to another mesh");
        long start = System.nanoTime();
        for (int b = 0; b < r.g.boxCount(); b++) r.q[0][b] = old.temperature(b);
        old.centreVelocities(r.q[1], r.q[2], r.q[3]);
        Arrays.fill(r.done, false); r.edited.clear();
        r.local = true; r.source = old;
        r.nanos += System.nanoTime() - start;
    }

    /** Rasterises old box b unless already done (local mode; a no-op after a full rasterise). */
    public static void rasteriseBox(Raster r, int b) {
        if (r.done[b]) return;
        long start = System.nanoTime();
        BoxGraph3D g = r.g;
        r.done[b] = true;
        for (int f = 0; f < 4; f++) {
            double[][] l = r.limited[f];
            r.gradients.gradientBox(b, r.q[f], r.grad);
            r.gradients.limitBox(b, r.q[f], r.grad, r.lim);
            l[0][b] = r.lim[0]; l[1][b] = r.lim[1]; l[2][b] = r.lim[2];
            double[] out = r.cells[f];
            for (int y = g.boxY0(b); y < g.boxY0(b) + g.boxSy(b); y++)
                for (int z = g.boxZ0(b); z < g.boxZ0(b) + g.boxSz(b); z++)
                    for (int x = g.boxX0(b); x < g.boxX0(b) + g.boxSx(b); x++)
                        out[(y * g.nz() + z) * g.nx() + x] = r.q[f][b] + l[0][b] * (x + 0.5 - g.boxCx(b))
                                + l[1][b] * (y + 0.5 - g.boxCy(b)) + l[2][b] * (z + 0.5 - g.boxCz(b));
        }
        // Surface unit faces: zero (solid sides), then explicit old faces and boundaries, as the full pass leaves
        // them; interior unit faces: the limited reconstruction.
        for (int axis = 0; axis < 3; axis++) {
            int ua = axis == 0 ? 1 : 0, va = axis == 2 ? 1 : 2;
            int lo = start(g, b, axis), hi = lo + size(g, b, axis);
            paint(g, r.unitFaces, axis, lo, start(g, b, ua), start(g, b, ua) + size(g, b, ua),
                    start(g, b, va), start(g, b, va) + size(g, b, va), 0);
            paint(g, r.unitFaces, axis, hi, start(g, b, ua), start(g, b, ua) + size(g, b, ua),
                    start(g, b, va), start(g, b, va) + size(g, b, va), 0);
            double[][] l = r.limited[axis + 1];
            for (int p = lo + 1; p < hi; p++)
                for (int v = start(g, b, va); v < start(g, b, va) + size(g, b, va); v++)
                    for (int u = start(g, b, ua); u < start(g, b, ua) + size(g, b, ua); u++) {
                        double x = axis == 0 ? p : u + 0.5;
                        double y = axis == 1 ? p : axis == 0 ? u + 0.5 : v + 0.5;
                        double z = axis == 2 ? p : v + 0.5;
                        r.unitFaces[axis][faceIndex(g, axis, p, u, v)] = r.q[axis + 1][b]
                                + l[0][b] * (x - g.boxCx(b)) + l[1][b] * (y - g.boxCy(b))
                                + l[2][b] * (z - g.boxCz(b));
                    }
        }
        BoxSolver3D old = r.source;
        for (int k = g.facesStart(b); k < g.facesEnd(b); k++) {
            int f = g.faceAt(k);
            paint(g, r.unitFaces, g.faceAxis(f), start(g, g.faceB(f), g.faceAxis(f)),
                    g.faceU0(f), g.faceU1(f), g.faceV0(f), g.faceV1(f), old.faceVelocity(f));
        }
        for (int k = g.boundariesStart(b); k < g.boundariesEnd(b); k++) {
            int e = g.boundaryAt(k), a = g.boundaryAxis(e);
            paint(g, r.unitFaces, a, start(g, b, a) + g.boundarySide(e) * size(g, b, a),
                    g.boundaryU0(e), g.boundaryU1(e), g.boundaryV0(e), g.boundaryV1(e), old.boundaryVelocity(e));
        }
        r.nanos += System.nanoTime() - start;
    }

    /** Rasterises the old box holding a cell index, if any (local mode). */
    public static void rasteriseCell(Raster r, int cell) {
        int b = r.g.boxOfCellIndex(cell);
        if (b >= 0) rasteriseBox(r, b);
    }

    private static void rasteriseAll(BoxSolver3D old, Raster r) {
        BoxGraph3D g = r.g;
        for (int b = 0; b < g.boxCount(); b++) r.q[0][b] = old.temperature(b);
        old.centreVelocities(r.q[1], r.q[2], r.q[3]);
        for (int f = 0; f < 4; f++) {
            double[][] u = r.unlimited[f], l = r.limited[f];
            r.gradients.gradient(r.q[f], u[0], u[1], u[2]);
            r.gradients.limit(r.q[f], u[0], u[1], u[2], l[0], l[1], l[2]);
            rasterise(g, r.q[f], l[0], l[1], l[2], r.cells[f]);
        }
        for (double[] faces : r.unitFaces) Arrays.fill(faces, 0);
        for (int b = 0; b < g.boxCount(); b++) for (int axis = 0; axis < 3; axis++) {
            int lo = start(g, b, axis), hi = lo + size(g, b, axis);
            int ua = axis == 0 ? 1 : 0, va = axis == 2 ? 1 : 2;
            for (int p = lo + 1; p < hi; p++)
                for (int v = start(g, b, va); v < start(g, b, va) + size(g, b, va); v++)
                    for (int u = start(g, b, ua); u < start(g, b, ua) + size(g, b, ua); u++) {
                        double x = axis == 0 ? p : u + 0.5;
                        double y = axis == 1 ? p : axis == 0 ? u + 0.5 : v + 0.5;
                        double z = axis == 2 ? p : v + 0.5;
                        double[][] l = r.limited[axis + 1];
                        r.unitFaces[axis][faceIndex(g, axis, p, u, v)] = r.q[axis + 1][b]
                                + l[0][b] * (x - g.boxCx(b)) + l[1][b] * (y - g.boxCy(b))
                                + l[2][b] * (z - g.boxCz(b));
                    }
        }
        // Explicit old faces override reconstruction, including zero-aperture door faces.
        for (int f = 0; f < g.faceCount(); f++)
            paint(g, r.unitFaces, g.faceAxis(f), start(g, g.faceB(f), g.faceAxis(f)),
                    g.faceU0(f), g.faceU1(f), g.faceV0(f), g.faceV1(f), old.faceVelocity(f));
        for (int k = 0; k < g.boundaryCount(); k++) {
            int b = g.boundaryBox(k), a = g.boundaryAxis(k);
            paint(g, r.unitFaces, a, start(g, b, a) + g.boundarySide(k) * size(g, b, a),
                    g.boundaryU0(k), g.boundaryU1(k), g.boundaryV0(k), g.boundaryV1(k), old.boundaryVelocity(k));
        }
    }

    /** Cell-centre reconstruction; each old box's cell offsets sum to zero, preserving its mean. */
    public static void rasterise(BoxGraph3D g, double[] q, double[] lx, double[] ly, double[] lz, double[] out) {
        Arrays.fill(out, Double.NaN);
        for (int b = 0; b < g.boxCount(); b++)
            for (int y = g.boxY0(b); y < g.boxY0(b) + g.boxSy(b); y++)
                for (int z = g.boxZ0(b); z < g.boxZ0(b) + g.boxSz(b); z++)
                    for (int x = g.boxX0(b); x < g.boxX0(b) + g.boxSx(b); x++)
                        out[(y * g.nz() + z) * g.nx() + x] = q[b] + lx[b] * (x + 0.5 - g.boxCx(b))
                                + ly[b] * (y + 0.5 - g.boxCy(b)) + lz[b] * (z + 0.5 - g.boxCz(b));
    }

    /** Compensated cell means, °C (or the input field's units). */
    public static void boxMeans(BoxGraph3D g, double[] cells, double[] out) {
        for (int b = 0; b < g.boxCount(); b++) {
            double sum = 0, correction = 0;
            for (int y = g.boxY0(b); y < g.boxY0(b) + g.boxSy(b); y++)
                for (int z = g.boxZ0(b); z < g.boxZ0(b) + g.boxSz(b); z++)
                    for (int x = g.boxX0(b); x < g.boxX0(b) + g.boxSx(b); x++) {
                        double value = cells[(y * g.nz() + z) * g.nx() + x] - correction;
                        double next = sum + value; correction = (next - sum) - value; sum = next;
                    }
            out[b] = sum / g.boxVolume(b);
        }
    }

    /** Builds mean temperatures and face velocities on a new graph on the same cells. */
    public static Transfer transfer(Raster r, BoxGraph3D g) {
        if (r.g.nx() != g.nx() || r.g.ny() != g.ny() || r.g.nz() != g.nz())
            throw new IllegalArgumentException("remap domain changed");
        if (r.local) return transferLocal(r, g);
        double[] t = new double[g.boxCount()], faces = new double[g.faceCount()], boundaries = new double[g.boundaryCount()];
        boxMeans(g, r.cells[0], t);
        for (int f = 0; f < faces.length; f++)
            faces[f] = mean(g, r.unitFaces, g.faceAxis(f), start(g, g.faceB(f), g.faceAxis(f)),
                    g.faceU0(f), g.faceU1(f), g.faceV0(f), g.faceV1(f));
        for (int k = 0; k < boundaries.length; k++) {
            int b = g.boundaryBox(k), a = g.boundaryAxis(k);
            boundaries[k] = mean(g, r.unitFaces, a, start(g, b, a) + g.boundarySide(k) * size(g, b, a),
                    g.boundaryU0(k), g.boundaryU1(k), g.boundaryV0(k), g.boundaryV1(k));
        }
        return new Transfer(t, faces, boundaries);
    }

    /**
     * Local transfer (M6c3). A new box identical to an old box takes that box's mean T, a face between two such
     * boxes the old face's velocity, and their boundaries the old boundary velocities, exactly. Everything else
     * lies in the cells of old boxes that have no identical new box; those are rasterised first and averaged as in
     * the full transfer. The full transfer gets the copied values back from the raster only to roundoff.
     */
    private static Transfer transferLocal(Raster r, BoxGraph3D g) {
        BoxGraph3D old = r.g;
        BoxSolver3D src = r.source;
        int[] same = new int[g.boxCount()];
        boolean[] kept = new boolean[old.boxCount()];
        for (int b = 0; b < g.boxCount(); b++) {
            int ob = old.boxOfCell(g.boxX0(b), g.boxY0(b), g.boxZ0(b));
            boolean equal = ob >= 0 && old.boxX0(ob) == g.boxX0(b) && old.boxY0(ob) == g.boxY0(b)
                    && old.boxZ0(ob) == g.boxZ0(b) && old.boxSx(ob) == g.boxSx(b) && old.boxSy(ob) == g.boxSy(b)
                    && old.boxSz(ob) == g.boxSz(b);
            same[b] = equal ? ob : -1;
            if (equal) kept[ob] = true;
        }
        // M7b: a door placed or taken out can leave its 1×1×1 box where it was; the edited raster values, not the old
        // box, must reach it. An AIR/SOLID edit never leaves an identical box at an edited cell, so for those
        // batches this changes nothing.
        for (int c = r.edited.nextSetBit(0); c >= 0; c = r.edited.nextSetBit(c + 1)) {
            int b = g.boxOfCellIndex(c);
            if (b >= 0 && same[b] >= 0) { kept[same[b]] = false; same[b] = -1; }
        }
        for (int ob = 0; ob < old.boxCount(); ob++) if (!kept[ob]) rasteriseBox(r, ob);
        double[] t = new double[g.boxCount()], faces = new double[g.faceCount()], boundaries = new double[g.boundaryCount()];
        for (int b = 0; b < g.boxCount(); b++) {
            if (same[b] >= 0) { t[b] = src.temperature(same[b]); continue; }
            double sum = 0, correction = 0;
            for (int y = g.boxY0(b); y < g.boxY0(b) + g.boxSy(b); y++)
                for (int z = g.boxZ0(b); z < g.boxZ0(b) + g.boxSz(b); z++)
                    for (int x = g.boxX0(b); x < g.boxX0(b) + g.boxSx(b); x++) {
                        double value = r.cells[0][(y * g.nz() + z) * g.nx() + x] - correction;
                        double next = sum + value; correction = (next - sum) - value; sum = next;
                    }
            t[b] = sum / g.boxVolume(b);
        }
        for (int f = 0; f < faces.length; f++) {
            int a = same[g.faceA(f)], b = same[g.faceB(f)], oldFace = -1;
            if (a >= 0 && b >= 0)
                for (int k = old.facesStart(a); k < old.facesEnd(a); k++) {
                    int of = old.faceAt(k);
                    if (old.faceA(of) == a && old.faceB(of) == b || old.faceA(of) == b && old.faceB(of) == a) { oldFace = of; break; }
                }
            faces[f] = oldFace >= 0 ? src.faceVelocity(oldFace)
                    : mean(g, r.unitFaces, g.faceAxis(f), start(g, g.faceB(f), g.faceAxis(f)),
                            g.faceU0(f), g.faceU1(f), g.faceV0(f), g.faceV1(f));
        }
        for (int k = 0; k < boundaries.length; k++) {
            int b = g.boundaryBox(k), a = g.boundaryAxis(k), ob = same[b], oldK = -1;
            if (ob >= 0)
                for (int j = old.boundariesStart(ob); j < old.boundariesEnd(ob); j++) {
                    int e = old.boundaryAt(j);
                    if (old.boundaryAxis(e) == a && old.boundarySide(e) == g.boundarySide(k)
                            && old.boundaryU0(e) == g.boundaryU0(k) && old.boundaryV0(e) == g.boundaryV0(k)
                            && old.boundaryU1(e) == g.boundaryU1(k) && old.boundaryV1(e) == g.boundaryV1(k)) { oldK = e; break; }
                }
            boundaries[k] = oldK >= 0 ? src.boundaryVelocity(oldK)
                    : mean(g, r.unitFaces, a, start(g, b, a) + g.boundarySide(k) * size(g, b, a),
                            g.boundaryU0(k), g.boundaryU1(k), g.boundaryV0(k), g.boundaryV1(k));
        }
        return new Transfer(t, faces, boundaries);
    }

    /** Marks a cell an edit batch wrote, so the local transfer reads it from the raster (M7b). */
    static void markEdited(Raster r, int cell) {
        r.edited.set(cell);
    }

    /** Zeroes the six unit faces (m/s) of cell (x, y, z) in an edit raster. */
    static void clearCellFaces(Raster r, int x, int y, int z) {
        BoxGraph3D g = r.g;
        for (int p = x; p <= x + 1; p++) r.unitFaces[0][faceIndex(g, 0, p, y, z)] = 0;
        for (int p = y; p <= y + 1; p++) r.unitFaces[1][faceIndex(g, 1, p, x, z)] = 0;
        for (int p = z; p <= z + 1; p++) r.unitFaces[2][faceIndex(g, 2, p, x, y)] = 0;
    }

    private static int start(BoxGraph3D g, int b, int a) {
        return a == 0 ? g.boxX0(b) : a == 1 ? g.boxY0(b) : g.boxZ0(b);
    }
    private static int size(BoxGraph3D g, int b, int a) {
        return a == 0 ? g.boxSx(b) : a == 1 ? g.boxSy(b) : g.boxSz(b);
    }
    // Preserve cell storage order on tangential axes: axis0 (y,z), axis1 (x,z), axis2 (x,y).
    private static int faceIndex(BoxGraph3D g, int a, int p, int u, int v) {
        return a == 0 ? (u * g.nz() + v) * (g.nx() + 1) + p
                : a == 1 ? (p * g.nz() + v) * g.nx() + u : (v * (g.nz() + 1) + p) * g.nx() + u;
    }
    private static void paint(BoxGraph3D g, double[][] faces, int a, int p,
            int u0, int u1, int v0, int v1, double value) {
        for (int v = v0; v < v1; v++) for (int u = u0; u < u1; u++)
            faces[a][faceIndex(g, a, p, u, v)] = value;
    }
    private static double mean(BoxGraph3D g, double[][] faces, int a, int p, int u0, int u1, int v0, int v1) {
        double sum = 0;
        for (int v = v0; v < v1; v++) for (int u = u0; u < u1; u++) sum += faces[a][faceIndex(g, a, p, u, v)];
        return sum / ((u1 - u0) * (v1 - v0));
    }
}
