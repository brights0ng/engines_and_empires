// Written by ChatGPT from Claude's M5b spec.
// Edited by Claude: side means and box geometry packed per box (M6e3).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import java.util.Arrays;

/**
 * Full-side flux means (m/s) and axis-linear velocity reconstruction. Side means and box geometry are packed per
 * box (six doubles each), so a sample reads two short runs of memory instead of twelve arrays (M6e3); the
 * arithmetic is unchanged.
 */
final class Reconstruction3D {
    private final BoxGraph3D g;
    private final int n;
    /** Side means of box i at [6i, 6i + 6): −x, +x, −y, +y, −z, +z, m/s. */
    private final double[] sides;
    /** Box i at [6i, 6i + 6): low x, extent x, low y, extent y, low z, extent z, m. */
    private final double[] geometry;
    private final double[][] area;
    private final double[] faceArea, boundaryArea;
    Reconstruction3D(BoxGraph3D graph) {
        g = graph; n = g.boxCount();
        sides = new double[6 * n]; geometry = new double[6 * n]; area = new double[3][n];
        faceArea = new double[g.faceCount()]; boundaryArea = new double[g.boundaryCount()];
        for (int f = 0; f < faceArea.length; f++) faceArea[f] = g.faceArea(f);
        for (int k = 0; k < boundaryArea.length; k++) boundaryArea[k] = g.boundaryArea(k);
        for (int i = 0; i < n; i++) {
            area[0][i] = (double) g.boxSy(i) * g.boxSz(i);
            area[1][i] = (double) g.boxSx(i) * g.boxSz(i);
            area[2][i] = (double) g.boxSx(i) * g.boxSy(i);
            for (int axis = 0; axis < 3; axis++) {
                geometry[6 * i + 2 * axis] = low(g, i, axis); geometry[6 * i + 2 * axis + 1] = extent(g, i, axis);
            }
        }
    }
    void update(FlowState3D s) {
        Arrays.fill(sides, 0);
        for (int f = 0; f < g.faceCount(); f++) {
            double flux = s.u[f] * g.aperture(f) * faceArea[f];
            int axis = g.faceAxis(f);
            sides[6 * g.faceA(f) + 2 * axis + 1] += flux;
            sides[6 * g.faceB(f) + 2 * axis] += flux;
        }
        for (int k = 0; k < g.boundaryCount(); k++)
            sides[6 * g.boundaryBox(k) + 2 * g.boundaryAxis(k) + g.boundarySide(k)]
                    += s.ub[k] * g.boundaryAperture(k) * boundaryArea[k];
        for (int i = 0; i < n; i++) for (int side = 0; side < 6; side++)
            sides[6 * i + side] /= area[side / 2][i];
    }
    boolean sample(double x, double y, double z, double[] out) {
        int i = g.boxAt(x, y, z);
        if (i < 0) return false;
        int o = 6 * i;
        double fx = Math.min(1, Math.max(0, (x - geometry[o]) / geometry[o + 1]));
        double fy = Math.min(1, Math.max(0, (y - geometry[o + 2]) / geometry[o + 3]));
        double fz = Math.min(1, Math.max(0, (z - geometry[o + 4]) / geometry[o + 5]));
        out[0] = sides[o] + fx * (sides[o + 1] - sides[o]);
        out[1] = sides[o + 2] + fy * (sides[o + 3] - sides[o + 2]);
        out[2] = sides[o + 4] + fz * (sides[o + 5] - sides[o + 4]);
        return true;
    }
    void sideVelocities(int box, double[] out) {
        System.arraycopy(sides, 6 * box, out, 0, 6);
    }
    void centreVelocities(double[] ux, double[] uy, double[] uz) {
        for (int i = 0, o = 0; i < n; i++, o += 6) {
            ux[i] = 0.5 * (sides[o] + sides[o + 1]);
            uy[i] = 0.5 * (sides[o + 2] + sides[o + 3]);
            uz[i] = 0.5 * (sides[o + 4] + sides[o + 5]);
        }
    }
    static double low(BoxGraph3D g, int box, int axis) {
        return axis == 0 ? g.boxX0(box) : axis == 1 ? g.boxY0(box) : g.boxZ0(box);
    }
    static double extent(BoxGraph3D g, int box, int axis) {
        return axis == 0 ? g.boxSx(box) : axis == 1 ? g.boxSy(box) : g.boxSz(box);
    }
}
