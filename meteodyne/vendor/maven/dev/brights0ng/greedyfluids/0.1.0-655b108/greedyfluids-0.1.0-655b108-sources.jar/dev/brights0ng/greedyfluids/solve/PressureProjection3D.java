// Written by ChatGPT from Claude's M5b spec.
// Edited by Claude: masked remap projection (M5e2).
// Edited by ChatGPT from Claude's M6a spec.
// Edited by ChatGPT from Claude's M6b1 spec.
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D.BoundaryKind;
import java.util.Arrays;

/** Aperture-weighted pressure CSR, P1w PCG, and sealed-component diagnostics. */
final class PressureProjection3D {
    private final BoxGraph3D g;
    private final SolverConfig3D c;
    private final Pcg pcg;
    private final int[] diagonal, ab, ba;
    // Cache the area/dn geometry separately to preserve (ap * area) / dn operation order.
    private final double[] faceArea, faceDn, bndArea, bndDn, rhs, invVolume, compSum, compAbsSum;

    PressureProjection3D(BoxGraph3D graph, SolverConfig3D config) {
        g = graph; c = config;
        int n = g.boxCount(), nf = g.faceCount();
        int[] rows = new int[n + 1];
        for (int i = 0; i < n; i++) rows[i + 1] = rows[i] + 1 + g.facesEnd(i) - g.facesStart(i);
        int[] cols = new int[rows[n]], fill = rows.clone();
        for (int i = 0; i < n; i++) cols[fill[i]++] = i;
        for (int f = 0; f < nf; f++) {
            cols[fill[g.faceA(f)]++] = g.faceB(f);
            cols[fill[g.faceB(f)]++] = g.faceA(f);
        }
        pcg = new Pcg(rows, cols, Pcg.Preconditioner.MG);
        diagonal = new int[n]; ab = new int[nf]; ba = new int[nf];
        for (int i = 0; i < n; i++) diagonal[i] = Arrays.binarySearch(cols, rows[i], rows[i + 1], i);
        faceArea = new double[nf]; faceDn = new double[nf];
        for (int f = 0; f < nf; f++) {
            int a = g.faceA(f), b = g.faceB(f);
            ab[f] = Arrays.binarySearch(cols, rows[a], rows[a + 1], b);
            ba[f] = Arrays.binarySearch(cols, rows[b], rows[b + 1], a);
            faceArea[f] = g.faceArea(f); faceDn[f] = g.faceDn(f);
        }
        bndDn = new double[g.boundaryCount()]; bndArea = new double[bndDn.length];
        for (int k = 0; k < bndDn.length; k++) {
            bndDn[k] = 0.5 * Reconstruction3D.extent(g, g.boundaryBox(k), g.boundaryAxis(k)) + 0.5;
            bndArea[k] = g.boundaryArea(k);
        }
        rhs = new double[n]; invVolume = new double[n]; compSum = new double[n]; compAbsSum = new double[n];
        for (int i = 0; i < n; i++) invVolume[i] = 1.0 / g.boxVolume(i);
    }

    int project(FlowState3D s, double[] shiftOrNull, SealedComponents3D components, StepStats stats) {
        return project(s, shiftOrNull, components, stats, null, 0);
    }
    /** As project, solving only the listed rows (phi elsewhere held as given) when rows is non-null. */
    int project(FlowState3D s, double[] shiftOrNull, SealedComponents3D components, StepStats stats,
            int[] rows, int nRows) {
        double[] values = pcg.values();
        Arrays.fill(values, 0); Arrays.fill(rhs, 0);
        for (int f = 0; f < g.faceCount(); f++) {
            double ap = g.aperture(f);
            if (ap == 0) continue;
            int a = g.faceA(f), b = g.faceB(f);
            // Keep the specified multiplication order, including for future fractional apertures.
            double coefficient = ap * faceArea[f] / faceDn[f];
            values[ab[f]] = -coefficient; values[ba[f]] = -coefficient;
            values[diagonal[a]] += coefficient; values[diagonal[b]] += coefficient;
            double flux = (s.u[f] + (shiftOrNull == null ? 0 : shiftOrNull[f])) * ap * faceArea[f];
            rhs[a] -= flux; rhs[b] += flux;
        }
        for (int k = 0; k < g.boundaryCount(); k++) {
            int b = g.boundaryBox(k);
            rhs[b] -= (g.boundarySide(k) == 1 ? 1 : -1) * s.ub[k] * g.boundaryAperture(k) * bndArea[k];
            if (open(k)) values[diagonal[b]] += g.boundaryAperture(k) * bndArea[k] / bndDn[k];
        }
        long start = System.nanoTime();
        int iterations = rows == null ? pcg.solve(s.phi, rhs, invVolume, c.pcgTolerance(), c.pcgMaxIterations())
                : pcg.solveMasked(s.phi, rhs, invVolume, c.pcgTolerance(), c.pcgMaxIterations(), rows, nRows);
        stats.pcgInitialResidual = pcg.lastInitialResidual();
        stats.pcgFinalResidual = pcg.lastResidual();
        stats.pcgItBelow4 = pcg.lastIterationsBelow(4);
        stats.pcgItBelow5 = pcg.lastIterationsBelow(5);
        stats.pcgItBelow6 = pcg.lastIterationsBelow(6);
        stats.pcgMs = (System.nanoTime() - start) * 1e-6;
        stats.pcgFactorMs = pcg.lastFactorMs(); stats.pcgPivotFixes = pcg.lastPivotFixes();
        stats.pcgExit = pcg.lastExit(); stats.pcgTrueResidual = pcg.lastTrueResidual();
        for (int f = 0; f < g.faceCount(); f++) if (g.aperture(f) > 0)
            s.u[f] -= (s.phi[g.faceB(f)] - s.phi[g.faceA(f)]) / faceDn[f]
                    - (shiftOrNull == null ? 0 : shiftOrNull[f]);
        for (int k = 0; k < g.boundaryCount(); k++) if (open(k))
            s.ub[k] -= (g.boundarySide(k) == 1 ? -s.phi[g.boundaryBox(k)] : s.phi[g.boundaryBox(k)]) / bndDn[k];
        recordSealedStats(s, components, stats);
        return iterations;
    }
    private boolean open(int k) {
        return g.boundaryKind(k) == BoundaryKind.OPEN && g.boundaryAperture(k) > 0;
    }
    private void recordSealedStats(FlowState3D s, SealedComponents3D components, StepStats stats) {
        stats.sealedComponents = components.sealedCount(); stats.sealedVolume = components.sealedVolume();
        stats.pocketCount = components.pocketCount(); stats.pocketVolume = components.pocketVolume();
        stats.openedInflowFaces = components.openedFaces(); stats.roofedInflowFaces = g.roofedInflowFaces();
        stats.pocketInflow = components.pocketInflow(); stats.maxOutflowSpeed = components.maxOutflowSpeed();
        stats.maxSealedMeanPhi = 0; stats.maxSealedRhsImbalance = 0;
        if (components.sealedCount() == 0) return;
        Arrays.fill(compSum, 0); Arrays.fill(compAbsSum, 0);
        for (int i = 0; i < g.boxCount(); i++) {
            int comp = components.componentOfBox(i);
            if (comp >= 0 && components.isComponentSealed(comp)) compSum[comp] += g.boxVolume(i) * s.phi[i];
        }
        for (int comp = 0; comp < components.componentCount(); comp++) if (components.isComponentSealed(comp)) {
            stats.maxSealedMeanPhi = Math.max(stats.maxSealedMeanPhi,
                    Math.abs(compSum[comp] / components.componentVolume(comp)));
            compSum[comp] = 0;
        }
        for (int i = 0; i < g.boxCount(); i++) {
            int comp = components.componentOfBox(i);
            if (comp >= 0 && components.isComponentSealed(comp)) {
                compSum[comp] += rhs[i]; compAbsSum[comp] += Math.abs(rhs[i]);
            }
        }
        for (int comp = 0; comp < components.componentCount(); comp++)
            if (components.isComponentSealed(comp) && compAbsSum[comp] > 0)
                stats.maxSealedRhsImbalance = Math.max(stats.maxSealedRhsImbalance,
                        Math.abs(compSum[comp]) / compAbsSum[comp]);
    }
}
