// Edited by ChatGPT: Bright's P1w default selection (M3.5 part b1).
// Written by ChatGPT: settings specified by Bright for M3.5.
package dev.brights0ng.greedyfluids.solve;

/**
 * Dimensionless aggregation V-cycle settings.
 * @param aggregation aggregation rule
 * @param sweeps forward and backward sweep counts
 * @param coarseScale ω multiplies the coarse correction (x += ω·P·x_c); ω &lt; 2 keeps the V-cycle SPD
 * @param coarsestMax target maximum coarsest node count
 */
public record MgSettings(Aggregation aggregation, int sweeps, double coarseScale, int coarsestMax) {
    public enum Aggregation { GEOMETRIC, PAIRWISE }

    /** P1w, chosen from the M3.5a capture bench (Bright, 2026-11-01). */
    public static final MgSettings DEFAULT = new MgSettings(Aggregation.PAIRWISE, 1, 1.6, 64);

    public MgSettings {
        java.util.Objects.requireNonNull(aggregation, "aggregation");
        if (sweeps < 1 || !(coarseScale > 0 && coarseScale < 2) || coarsestMax < 1 || coarsestMax > 512) {
            throw new IllegalArgumentException("invalid multigrid settings");
        }
    }
}
