// Edited by ChatGPT: opt-in aggregation multigrid and Jacobi masked fallback (M3.5).
// Edited by ChatGPT: report-only remap projection variants (M3c part 2b).
// Written by Claude.
// Edited by ChatGPT: report-only exits, optional true residual and kernel bench hooks (M2f).
// Edited by ChatGPT: preserve original Jacobi multiply order alongside sorted IC(0) storage (M2e).
// Edited by ChatGPT: allocation-free IC(0), sorted CSR rows and factor diagnostics (M2d).
// Edited by ChatGPT from Claude's M6a spec.
package dev.brights0ng.greedyfluids.solve;

/**
 * Jacobi-, IC(0)- or aggregation-MG-preconditioned conjugate gradient for a symmetric positive (semi-)definite matrix in CSR form. The
 * pattern is fixed at construction; the owner rewrites {@link #values()} before each solve. All work arrays are
 * preallocated; only MG hierarchy setup (on first use or changed values/settings/coordinates) may allocate.
 * <p>
 * Rows whose diagonal is zero (unknowns with no couplings, such as a fully closed door box) are left unchanged.
 * Consistent singular systems (closed domains, pure Neumann) are fine.
 */
public final class Pcg {
    public enum Preconditioner { JACOBI, IC0, MG }
    public enum Exit { CONVERGED, ITERATION_CAP, RZ_BREAKDOWN, PQ_BREAKDOWN }

    private final Preconditioner preconditioner;
    private MgSettings mgSettings = MgSettings.DEFAULT;
    private AggregationMg mg;
    private double[] mgValues, coordinateX, coordinateY;
    private int setupCount;

    /** Sets dimensionless MG settings and invalidates its hierarchy. */
    public void setMgSettings(MgSettings settings) {
        mgSettings = java.util.Objects.requireNonNull(settings, "settings");
        mg = null;
    }

    /** Copies n box-centre coordinates in metres and invalidates the MG hierarchy. */
    public void setCoordinates(double[] x, double[] y) {
        if (x.length != n || y.length != n) throw new IllegalArgumentException("coordinate length");
        coordinateX = x.clone();
        coordinateY = y.clone();
        mg = null;
    }

    private final int[] lowerPtr, lowerSlots;
    private final int[] multiplySlots;
    private final double[] factor, diagonal, y;
    private int lastPivotFixes;
    private double lastFactorMs;
    private final int n;
    private final int[] rowPtr;
    private final int[] cols;
    private final double[] values;
    private final int[] diagSlot;
    private final double[] invDiag;
    private final double[] r;
    private final double[] z;
    private final double[] p;
    private final double[] q;
    private final double[] trueResidualScratch;
    private final boolean[] active;
    private final int[] orderedRows;
    private double lastResidual;
    private double lastInitialResidual = Double.NaN;
    private int lastItBelow4 = -1, lastItBelow5 = -1, lastItBelow6 = -1;
    private Exit lastExit;
    private boolean trueResidualCheck;
    private double lastTrueResidual = Double.NaN;

    /**
     * @param rowPtr CSR row pointers, length n + 1
     * @param cols   CSR column indices; every row must contain its diagonal
     */
    public Pcg(int[] rowPtr, int[] cols) {
        this(rowPtr, cols, Preconditioner.JACOBI);
    }

    /** Sorts the supplied columns in place; values() follows that sorted pattern. */
    public Pcg(int[] rowPtr, int[] cols, Preconditioner preconditioner) {
        this.preconditioner = preconditioner;
        n = rowPtr.length - 1;
        this.rowPtr = rowPtr;
        this.cols = cols;
        int[] originalColumns = cols.clone();
        multiplySlots = new int[cols.length];
        lowerPtr = new int[n + 1];
        for (int i = 0; i < n; i++) {
            java.util.Arrays.sort(cols, rowPtr[i], rowPtr[i + 1]);
            for (int slot = rowPtr[i]; slot < rowPtr[i + 1]; slot++) {
                multiplySlots[slot] = java.util.Arrays.binarySearch(cols, rowPtr[i], rowPtr[i + 1], originalColumns[slot]);
            }
            int count = 0;
            for (int slot = rowPtr[i]; slot < rowPtr[i + 1] && cols[slot] < i; slot++) count++;
            lowerPtr[i + 1] = lowerPtr[i] + count;
        }
        lowerSlots = new int[lowerPtr[n]];
        for (int i = 0; i < n; i++) for (int j = lowerPtr[i]; j < lowerPtr[i + 1]; j++) {
            lowerSlots[j] = rowPtr[i] + j - lowerPtr[i];
        }
        factor = new double[cols.length];
        diagonal = new double[n];
        y = new double[n];
        values = new double[cols.length];
        diagSlot = new int[n];
        for (int i = 0; i < n; i++) {
            diagSlot[i] = -1;
            for (int k = rowPtr[i]; k < rowPtr[i + 1]; k++) {
                if (cols[k] == i) {
                    diagSlot[i] = k;
                }
            }
            if (diagSlot[i] < 0) {
                throw new IllegalArgumentException("row " + i + " has no diagonal entry");
            }
        }
        invDiag = new double[n];
        r = new double[n];
        z = new double[n];
        p = new double[n];
        q = new double[n];
        trueResidualScratch = new double[n];
        active = new boolean[n];
        orderedRows = new int[n];
    }

    /** The matrix values, aligned with the column array sorted in place at construction. */
    public double[] values() {
        return values;
    }

    /** Pivot fixes in the last factorisation (count). */
    public int lastPivotFixes() { return lastPivotFixes; }

    /** Last IC(0) factor or MG setup wall time, ms; zero for Jacobi or a reused MG hierarchy. */
    public double lastFactorMs() { return lastFactorMs; }

    public int size() {
        return n;
    }

    /** Max |residual_i · scale_i| after the last solve. */
    public double lastResidual() {
        return lastResidual;
    }

    /** Initial max |residual_i · scale_i|, in the stopping test's units. */
    public double lastInitialResidual() { return lastInitialResidual; }

    /** First iteration below 10^-exponent (4, 5 or 6); 0 if initially below, −1 if never. */
    public int lastIterationsBelow(int exponent) {
        return switch (exponent) {
            case 4 -> lastItBelow4;
            case 5 -> lastItBelow5;
            case 6 -> lastItBelow6;
            default -> throw new IllegalArgumentException("exponent must be 4, 5 or 6");
        };
    }

    private void beginTrace() {
        lastInitialResidual = lastResidual;
        lastItBelow4 = lastItBelow5 = lastItBelow6 = -1;
        trace(0);
    }

    private void trace(int it) {
        if (lastItBelow4 < 0 && lastResidual < 1e-4) lastItBelow4 = it;
        if (lastItBelow5 < 0 && lastResidual < 1e-5) lastItBelow5 = it;
        if (lastItBelow6 < 0 && lastResidual < 1e-6) lastItBelow6 = it;
    }

    /** Reason the last solve stopped; null before the first solve. */
    public Exit lastExit() { return lastExit; }

    /** Enables a report-only true residual check after each solve; off by default. */
    public void setTrueResidualCheck(boolean enabled) {
        trueResidualCheck = enabled;
        if (!enabled) lastTrueResidual = Double.NaN;
    }

    /** Max |(b − A · x)_i · scale_i|, in the stopping test's units; NaN when checking is off. */
    public double lastTrueResidual() { return lastTrueResidual; }

    /**
     * Solves A x = b in place, starting from the current x.
     *
     * @param scale    per-row weight in the stopping test (for the pressure solve, 1 / box volume)
     * @param tol      stop when max |r_i · scale_i| &lt; tol
     * @param maxIter  iteration cap
     * @return iterations used
     */
    public int solve(double[] x, double[] b, double[] scale, double tol, int maxIter) {
        for (int i = 0; i < n; i++) {
            double d = values[diagSlot[i]];
            invDiag[i] = d > 0 ? 1.0 / d : 0;
        }
        lastPivotFixes = 0;
        lastFactorMs = 0;
        if (preconditioner == Preconditioner.IC0) {
            long start = System.nanoTime();
            factor();
            lastFactorMs = (System.nanoTime() - start) * 1e-6;
        } else if (preconditioner == Preconditioner.MG && (mg == null || !java.util.Arrays.equals(values, mgValues))) {
            benchSetup();
        }
        multiply(x, q);
        double rz = 0;
        for (int i = 0; i < n; i++) {
            r[i] = invDiag[i] == 0 ? 0 : b[i] - q[i];
        }
        apply();
        for (int i = 0; i < n; i++) {
            p[i] = z[i];
            rz += r[i] * z[i];
        }
        lastResidual = maxScaled(scale);
        beginTrace();
        int it = 0;
        lastExit = null;
        while (lastResidual >= tol && it < maxIter && rz > 0) {
            multiply(p, q);
            double pq = 0;
            for (int i = 0; i < n; i++) {
                pq += p[i] * q[i];
            }
            if (!(pq > 0)) {
                lastExit = Exit.PQ_BREAKDOWN;
                break;
            }
            double alpha = rz / pq;
            double rzNew = 0;
            for (int i = 0; i < n; i++) {
                x[i] += alpha * p[i];
                r[i] -= alpha * q[i];
            }
            apply();
            for (int i = 0; i < n; i++) rzNew += r[i] * z[i];
            it++;
            lastResidual = maxScaled(scale);
            trace(it);
            double beta = rzNew / rz;
            rz = rzNew;
            for (int i = 0; i < n; i++) {
                p[i] = z[i] + beta * p[i];
            }
        }
        if (lastExit == null) {
            lastExit = lastResidual < tol ? Exit.CONVERGED
                    : it == maxIter ? Exit.ITERATION_CAP : Exit.RZ_BREAKDOWN;
        }
        if (trueResidualCheck) {
            multiply(x, trueResidualScratch);
            double m = 0;
            for (int i = 0; i < n; i++) {
                m = Math.max(m, Math.abs((b[i] - trueResidualScratch[i]) * scale[i]));
            }
            lastTrueResidual = m;
        }
        return it;
    }

    /**
     * Solves only the listed rows, holding all other x entries fixed. Rows must be distinct.
     * The matrix and scale units, tolerance and iteration cap are as in {@link #solve}.
     * MG uses Jacobi on the listed rows, including Jacobi multiply order.
     * Work arrays and the restricted IC(0) factor are reused; this method allocates nothing.
     * @return iterations used (count)
     */
    public int solveMasked(double[] x, double[] b, double[] scale, double tol, int maxIter,
            int[] rows, int nRows) {
        if (nRows < 0 || nRows > n) throw new IllegalArgumentException("row count");
        java.util.Arrays.fill(active, false);
        java.util.Arrays.fill(p, 0);
        java.util.Arrays.fill(factor, 0);
        for (int row = 0; row < nRows; row++) {
            int i = rows[row];
            if (i < 0 || i >= n || active[i]) throw new IllegalArgumentException("invalid or duplicate row");
            active[i] = true;
        }
        // IC(0) triangular passes need natural row order; scanning flags reuses primitive storage.
        for (int i = 0, row = 0; i < n; i++) if (active[i]) orderedRows[row++] = i;
        for (int row = 0; row < nRows; row++) {
            int i = rows[row];
            double d = values[diagSlot[i]];
            invDiag[i] = d > 0 ? 1.0 / d : 0;
        }
        lastPivotFixes = 0;
        lastFactorMs = 0;
        if (preconditioner == Preconditioner.IC0) {
            long start = System.nanoTime();
            factorMasked(nRows);
            lastFactorMs = (System.nanoTime() - start) * 1e-6;
        }
        multiplyMasked(x, q, rows, nRows);
        double rz = 0;
        for (int row = 0; row < nRows; row++) {
            int i = rows[row];
            r[i] = invDiag[i] == 0 ? 0 : b[i] - q[i];
        }
        applyMasked(nRows);
        for (int row = 0; row < nRows; row++) {
            int i = rows[row];
            p[i] = z[i];
            rz += r[i] * z[i];
        }
        lastResidual = maxScaledMasked(scale, rows, nRows);
        beginTrace();
        int it = 0;
        lastExit = null;
        while (lastResidual >= tol && it < maxIter && rz > 0) {
            multiplyMasked(p, q, rows, nRows);
            double pq = 0;
            for (int row = 0; row < nRows; row++) {
                int i = rows[row];
                pq += p[i] * q[i];
            }
            if (!(pq > 0)) {
                lastExit = Exit.PQ_BREAKDOWN;
                break;
            }
            double alpha = rz / pq;
            double rzNew = 0;
            for (int row = 0; row < nRows; row++) {
                int i = rows[row];
                x[i] += alpha * p[i];
                r[i] -= alpha * q[i];
            }
            applyMasked(nRows);
            for (int row = 0; row < nRows; row++) {
                int i = rows[row];
                rzNew += r[i] * z[i];
            }
            it++;
            lastResidual = maxScaledMasked(scale, rows, nRows);
            trace(it);
            double beta = rzNew / rz;
            rz = rzNew;
            for (int row = 0; row < nRows; row++) {
                int i = rows[row];
                p[i] = z[i] + beta * p[i];
            }
        }
        if (lastExit == null) {
            lastExit = lastResidual < tol ? Exit.CONVERGED
                    : it == maxIter ? Exit.ITERATION_CAP : Exit.RZ_BREAKDOWN;
        }
        if (trueResidualCheck) {
            multiplyMasked(x, trueResidualScratch, rows, nRows);
            double m = 0;
            for (int row = 0; row < nRows; row++) {
                int i = rows[row];
                m = Math.max(m, Math.abs((b[i] - trueResidualScratch[i]) * scale[i]));
            }
            lastTrueResidual = m;
        }
        return it;
    }

    private void factorMasked(int nRows) {
        for (int row = 0; row < nRows; row++) {
            int i = orderedRows[row];
            double aii = values[diagSlot[i]];
            double squares = 0;
            for (int ij = lowerPtr[i]; ij < lowerPtr[i + 1]; ij++) {
                int slot = lowerSlots[ij], j = cols[slot];
                if (!active[j]) continue;
                double sum = 0;
                int im = lowerPtr[i], jm = lowerPtr[j];
                while (im < ij && jm < lowerPtr[j + 1]) {
                    int is = lowerSlots[im], js = lowerSlots[jm];
                    int a = cols[is], b = cols[js];
                    if (a == b) { sum += factor[is] * factor[js]; im++; jm++; }
                    else if (a < b) im++;
                    else jm++;
                }
                double lij = aii == 0 || diagonal[j] == 0 ? 0 : (values[slot] - sum) / diagonal[j];
                factor[slot] = lij;
                squares += lij * lij;
            }
            double d = aii - squares;
            if (aii == 0) diagonal[i] = 0;
            else if (d <= 1e-12 * aii) {
                diagonal[i] = Math.sqrt(aii);
                lastPivotFixes++;
            } else diagonal[i] = Math.sqrt(d);
        }
    }

    private void applyMasked(int nRows) {
        if (preconditioner != Preconditioner.IC0) {
            for (int row = 0; row < nRows; row++) {
                int i = orderedRows[row];
                z[i] = r[i] * invDiag[i];
            }
            return;
        }
        for (int row = 0; row < nRows; row++) {
            int i = orderedRows[row];
            double sum = r[i];
            for (int k = lowerPtr[i]; k < lowerPtr[i + 1]; k++) {
                int slot = lowerSlots[k];
                if (active[cols[slot]]) sum -= factor[slot] * y[cols[slot]];
            }
            y[i] = diagonal[i] == 0 ? 0 : sum / diagonal[i];
        }
        for (int row = nRows - 1; row >= 0; row--) {
            int i = orderedRows[row];
            z[i] = diagonal[i] == 0 ? 0 : y[i] / diagonal[i];
            if (diagonal[i] == 0) continue;
            for (int k = lowerPtr[i]; k < lowerPtr[i + 1]; k++) {
                int slot = lowerSlots[k];
                if (active[cols[slot]]) y[cols[slot]] -= factor[slot] * z[i];
            }
        }
    }

    private double maxScaledMasked(double[] scale, int[] rows, int nRows) {
        double m = 0;
        for (int row = 0; row < nRows; row++) {
            int i = rows[row];
            m = Math.max(m, Math.abs(r[i] * scale[i]));
        }
        return m;
    }

    private void multiplyMasked(double[] v, double[] out, int[] rows, int nRows) {
        for (int row = 0; row < nRows; row++) {
            int i = rows[row];
            double sum = 0;
            for (int k = rowPtr[i]; k < rowPtr[i + 1]; k++) {
                int slot = preconditioner != Preconditioner.IC0 ? multiplySlots[k] : k;
                sum += values[slot] * v[cols[slot]];
            }
            out[i] = sum;
        }
    }

    private void factor() {
        for (int i = 0; i < n; i++) {
            double aii = values[diagSlot[i]];
            double squares = 0;
            for (int ij = lowerPtr[i]; ij < lowerPtr[i + 1]; ij++) {
                int slot = lowerSlots[ij], j = cols[slot];
                double sum = 0;
                int im = lowerPtr[i], jm = lowerPtr[j];
                while (im < ij && jm < lowerPtr[j + 1]) {
                    int is = lowerSlots[im], js = lowerSlots[jm];
                    int a = cols[is], b = cols[js];
                    if (a == b) { sum += factor[is] * factor[js]; im++; jm++; }
                    else if (a < b) im++;
                    else jm++;
                }
                double lij = aii == 0 || diagonal[j] == 0 ? 0 : (values[slot] - sum) / diagonal[j];
                factor[slot] = lij;
                squares += lij * lij;
            }
            double d = aii - squares;
            if (aii == 0) diagonal[i] = 0;
            else if (d <= 1e-12 * aii) {
                diagonal[i] = Math.sqrt(aii);
                lastPivotFixes++;
            } else diagonal[i] = Math.sqrt(d);
        }
    }

    private void apply() {
        if (preconditioner == Preconditioner.MG) {
            mg.apply(r, z);
            return;
        }
        if (preconditioner == Preconditioner.JACOBI) {
            jacobi(r, z);
            return;
        }
        forwardSolve(r, y);
        backwardSolve(y, z);
    }

    private void jacobi(double[] r, double[] z) {
        for (int i = 0; i < n; i++) z[i] = r[i] * invDiag[i];
    }

    private void forwardSolve(double[] r, double[] y) {
        for (int i = 0; i < n; i++) {
            double sum = r[i];
            for (int k = lowerPtr[i]; k < lowerPtr[i + 1]; k++) {
                int slot = lowerSlots[k];
                sum -= factor[slot] * y[cols[slot]];
            }
            y[i] = diagonal[i] == 0 ? 0 : sum / diagonal[i];
        }
    }

    private void backwardSolve(double[] y, double[] z) {
        for (int i = n - 1; i >= 0; i--) {
            z[i] = diagonal[i] == 0 ? 0 : y[i] / diagonal[i];
            if (diagonal[i] == 0) continue;
            for (int k = lowerPtr[i]; k < lowerPtr[i + 1]; k++) {
                int slot = lowerSlots[k];
                y[cols[slot]] -= factor[slot] * z[i];
            }
        }
    }

    // Factor refreshes the preconditioner; solve kernels overwrite only caller work arrays.
    void benchSetup() {
        if (preconditioner != Preconditioner.MG) return;
        long start = System.nanoTime();
        AggregationMg rebuilt = new AggregationMg(mgSettings);
        rebuilt.setup(rowPtr, cols, values, coordinateX, coordinateY);
        mgValues = values.clone();
        mg = rebuilt;
        setupCount++;
        lastFactorMs = (System.nanoTime() - start) * 1e-6;
    }
    int setupCount() { return setupCount; }
    int[] mgLevelSizes() { return mg == null ? new int[0] : mg.levelSizes(); }
    int[] mgLevelNnz() { return mg == null ? new int[0] : mg.levelNnz(); }
    int[] mgFirstLevelAggregates() { return mg == null ? new int[0] : mg.firstLevelAggregates(); }

    void benchFactor() { factor(); }
    void benchForward(double[] r, double[] y) { forwardSolve(r, y); }
    void benchBackward(double[] y, double[] z) { backwardSolve(y, z); }
    void benchJacobi(double[] r, double[] z) { jacobi(r, z); }

    /** Live CSR pattern for read-only bench access. */
    int[] rowPtr() { return rowPtr; }
    /** Live sorted columns for read-only bench access. */
    int[] cols() { return cols; }

    private double maxScaled(double[] scale) {
        double m = 0;
        for (int i = 0; i < n; i++) {
            m = Math.max(m, Math.abs(r[i] * scale[i]));
        }
        return m;
    }

    /** out = A · v. */
    public void multiply(double[] v, double[] out) {
        for (int i = 0; i < n; i++) {
            double s = 0;
            for (int k = rowPtr[i]; k < rowPtr[i + 1]; k++) {
                int slot = preconditioner == Preconditioner.JACOBI ? multiplySlots[k] : k;
                s += values[slot] * v[cols[slot]];
            }
            out[i] = s;
        }
    }
}
