// Written by ChatGPT from Claude's M5b spec.
// Edited by Claude: buoyancy relative to each face's background (M7a).
// Edited by Claude: the reference is the background's buoyancy reference, which may differ from it (M8b5).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D.BoundaryKind;

/**
 * Background-relative damping and gravity-consistent buoyancy. Buoyancy is relative to the face's buoyancy reference:
 * the mean of its boxes' background temperatures by default, or of the background's own buoyancy reference when it
 * has one ({@link Background3D#buoyancyBoxes}, M8b5); the expansion coefficient stays 1/(ambientT + 273.15).
 */
final class Forcing3D {
    private final BoxGraph3D g;
    private final SolverConfig3D c;
    private final double[] dyPerp, dn, faceBg;
    private final double buoyancyFactor, dampingFactor;
    Forcing3D(BoxGraph3D graph, SolverConfig3D config) {
        g = graph; c = config;
        buoyancyFactor = c.dt() * c.g() * (1.0 / (c.ambientT() + 273.15));
        dampingFactor = 1.0 / (1.0 + c.damping() * c.dt());
        dyPerp = new double[g.faceCount()]; dn = new double[dyPerp.length]; faceBg = new double[dyPerp.length];
        java.util.Arrays.fill(faceBg, c.ambientT());
        for (int f = 0; f < dyPerp.length; f++) {
            dyPerp[f] = g.faceAxis(f) == 1 ? 0 : g.boxCy(g.faceB(f)) - g.boxCy(g.faceA(f));
            dn[f] = g.faceDn(f);
        }
    }
    /** Sets each face's buoyancy reference, °C, to the mean of its two boxes' references. */
    void setBackground(double[] boxBg) {
        for (int f = 0; f < faceBg.length; f++) faceBg[f] = 0.5 * (boxBg[g.faceA(f)] + boxBg[g.faceB(f)]);
    }
    void damp(FlowState3D s) {
        for (int f = 0; f < s.u.length; f++) s.u[f] = s.uBg[f] + (s.u[f] - s.uBg[f]) * dampingFactor;
        for (int k = 0; k < s.ub.length; k++) if (g.boundaryKind(k) == BoundaryKind.OPEN)
            s.ub[k] = s.ubBg[k] + (s.ub[k] - s.ubBg[k]) * dampingFactor;
    }
    void buoyancy(FlowState3D s) {
        if (buoyancyFactor == 0) return;
        for (int f = 0; f < s.u.length; f++) if (g.faceAxis(f) == 1)
            s.u[f] += buoyancyFactor * (0.5 * (s.T[g.faceA(f)] + s.T[g.faceB(f)]) - faceBg[f]);
    }
    void gravityShift(FlowState3D s, double[] out) {
        for (int f = 0; f < out.length; f++) out[f] = dyPerp[f] == 0 || buoyancyFactor == 0 ? 0
                : buoyancyFactor * (0.5 * (s.T[g.faceA(f)] + s.T[g.faceB(f)]) - faceBg[f])
                        * dyPerp[f] / dn[f];
    }
}
