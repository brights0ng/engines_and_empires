// Written by Claude (M8b).
package dev.brights0ng.greedyfluids.mesh;

import dev.brights0ng.greedyfluids.grid.CellGrid3D;
import dev.brights0ng.greedyfluids.grid.CellGrid3D.Boundary;
import dev.brights0ng.greedyfluids.grid.CellGrid3D.Side;

/**
 * Per-cell side conditions on the mesh (M8b): a box meets each domain side it touches with one condition over its
 * whole face, so its exterior face is one kind. {@link GreedyMesher3D} grows and merges only within that, as it does
 * for the roofed-inflow rule; {@link BoxGraph3D} rejects a box that breaks it.
 */
public final class FaceKinds3D {
    private FaceKinds3D() { }

    /** Whether a box (cells) has one condition over each domain side it touches; true when no cell has its own. */
    public static boolean uniform(CellGrid3D g, int x0, int y0, int z0, int sx, int sy, int sz) {
        if (!g.hasFaceBoundaries()) return true;
        for (Side side : Side.values())
            if (touches(g, side, x0, y0, z0, sx, sy, sz) && kind(g, side, x0, y0, z0, sx, sy, sz, true) == null)
                return false;
        return true;
    }

    /** Whether a box (cells) reaches a domain side. */
    public static boolean touches(CellGrid3D g, Side side, int x0, int y0, int z0, int sx, int sy, int sz) {
        int a = side.axis(), lo = a == 0 ? x0 : a == 1 ? y0 : z0, n = a == 0 ? sx : a == 1 ? sy : sz;
        int extent = a == 0 ? g.nx() : a == 1 ? g.ny() : g.nz();
        return side.high() ? lo + n == extent : lo == 0;
    }

    /**
     * The condition over a box's face on a domain side it touches: one value, or null when it is mixed (checked
     * only when {@code check}; else the first face cell's) or the box doesn't reach the side.
     */
    public static Boundary kind(CellGrid3D g, Side side, int x0, int y0, int z0, int sx, int sy, int sz, boolean check) {
        if (!touches(g, side, x0, y0, z0, sx, sy, sz)) return null;
        int a = side.axis(), u = a == 0 ? 1 : 0, v = a == 2 ? 1 : 2;
        int[] p = {x0, y0, z0}, n = {sx, sy, sz}, c = p.clone();
        c[a] = side.high() ? p[a] + n[a] - 1 : p[a];
        Boundary first = null;
        for (int cu = p[u]; cu < p[u] + n[u]; cu++)
            for (int cv = p[v]; cv < p[v] + n[v]; cv++) {
                c[u] = cu; c[v] = cv;
                Boundary b = g.faceBoundary(side, c[0], c[1], c[2]);
                if (first == null) {
                    first = b;
                    if (!check || !g.hasFaceBoundaries()) return first;
                } else if (b != first) return null;
            }
        return first;
    }
}
