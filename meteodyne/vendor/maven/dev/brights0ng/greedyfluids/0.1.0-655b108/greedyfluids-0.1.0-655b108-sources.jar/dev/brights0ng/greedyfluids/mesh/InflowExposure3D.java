// Written by Claude (M6b1).
package dev.brights0ng.greedyfluids.mesh;

import dev.brights0ng.greedyfluids.grid.CellGrid3D;
import dev.brights0ng.greedyfluids.grid.CellGrid3D.Boundary;
import dev.brights0ng.greedyfluids.grid.CellGrid3D.Side;
import dev.brights0ng.greedyfluids.grid.CellType;

/**
 * Roofed-inflow rule (Bright, 2026-11-06): wind enters a domain only where the air at the cut is open to the sky.
 * A cell on a side wall (WEST, EAST, NORTH, SOUTH) with an INFLOW condition is <em>roofed</em> when its column
 * holds a SOLID cell above it inside the domain; its exterior face is then OPEN (ambient pressure, no forced
 * wind) instead of INFLOW. Within one fluid box every column is uniformly roofed or not (a box cannot contain the
 * column's top solid), so a box's face is mixed only across columns; {@link GreedyMesher3D} does not grow or
 * merge a box across such a change. DOWN and UP are never affected. A stand-in until Meteodyne supplies
 * per-face exposure from the world (M7).
 */
public final class InflowExposure3D {
    private InflowExposure3D() { }

    /** Whether any side wall has an INFLOW condition. */
    public static boolean anySideInflow(CellGrid3D g) {
        return g.boundary(Side.WEST) == Boundary.INFLOW || g.boundary(Side.EAST) == Boundary.INFLOW
                || g.boundary(Side.NORTH) == Boundary.INFLOW || g.boundary(Side.SOUTH) == Boundary.INFLOW;
    }

    /**
     * Per column (index z·nx + x), one more than the highest SOLID cell's y, or 0 if none, cells; filled only for
     * columns on a side wall with an INFLOW condition (others 0), or null when no side wall has INFLOW.
     */
    public static int[] roofTops(CellGrid3D g) {
        if (!anySideInflow(g)) return null;
        int nx = g.nx(), nz = g.nz();
        int[] tops = new int[nx * nz];
        for (int z = 0; z < nz; z++) for (int x = 0; x < nx; x++) {
            if (!onInflowWall(g, x, z)) continue;
            for (int y = g.ny() - 1; y >= 0; y--)
                if (g.type(x, y, z) == CellType.SOLID) { tops[z * nx + x] = y + 1; break; }
        }
        return tops;
    }

    /** Whether column (x, z) lies on a side wall whose condition is INFLOW. */
    public static boolean onInflowWall(CellGrid3D g, int x, int z) {
        return x == 0 && g.boundary(Side.WEST) == Boundary.INFLOW
                || x == g.nx() - 1 && g.boundary(Side.EAST) == Boundary.INFLOW
                || z == 0 && g.boundary(Side.NORTH) == Boundary.INFLOW
                || z == g.nz() - 1 && g.boundary(Side.SOUTH) == Boundary.INFLOW;
    }

    /** Whether cell (x, y, z) is under a SOLID cell of its column; tops from {@link #roofTops} (non-null). */
    public static boolean roofed(int[] tops, CellGrid3D g, int x, int y, int z) {
        return y < tops[z * g.nx() + x];
    }

    /**
     * Whether a candidate box (cells) has the same roofed state over every column of each INFLOW side-wall face
     * it touches; always true when tops is null.
     */
    public static boolean uniform(int[] tops, CellGrid3D g, int x0, int y0, int z0, int sx, int sz) {
        if (tops == null) return true;
        if (x0 == 0 && g.boundary(Side.WEST) == Boundary.INFLOW && !uniformRow(tops, g, 0, y0, z0, 0, sz)) return false;
        if (x0 + sx == g.nx() && g.boundary(Side.EAST) == Boundary.INFLOW
                && !uniformRow(tops, g, g.nx() - 1, y0, z0, 0, sz)) return false;
        if (z0 == 0 && g.boundary(Side.NORTH) == Boundary.INFLOW && !uniformRow(tops, g, x0, y0, 0, sx, 0)) return false;
        return !(z0 + sz == g.nz() && g.boundary(Side.SOUTH) == Boundary.INFLOW
                && !uniformRow(tops, g, x0, y0, g.nz() - 1, sx, 0));
    }

    /** Columns along x (count sx, dz = 0) or along z (count sz, sx = 0) from (x0, z0), at height y0. */
    private static boolean uniformRow(int[] tops, CellGrid3D g, int x0, int y0, int z0, int sx, int sz) {
        boolean first = roofed(tops, g, x0, y0, z0);
        for (int i = 1; i < Math.max(sx, sz); i++)
            if (roofed(tops, g, sx > 0 ? x0 + i : x0, y0, sx > 0 ? z0 : z0 + i) != first) return false;
        return true;
    }
}
