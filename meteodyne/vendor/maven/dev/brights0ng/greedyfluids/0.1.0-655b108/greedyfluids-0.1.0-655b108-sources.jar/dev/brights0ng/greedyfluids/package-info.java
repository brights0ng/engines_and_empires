// Written by Claude.
/** GreedyFluids: adaptive greedy-box air flow and heat simulation, independent of Minecraft. */
package dev.brights0ng.greedyfluids;
