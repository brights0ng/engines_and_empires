// Written by Claude (M6d2).
// Edited by Claude: two-pass chamfer scans; edits rescan one window per change, with no full-build fallback (M6e1).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import java.util.Arrays;

/**
 * Capped Chebyshev distance, in cells, from every cell to the nearest solid cell of a graph: 0 in solids, at most
 * {@link #CAP}. Advection3D sizes its backtrace sub-steps with it. Immutable; it depends only on which cells are
 * solid, so remeshes of an unchanged grid share one instance, and {@link #edited} updates it locally after edits.
 * Door faces are not solids here (a closed door is a zero-aperture face between fluid cells).
 * <p>Both builds use a two-pass chamfer scan (ascending then descending cell index, each reading the 13 of a cell's
 * 26 neighbours already visited in that pass), which is exact for the Chebyshev distance on a box of cells: a
 * shortest path can take its index-ascending steps first and its index-descending steps second.
 */
public final class SolidDistance3D {
    /** Largest stored distance, cells; a backtrace sub-step is at most CAP − 1 m long. */
    public static final int CAP = 16;
    /** Up to this many changed cells get one update window each (merged where they meet); more share one window. */
    private static final int MAX_WINDOWS = 64;
    private final int nx, ny, nz;
    private final byte[] d;

    private SolidDistance3D(int nx, int ny, int nz, byte[] d) { this.nx = nx; this.ny = ny; this.nz = nz; this.d = d; }

    /** Full build from the graph's solid cells (boxOfCell < 0). */
    public static SolidDistance3D of(BoxGraph3D g) {
        int nx = g.nx(), ny = g.ny(), nz = g.nz();
        byte[] d = new byte[nx * ny * nz];
        scan(d, g, nx, ny, nz, 0, nx - 1, 0, ny - 1, 0, nz - 1);
        return new SolidDistance3D(nx, ny, nz, d);
    }

    /**
     * The distances of {@code next}, a graph of the same grid after AIR ↔ SOLID edits. Cells whose solidity changed
     * are found by comparison. Returns this instance when nothing changed. Equal to {@code of(next)} (tested).
     */
    public SolidDistance3D edited(BoxGraph3D next) { return edited(next, null); }

    /**
     * As {@link #edited(BoxGraph3D)}, checking only the given cell indices ((y·nz + z)·nx + x) for solidity changes;
     * null checks every cell. The caller guarantees that no other cell changed.
     * <p>A change moves only the distances within CAP − 1 cells of it, so each changed cell gets that cube as a
     * window (windows that overlap or touch merge into their bounding box), and each window is rescanned with the
     * cells around it, which are unchanged, as its boundary values. There is no full-build fallback: the cost is
     * that of the windows, at most one scan of the grid.
     */
    public SolidDistance3D edited(BoxGraph3D next, int[] candidates) {
        if (next.nx() != nx || next.ny() != ny || next.nz() != nz) throw new IllegalArgumentException("grid size changed");
        int n = d.length, changes = 0, count = candidates == null ? n : candidates.length;
        int[] changed = new int[16];
        for (int k = 0; k < count; k++) {
            int i = candidates == null ? k : candidates[k];
            boolean solid = next.boxOfCellIndex(i) < 0;
            if (solid != (d[i] == 0)) {
                if (changes == changed.length) changed = Arrays.copyOf(changed, 2 * changes);
                changed[changes++] = i;
            }
        }
        if (changes == 0) return this;
        // Windows as {x0, x1, y0, y1, z0, z1}, inclusive and clipped to the grid.
        int r = CAP - 1, windows = changes <= MAX_WINDOWS ? changes : 1;
        int[][] w = new int[windows][];
        for (int k = 0; k < changes; k++) {
            int c = changed[k], cx = c % nx, cz = c / nx % nz, cy = c / (nx * nz);
            int[] cube = {Math.max(0, cx - r), Math.min(nx - 1, cx + r), Math.max(0, cy - r), Math.min(ny - 1, cy + r),
                    Math.max(0, cz - r), Math.min(nz - 1, cz + r)};
            if (windows == changes) w[k] = cube; else if (k == 0) w[0] = cube; else join(w[0], cube);
        }
        // A window reads the cells one outside it, so two windows are independent only with a cell between them.
        for (boolean merged = true; merged; ) {
            merged = false;
            for (int a = 0; a < windows; a++)
                for (int b = a + 1; b < windows; b++)
                    if (w[a][0] <= w[b][1] + 1 && w[b][0] <= w[a][1] + 1 && w[a][2] <= w[b][3] + 1 && w[b][2] <= w[a][3] + 1
                            && w[a][4] <= w[b][5] + 1 && w[b][4] <= w[a][5] + 1) {
                        join(w[a], w[b]);
                        w[b--] = w[--windows];
                        merged = true;
                    }
        }
        byte[] out = d.clone();
        for (int k = 0; k < windows; k++) scan(out, next, nx, ny, nz, w[k][0], w[k][1], w[k][2], w[k][3], w[k][4], w[k][5]);
        return new SolidDistance3D(nx, ny, nz, out);
    }

    /** Grows window a to the bounding box of a and b. */
    private static void join(int[] a, int[] b) {
        for (int i = 0; i < 6; i += 2) { a[i] = Math.min(a[i], b[i]); a[i + 1] = Math.max(a[i + 1], b[i + 1]); }
    }

    /** Distance at cell (x, y, z), cells. */
    public int at(int x, int y, int z) { return d[(y * nz + z) * nx + x]; }

    /** Distance at the cell holding point (x, y, z) in m; upper faces clamp to the last cell, as BoxGraph3D.boxAt. */
    public int at(double x, double y, double z) {
        return at(Math.min((int) x, nx - 1), Math.min((int) y, ny - 1), Math.min((int) z, nz - 1));
    }

    /** Whether both describe the same distances (tests). */
    public boolean sameAs(SolidDistance3D o) { return nx == o.nx && ny == o.ny && nz == o.nz && Arrays.equals(d, o.d); }

    /**
     * Recomputes the cells of an inclusive window from g's solid cells: reset to 0 in solids and CAP in fluid, then
     * the two chamfer passes. Cells outside the window are read, never written, and must hold their final values;
     * the whole grid is a window with nothing outside it.
     */
    private static void scan(byte[] d, BoxGraph3D g, int nx, int ny, int nz, int x0, int x1, int y0, int y1, int z0, int z1) {
        for (int y = y0; y <= y1; y++)
            for (int z = z0; z <= z1; z++) {
                int row = (y * nz + z) * nx;
                for (int x = x0; x <= x1; x++) d[row + x] = (byte) (g.boxOfCellIndex(row + x) < 0 ? 0 : CAP);
            }
        int[] rows = new int[4];
        for (int y = y0; y <= y1; y++)
            for (int z = z0; z <= z1; z++) {
                int row = (y * nz + z) * nx, count = 0;
                if (y > 0) for (int zz = Math.max(0, z - 1); zz <= Math.min(nz - 1, z + 1); zz++) rows[count++] = ((y - 1) * nz + zz) * nx;
                if (z > 0) rows[count++] = row - nx;
                for (int x = x0; x <= x1; x++) relax(d, row, x, Math.max(0, x - 1), Math.min(nx - 1, x + 1), -1, rows, count);
            }
        for (int y = y1; y >= y0; y--)
            for (int z = z1; z >= z0; z--) {
                int row = (y * nz + z) * nx, count = 0;
                if (y < ny - 1) for (int zz = Math.max(0, z - 1); zz <= Math.min(nz - 1, z + 1); zz++) rows[count++] = ((y + 1) * nz + zz) * nx;
                if (z < nz - 1) rows[count++] = row + nx;
                for (int x = x1; x >= x0; x--) relax(d, row, x, Math.max(0, x - 1), Math.min(nx - 1, x + 1), 1, rows, count);
            }
    }

    /**
     * Lowers cell (row, x) to one more than the least of its neighbour at x + side in its own row and its three
     * neighbours in each listed row. xm and xp are x ∓ 1 clamped to the grid; a clamped index repeats a cell that is
     * a neighbour anyway (or the cell itself, which cannot lower it).
     */
    private static void relax(byte[] d, int row, int x, int xm, int xp, int side, int[] rows, int count) {
        int i = row + x, v = d[i];
        if (v == 0) return;
        int m = d[row + (side < 0 ? xm : xp)];
        for (int k = 0; k < count; k++) {
            int r = rows[k];
            m = Math.min(m, Math.min(d[r + xm], Math.min(d[r + x], d[r + xp])));
        }
        if (m + 1 < v) d[i] = (byte) (m + 1);
    }
}
