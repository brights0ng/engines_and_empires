// Written by Claude (M5e1).
// Edited by Claude: door placement and removal (M7b).
package dev.brights0ng.greedyfluids.grid;

import java.util.Objects;

/**
 * One 1 m cell edit, validated against the pre-batch grid by GridEdits3D: AIR ↔ SOLID (M5e1), and AIR ↔ DOOR (M7b:
 * a door placed in an air cell, open or shut, or a door taken out back to air).
 */
public record CellEdit3D(int x, int y, int z, Kind kind, Material material, boolean open) {
    /**
     * PLACE turns AIR into SOLID; BREAK turns SOLID into AIR; PLACE_DOOR turns AIR into a DOOR, open or shut;
     * REMOVE_DOOR turns a DOOR into AIR.
     */
    public enum Kind { PLACE, BREAK, PLACE_DOOR, REMOVE_DOOR }

    public CellEdit3D {
        Objects.requireNonNull(kind, "kind");
        if (kind == Kind.PLACE) Objects.requireNonNull(material, "PLACE material");
        else if (kind != Kind.PLACE_DOOR && material != null)
            throw new IllegalArgumentException(kind + " material must be null");
        if (open && kind != Kind.PLACE_DOOR) throw new IllegalArgumentException("only PLACE_DOOR has an open state");
    }

    /** An edit with no door state (the M5e1 form). */
    public CellEdit3D(int x, int y, int z, Kind kind, Material material) {
        this(x, y, z, kind, material, false);
    }

    /** A block placed in an AIR cell; any source in the cell is cleared (M7b b4). */
    public static CellEdit3D place(int x, int y, int z, Material material) {
        return new CellEdit3D(x, y, z, Kind.PLACE, material);
    }

    public static CellEdit3D breakBlock(int x, int y, int z) {
        return new CellEdit3D(x, y, z, Kind.BREAK, null);
    }

    /** A door placed in an AIR cell, open or shut; a null material means {@link Material#DOOR}. */
    public static CellEdit3D placeDoor(int x, int y, int z, Material material, boolean open) {
        return new CellEdit3D(x, y, z, Kind.PLACE_DOOR, material == null ? Material.DOOR : material, open);
    }

    /** A DOOR cell taken out, back to AIR. */
    public static CellEdit3D removeDoor(int x, int y, int z) {
        return new CellEdit3D(x, y, z, Kind.REMOVE_DOOR, null);
    }

    /** Whether this edit places or removes a door. */
    public boolean doorEdit() {
        return kind == Kind.PLACE_DOOR || kind == Kind.REMOVE_DOOR;
    }
}
