// Written by ChatGPT from Claude's M5b spec.
// Edited by Claude: rebuild from edited geometry with tracked block heat (M5e1).
// Edited by Claude: build arrays sized by the store count, not the grid; rebuild matches old stores by a merge pass (M6e2).
// Edited by Claude: rebuildLocal along the edited cells' axis lines; trackedHeat per block (M6e2).
// Edited by Claude: equilibrate against a per-store far-side temperature (M7a).
// Edited by Claude: fixed-temperature stores from the grid's fixed wall temperatures (M7c).
// Edited by Claude: the grid's film resistance (M8a).
// Edited by Claude: fixed stores couple by the grid's fixed-wall surface (M8e).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.grid.CellGrid3D;
import dev.brights0ng.greedyfluids.grid.CellGrid3D.FixedSurface;
import dev.brights0ng.greedyfluids.grid.CellType;
import dev.brights0ng.greedyfluids.grid.Material;
import java.util.Arrays;
import java.util.function.IntToDoubleFunction;

/**
 * Fixed geometry wall stores. For each fluid cell in index order, scan -x,+x,-y,+y,-z,+z;
 * record fluid-to-fluid rays only toward +axis, followed by the door panel (direction 6).
 * Each store couples a 1 m² face through gA = rhoCp/(film + R/2), W/K, film being the grid's
 * ({@link CellGrid3D#filmResistance}, s/m).
 * AIR and AMBIENT have gB = gA; GROUND has gB = 0. Capacity (J/K) is
 * min(n,2)/n times summed relative capacities times rhoCp (J/(m³·K)) times 1 m³.
 * Only store temperatures (°C) change after construction; edits build a replacement with {@link #rebuild}.
 * A store holding a block with a fixed wall temperature ({@link CellGrid3D#setFixedTemperature}) is fixed at the
 * first such block's temperature walking from its near cell: it never changes and acts as a heat source or sink
 * of unlimited capacity (M7c: lava, magma). How it couples to its air is the grid's {@link FixedSurface} (M8e): under
 * RAY as above; under FILM and CONVECTION through a surface film and only the blocks between the air and the fixed
 * block (the far side from the last fixed block).
 */
public final class WallStore3D {
    /** Capacity cap, blocks. */
    public static final int MAX_STORE_BLOCKS = 2;
    /** Store kinds, dimensionless. */
    public static final byte AIR = 0, AMBIENT = 1, GROUND = 2, DOOR = 3;
    private final int[] cellA, cellB, blockStart, blockCells;
    private final byte[] kind, direction;
    private final double[] gA, gB, capacity, temperature, fixed;
    /** The air's volumetric heat capacity the couplings were built with, J/(m³·K). */
    private final double rhoCp;
    /** Reference air temperature for a fixed face's free convection, °C (M8e): one value, not the live air. */
    public static final double CONVECTION_REFERENCE_C = 20;

    /** Builds stores using rhoCp in J/(m³·K). Null solid material means STONE; null door means DOOR. */
    public WallStore3D(CellGrid3D grid, double rhoCp) { this(scan(grid, rhoCp, 1024)); }

    private WallStore3D(Builder s) {
        int count = s.count;
        cellA = Arrays.copyOf(s.a, count); cellB = Arrays.copyOf(s.b, count);
        kind = Arrays.copyOf(s.kinds, count); direction = Arrays.copyOf(s.dirs, count);
        gA = Arrays.copyOf(s.ga, count); gB = Arrays.copyOf(s.gb, count); capacity = Arrays.copyOf(s.cap, count);
        s.starts[count] = s.blockCount;
        blockStart = Arrays.copyOf(s.starts, count + 1); blockCells = Arrays.copyOf(s.blocks, s.blockCount);
        temperature = new double[count];
        fixed = Arrays.copyOf(s.fx, count);
        rhoCp = s.rhoCp;
        applyFixed();
    }

    /** Every store of the grid: fluid cells in index order, rays 0..5 then the door panel. */
    private static Builder scan(CellGrid3D grid, double rhoCp, int expected) {
        Builder s = new Builder(grid, rhoCp, expected);
        for (int y = 0; y < grid.ny(); y++) for (int z = 0; z < grid.nz(); z++)
            for (int x = 0; x < grid.nx(); x++) {
                if (!grid.type(x, y, z).isFluid()) continue;
                for (int d = 0; d < 6; d++) s.ray(x, y, z, d);
                if (grid.type(x, y, z) == CellType.DOOR) s.door(x, y, z);
            }
        return s;
    }

    /** Growable store arrays; the one place a ray or door panel becomes a store. */
    private static final class Builder {
        final CellGrid3D grid;
        final double rhoCp;
        int room, count, blockCount;
        int[] a, b, starts, blocks;
        byte[] kinds, dirs;
        double[] ga, gb, cap, fx;

        Builder(CellGrid3D grid, double rhoCp, int expected) {
            this.grid = grid; this.rhoCp = rhoCp;
            room = Math.max(16, expected);
            a = new int[room]; b = new int[room]; starts = new int[room + 1]; blocks = new int[2 * room];
            kinds = new byte[room]; dirs = new byte[room];
            ga = new double[room]; gb = new double[room]; cap = new double[room]; fx = new double[room];
        }
        private void grow() {
            if (count < room) return;
            room *= 2;
            a = Arrays.copyOf(a, room); b = Arrays.copyOf(b, room); starts = Arrays.copyOf(starts, room + 1);
            kinds = Arrays.copyOf(kinds, room); dirs = Arrays.copyOf(dirs, room);
            ga = Arrays.copyOf(ga, room); gb = Arrays.copyOf(gb, room); cap = Arrays.copyOf(cap, room);
            fx = Arrays.copyOf(fx, room);
        }
        /** Adds fluid cell (x, y, z)'s ray in direction d if it has one. */
        void ray(int x, int y, int z, int d) {
            int dx = d == 0 ? -1 : d == 1 ? 1 : 0;
            int dy = d == 2 ? -1 : d == 3 ? 1 : 0;
            int dz = d == 4 ? -1 : d == 5 ? 1 : 0;
            int cx = x + dx, cy = y + dy, cz = z + dz, n = 0;
            // before: resistance ahead of the first fixed block; after: behind the last one (M8e)
            double resistance = 0, relativeCapacity = 0, fixedT = Double.NaN, before = Double.NaN, after = 0;
            while (grid.inBounds(cx, cy, cz) && grid.type(cx, cy, cz) == CellType.SOLID) {
                Material m = grid.material(cx, cy, cz);
                if (m == null) m = Material.STONE;
                double r = m.resistancePerBlock(), t = grid.fixedTemperature(grid.index(cx, cy, cz));
                if (!Double.isNaN(t)) {
                    if (Double.isNaN(fixedT)) { fixedT = t; before = resistance; }
                    after = 0;
                } else after += r;
                resistance += r;
                relativeCapacity += m.relHeatCapacity();
                n++; cx += dx; cy += dy; cz += dz;
            }
            if (n == 0) return;
            boolean farFluid = grid.inBounds(cx, cy, cz);
            if (farFluid && (d & 1) == 0) return;
            grow();
            starts[count] = blockCount;
            if (blockCount + n > blocks.length)
                blocks = Arrays.copyOf(blocks, Math.max(blockCount + n, 2 * blocks.length));
            for (int k = 1; k <= n; k++)
                blocks[blockCount++] = grid.index(x + k * dx, y + k * dy, z + k * dz);
            a[count] = grid.index(x, y, z); b[count] = farFluid ? grid.index(cx, cy, cz) : -1;
            kinds[count] = farFluid ? AIR : d == 2 ? GROUND : AMBIENT;
            dirs[count] = (byte) d;
            ga[count] = nearCoupling(grid, rhoCp, d, resistance, fixedT, before);
            gb[count] = farCoupling(grid, rhoCp, d, kinds[count], fixedT, after, ga[count]);
            fx[count] = fixedT;
            cap[count] = ((double) Math.min(n, MAX_STORE_BLOCKS) / n) * relativeCapacity * rhoCp;
            count++;
        }
        /** Adds door cell (x, y, z)'s panel. */
        void door(int x, int y, int z) {
            Material m = grid.material(x, y, z);
            if (m == null) m = Material.DOOR;
            grow();
            starts[count] = blockCount;
            if (blockCount == blocks.length) blocks = Arrays.copyOf(blocks, 2 * blocks.length);
            blocks[blockCount++] = grid.index(x, y, z);
            a[count] = grid.index(x, y, z); b[count] = -1; kinds[count] = DOOR; dirs[count] = 6;
            ga[count] = 2 * rhoCp / grid.filmResistance();
            fx[count] = Double.NaN;
            cap[count] = m.heatCapacity(rhoCp);
            count++;
        }
        /** Appends store i of src unchanged (geometry only). */
        void copy(WallStore3D src, int i) {
            grow();
            int n = src.blockStart[i + 1] - src.blockStart[i];
            starts[count] = blockCount;
            if (blockCount + n > blocks.length)
                blocks = Arrays.copyOf(blocks, Math.max(blockCount + n, 2 * blocks.length));
            System.arraycopy(src.blockCells, src.blockStart[i], blocks, blockCount, n);
            blockCount += n;
            a[count] = src.cellA[i]; b[count] = src.cellB[i]; kinds[count] = src.kind[i]; dirs[count] = src.direction[i];
            ga[count] = src.gA[i]; gb[count] = src.gB[i]; cap[count] = src.capacity[i]; fx[count] = src.fixed[i];
            count++;
        }
    }
    /** The first fixed wall temperature among blocks[from, to) (cell indices), °C, or NaN. */
    private static double firstFixed(CellGrid3D grid, int[] blocks, int from, int to) {
        for (int k = from; k < to; k++) {
            double t = grid.fixedTemperature(blocks[k]);
            if (!Double.isNaN(t)) return t;
        }
        return Double.NaN;
    }
    /**
     * A ray store's near coupling, W/K (1 m² face): the film and half the ray's resistance, or for a fixed store
     * under FILM or CONVECTION the surface and the resistance {@code before} its first fixed block (M8e).
     */
    private static double nearCoupling(CellGrid3D grid, double rhoCp, int d, double resistance, double fixedT,
            double before) {
        if (Double.isNaN(fixedT) || grid.fixedSurface() == FixedSurface.RAY)
            return rhoCp / (grid.filmResistance() + 0.5 * resistance);
        return rhoCp / (surfaceFilm(grid, rhoCp, before == 0, d, fixedT) + before);
    }
    /**
     * A ray store's far coupling, W/K (1 m² face): none for GROUND, else the near one, or for a fixed store under FILM
     * or CONVECTION the surface and the resistance {@code after} its last fixed block, seen from the far side (M8e).
     */
    private static double farCoupling(CellGrid3D grid, double rhoCp, int d, byte kind, double fixedT, double after,
            double near) {
        if (kind == GROUND) return 0;
        if (Double.isNaN(fixedT) || grid.fixedSurface() == FixedSurface.RAY) return near;
        return rhoCp / (surfaceFilm(grid, rhoCp, after == 0, d ^ 1, fixedT) + after);
    }
    /**
     * The film between a fixed store's air and its first block, s/m (M8e): the grid's film, or under CONVECTION, when
     * the fixed block itself is that first block, the smaller of it and free convection's (d: from the air to it).
     */
    private static double surfaceFilm(CellGrid3D grid, double rhoCp, boolean touches, int d, double fixedT) {
        double film = grid.filmResistance();
        if (!touches || grid.fixedSurface() != FixedSurface.CONVECTION) return film;
        double h = freeConvection(fixedT - CONVECTION_REFERENCE_C, d);
        return h > 0 ? Math.min(film, rhoCp / h) : film;
    }
    /**
     * Free convection off a 1 m face held {@code dT} K warmer than its air (negative: colder), W/(m²·K), with
     * {@code d} the ray's way from the air to the face's block (0..5: -x,+x,-y,+y,-z,+z); Holman's simplified
     * correlations for air (M8e). A heated face looking up or a cooled one looking down, 1.52·|dT|^(1/3) (turbulent);
     * a vertical face, 1.31·|dT|^(1/3); a heated face looking down or a cooled one looking up, 0.59·(|dT|/L)^(1/4)
     * with L = 1 m (laminar, the air trapped under it). Lava at 1000 °C over 20 °C air: 15.1, 13.0 and 3.3.
     */
    public static double freeConvection(double dT, int d) {
        double a = Math.abs(dT);
        if (a == 0) return 0;
        boolean below = d == 2, above = d == 3; // the block below the air faces up; above it, down
        if (!below && !above) return 1.31 * Math.cbrt(a);
        boolean free = below == (dT > 0); // warm air rises off a heated face looking up; cool air sinks off a cold one
        return free ? 1.52 * Math.cbrt(a) : 0.59 * Math.pow(a, 0.25);
    }
    /** Sets every fixed store to its fixed temperature. */
    private void applyFixed() {
        for (int i = 0; i < fixed.length; i++) if (!Double.isNaN(fixed[i])) temperature[i] = fixed[i];
    }
    /**
     * Re-reads which stores are fixed, and at what, from the grid's fixed wall temperatures (M7c); a store that is no
     * longer fixed keeps the temperature it had. Under FILM or CONVECTION the couplings follow (M8e): a solver built
     * on these stores must then refresh its copies ({@code BoxSolver3D.refreshWallCouplings}). Returns whether any
     * store's fixed temperature or coupling changed.
     */
    public boolean refreshFixed(CellGrid3D grid) {
        if (grid.fixedSurface() != FixedSurface.RAY) return recouple(grid);
        boolean changed = false;
        for (int i = 0; i < fixed.length; i++) {
            double t = kind[i] == DOOR ? Double.NaN : firstFixed(grid, blockCells, blockStart[i], blockStart[i + 1]);
            if (Double.compare(t, fixed[i]) != 0) { fixed[i] = t; changed = true; }
        }
        applyFixed();
        return changed;
    }
    /** refreshFixed under FILM or CONVECTION: every ray store's fixed temperature and couplings re-read (M8e). */
    private boolean recouple(CellGrid3D grid) {
        int nx = grid.nx(), nz = grid.nz();
        boolean changed = false;
        for (int i = 0; i < fixed.length; i++) {
            if (kind[i] == DOOR) continue;
            double resistance = 0, fixedT = Double.NaN, before = Double.NaN, after = 0;
            for (int k = blockStart[i]; k < blockStart[i + 1]; k++) {
                int cell = blockCells[k];
                Material m = grid.material(cell % nx, cell / (nx * nz), cell / nx % nz);
                if (m == null) m = Material.STONE;
                double r = m.resistancePerBlock(), t = grid.fixedTemperature(cell);
                if (!Double.isNaN(t)) {
                    if (Double.isNaN(fixedT)) { fixedT = t; before = resistance; }
                    after = 0;
                } else after += r;
                resistance += r;
            }
            double a = nearCoupling(grid, rhoCp, direction[i], resistance, fixedT, before);
            double b = farCoupling(grid, rhoCp, direction[i], kind[i], fixedT, after, a);
            if (Double.compare(fixedT, fixed[i]) != 0 || a != gA[i] || b != gB[i]) {
                fixed[i] = fixedT; gA[i] = a; gB[i] = b; changed = true;
            }
        }
        applyFixed();
        return changed;
    }
    /** Whether store i holds a fixed temperature. */
    public boolean isFixed(int i) { return !Double.isNaN(fixed[i]); }
    /** Store count, dimensionless. */
    public int count() { return cellA.length; }
    /** Near cell index, dimensionless. */
    public int cellA(int i) { return cellA[i]; }
    /** Far cell index, -1 without a far fluid cell. */
    public int cellB(int i) { return cellB[i]; }
    /** Store kind (AIR, AMBIENT, GROUND, DOOR). */
    public byte kind(int i) { return kind[i]; }
    /** Ray id 0..5 (-x,+x,-y,+y,-z,+z), or panel id 6. */
    public int direction(int i) { return direction[i]; }
    /** Near coupling, W/K (1 m² face). */
    public double gA(int i) { return gA[i]; }
    /** Far coupling, W/K (1 m² face). */
    public double gB(int i) { return gB[i]; }
    /** Store heat capacity, J/K. */
    public double capacity(int i) { return capacity[i]; }
    /** Store temperature, °C. */
    public double temperature(int i) { return temperature[i]; }
    /** Sets store temperature, °C; a fixed store keeps its own. */
    public void setTemperature(int i, double celsius) { if (Double.isNaN(fixed[i])) temperature[i] = celsius; }
    /** CSR offset for store i; blockStart(count()) is the exclusive final offset. */
    public int blockStart(int i) { return blockStart[i]; }
    /** Cell index at block CSR offset. */
    public int blockCell(int k) { return blockCells[k]; }
    /** Equilibrates against per-cell temperatures and ambient tBg, both °C. */
    public void equilibrate(double[] cellT, double tBg) { equilibrate(cellT, i -> tBg); }
    /** As above, with each AMBIENT store's far-side temperature (°C) given by store index; allocates nothing. */
    public void equilibrate(double[] cellT, java.util.function.IntToDoubleFunction farT) {
        for (int i = 0; i < count(); i++) {
            if (!Double.isNaN(fixed[i])) continue;
            double ta = cellT[cellA[i]];
            temperature[i] = switch (kind[i]) {
                case AIR -> (gA[i] * ta + gB[i] * cellT[cellB[i]]) / (gA[i] + gB[i]);
                case AMBIENT -> (gA[i] * ta + gB[i] * farT.applyAsDouble(i)) / (gA[i] + gB[i]);
                default -> ta;
            };
        }
    }
    /** Stored heat relative to 0 °C, J. */
    public double energy() {
        double sum = 0;
        for (int i = 0; i < count(); i++) sum += capacity[i] * temperature[i];
        return sum;
    }

    /** Rebuilt stores and the number of distinct untracked blocks filled by fallback (cells). */
    public record Rebuilt(WallStore3D store, int fallbackBlocks) { }

    /**
     * Rebuilds from edited geometry. A store with the same (cellA, direction, block cells) as an old store copies
     * its T bitwise; others take the relative-capacity-weighted mean of their blocks' tracked T (°C).
     * NaN in blockT means no tracked heat: fallback (cell index → °C) fills it once per block, and each such
     * distinct block is counted. blockT is updated in place.
     */
    public static Rebuilt rebuild(CellGrid3D grid, double rhoCp, WallStore3D old, double[] blockT,
            IntToDoubleFunction fallback) {
        WallStore3D next = new WallStore3D(scan(grid, rhoCp, old == null ? 1024 : old.count() + old.count() / 8 + 64));
        boolean[] filled = new boolean[blockT.length];
        int fallbackBlocks = 0, oi = 0, oldCount = old == null ? 0 : old.count();
        // Both store lists ascend in (cellA, direction), so the old store of a ray is found by one merge pass.
        for (int i = 0; i < next.count(); i++) {
            long key = 7L * next.cellA[i] + next.direction[i];
            while (oi < oldCount && 7L * old.cellA[oi] + old.direction[oi] < key) oi++;
            if (oi < oldCount && 7L * old.cellA[oi] + old.direction[oi] == key
                    && Arrays.equals(next.blockCells, next.blockStart[i], next.blockStart[i + 1],
                    old.blockCells, old.blockStart[oi], old.blockStart[oi + 1])) {
                next.temperature[i] = old.temperature[oi];
                continue;
            }
            double sum = 0, weight = 0;
            for (int k = next.blockStart[i]; k < next.blockStart[i + 1]; k++) {
                int cell = next.blockCells[k];
                if (Double.isNaN(blockT[cell])) {
                    blockT[cell] = fallback.applyAsDouble(cell);
                    if (!filled[cell]) { filled[cell] = true; fallbackBlocks++; }
                }
                int x = cell % grid.nx(), z = (cell / grid.nx()) % grid.nz(), y = cell / (grid.nx() * grid.nz());
                Material m = grid.material(x, y, z);
                if (m == null) m = next.kind[i] == DOOR ? Material.DOOR : Material.STONE;
                sum += m.relHeatCapacity() * blockT[cell];
                weight += m.relHeatCapacity();
            }
            next.temperature[i] = sum / weight;
        }
        next.applyFixed();
        return new Rebuilt(next, fallbackBlocks);
    }

    /** Index of the store of cellA's ray in direction (0..5) or its door panel (6); −1 if it has none. */
    public int find(int cell, int dir) {
        long key = 7L * cell + dir;
        int lo = 0, hi = cellA.length - 1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            long k = 7L * cellA[mid] + direction[mid];
            if (k < key) lo = mid + 1; else if (k > key) hi = mid - 1; else return mid;
        }
        return -1;
    }

    /**
     * Tracked heat of the solid block at a cell, as GridEdits3D rule 3: out[0] = Σ w_s T_s (J/K · °C) and
     * out[1] = Σ w_s (J/K) over the non-door stores holding the block, w_s = C_s / min(n_s, 2), summed in store
     * order. solid tells which cells were solid when these stores were built (cell index → boolean). A block is
     * in at most one store per ray direction: the one whose fluid cell is reached by walking back through solids.
     */
    public void trackedHeat(CellGrid3D grid, int cell, java.util.function.IntPredicate solid, double[] out) {
        int nx = grid.nx(), nz = grid.nz();
        int x = cell % nx, z = cell / nx % nz, y = cell / (nx * nz);
        int[] found = new int[6];
        int count = 0;
        for (int d = 0; d < 6; d++) {
            int dx = d == 0 ? -1 : d == 1 ? 1 : 0, dy = d == 2 ? -1 : d == 3 ? 1 : 0, dz = d == 4 ? -1 : d == 5 ? 1 : 0;
            int cx = x - dx, cy = y - dy, cz = z - dz;
            while (grid.inBounds(cx, cy, cz) && solid.test(grid.index(cx, cy, cz))) { cx -= dx; cy -= dy; cz -= dz; }
            if (!grid.inBounds(cx, cy, cz)) continue;
            int i = find(grid.index(cx, cy, cz), d);
            if (i >= 0) found[count++] = i;
        }
        Arrays.sort(found, 0, count);
        double sum = 0, weight = 0;
        for (int k = 0; k < count; k++) {
            int i = found[k];
            double w = capacity[i] / Math.min(blockStart[i + 1] - blockStart[i], MAX_STORE_BLOCKS);
            sum += w * temperature[i]; weight += w;
        }
        out[0] = sum; out[1] = weight;
    }

    /**
     * {@link #rebuild} for AIR ↔ SOLID edits of the listed cells only, without scanning the grid (M6e2). An edit
     * can change only rays along the three axis lines through its cell, so those lines' rays are rebuilt and every
     * other store is copied. The result equals rebuild's: the same stores in the same order with the same T.
     *
     * @param grid       the edited grid
     * @param old        the stores of the grid before the edits
     * @param edited     edited cell indices, each once
     * @param wasSolid   per edited cell, whether it was SOLID before the edit
     * @param placedT    per edited cell, the tracked T (°C) of a block placed there; ignored for broken cells
     * @param fallback   cell index → °C for a block with no tracked heat
     */
    public static Rebuilt rebuildLocal(CellGrid3D grid, double rhoCp, WallStore3D old, int[] edited,
            boolean[] wasSolid, double[] placedT, IntToDoubleFunction fallback) {
        int nx = grid.nx(), ny = grid.ny(), nz = grid.nz();
        // Lines by axis: x lines indexed y·nz + z, y lines z·nx + x, z lines y·nx + x.
        boolean[][] dirty = {new boolean[ny * nz], new boolean[nz * nx], new boolean[ny * nx]};
        java.util.HashMap<Integer, Boolean> before = new java.util.HashMap<>();
        java.util.HashMap<Integer, Double> blockT = new java.util.HashMap<>();
        Builder fresh = new Builder(grid, rhoCp, 64 * edited.length);
        for (int e = 0; e < edited.length; e++) {
            int c = edited[e], x = c % nx, z = c / nx % nz, y = c / (nx * nz);
            before.put(c, wasSolid[e]);
            if (!wasSolid[e]) blockT.put(c, placedT[e]);
            if (!dirty[0][y * nz + z]) {
                dirty[0][y * nz + z] = true;
                for (int i = 0; i < nx; i++) if (grid.type(i, y, z).isFluid()) { fresh.ray(i, y, z, 0); fresh.ray(i, y, z, 1); }
            }
            if (!dirty[1][z * nx + x]) {
                dirty[1][z * nx + x] = true;
                for (int i = 0; i < ny; i++) if (grid.type(x, i, z).isFluid()) { fresh.ray(x, i, z, 2); fresh.ray(x, i, z, 3); }
            }
            if (!dirty[2][y * nx + x]) {
                dirty[2][y * nx + x] = true;
                for (int i = 0; i < nz; i++) if (grid.type(x, y, i).isFluid()) { fresh.ray(x, y, i, 4); fresh.ray(x, y, i, 5); }
            }
        }
        WallStore3D rays = new WallStore3D(fresh);
        long[] order = new long[rays.count()];
        for (int i = 0; i < order.length; i++) order[i] = (7L * rays.cellA[i] + rays.direction[i]) << 24 | i;
        if (order.length >= 1 << 24) throw new IllegalStateException("too many rebuilt rays");
        Arrays.sort(order);
        // Merge the kept old stores with the rebuilt rays, both ascending in (cellA, direction).
        Builder merged = new Builder(grid, rhoCp, old.count() + order.length);
        int[] source = new int[old.count() + order.length];
        int k = 0;
        for (int i = 0; i <= old.count(); i++) {
            long key = i == old.count() ? Long.MAX_VALUE : 7L * old.cellA[i] + old.direction[i];
            while (k < order.length && order[k] >> 24 < key) {
                int r = (int) (order[k++] & 0xFFFFFF);
                source[merged.count] = -1 - r;
                merged.copy(rays, r);
            }
            if (i == old.count()) break;
            int d = old.direction[i], c = old.cellA[i], x = c % nx, z = c / nx % nz, y = c / (nx * nz);
            if (d < 6 && dirty[d >> 1][d < 2 ? y * nz + z : d < 4 ? z * nx + x : y * nx + x]) continue;
            source[merged.count] = i;
            merged.copy(old, i);
        }
        WallStore3D next = new WallStore3D(merged);
        java.util.function.IntPredicate solidBefore = cell -> {
            Boolean was = before.get(cell);
            return was != null ? was : grid.type(cell % nx, cell / (nx * nz), cell / nx % nz) == CellType.SOLID;
        };
        double[] heat = new double[2];
        java.util.HashSet<Integer> filled = new java.util.HashSet<>();
        int fallbackBlocks = 0;
        for (int i = 0; i < next.count(); i++) {
            if (source[i] >= 0) { next.temperature[i] = old.temperature[source[i]]; continue; }
            int oi = old.find(next.cellA[i], next.direction[i]);
            if (oi >= 0 && Arrays.equals(next.blockCells, next.blockStart[i], next.blockStart[i + 1],
                    old.blockCells, old.blockStart[oi], old.blockStart[oi + 1])) {
                next.temperature[i] = old.temperature[oi];
                continue;
            }
            double sum = 0, weight = 0;
            for (int j = next.blockStart[i]; j < next.blockStart[i + 1]; j++) {
                int cell = next.blockCells[j];
                Double t = blockT.get(cell);
                if (t == null) {
                    old.trackedHeat(grid, cell, solidBefore, heat);
                    t = heat[1] == 0 ? Double.NaN : heat[0] / heat[1];
                }
                if (Double.isNaN(t)) { t = fallback.applyAsDouble(cell); if (filled.add(cell)) fallbackBlocks++; }
                blockT.put(cell, t);
                Material m = grid.material(cell % nx, cell / (nx * nz), cell / nx % nz);
                if (m == null) m = next.kind[i] == DOOR ? Material.DOOR : Material.STONE;
                sum += m.relHeatCapacity() * t;
                weight += m.relHeatCapacity();
            }
            next.temperature[i] = sum / weight;
        }
        next.applyFixed();
        return new Rebuilt(next, fallbackBlocks);
    }
}
