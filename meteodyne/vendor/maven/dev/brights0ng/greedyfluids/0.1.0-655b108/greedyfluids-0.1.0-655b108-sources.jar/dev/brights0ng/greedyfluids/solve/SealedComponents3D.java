// Written by ChatGPT from Claude's M5b spec.
// Edited by Claude: inflow-pocket rule (a) and pocket/outflow statistics (M6b1).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D.BoundaryKind;

/**
 * Components joined across positive-aperture interior faces; closed doors are excluded (id -1).
 * Only a positive-aperture declared-OPEN boundary unseals a component; INFLOW never does.
 * <p>Inflow-pocket rule (a), Bright 2026-11-06: a component with declared-INFLOW faces and no declared-OPEN
 * face has no divergence-free solution (wind is pumped in with no way out), so recompute marks those INFLOW
 * faces OPEN on the graph ({@link BoxGraph3D#setInflowOpened}); the component then counts as a pocket, not as
 * sealed. Faces are restored to INFLOW when a later recompute (graph build or door toggle) no longer finds
 * the pocket. Without pockets nothing on the graph changes.
 * Scratch and result storage is preallocated; recompute allocates nothing within capacity.
 */
public final class SealedComponents3D {
    private final int[] parent, rootToComp, componentOfBox, sealed, volume, inflowFaces;
    private final double[] inflowRate, openArea;
    private int boxCount, componentCount, sealedCount, sealedVolume, pocketCount, pocketVolume, openedFaces,
            kindChanges;
    private double pocketInflow, maxOutflowSpeed;
    /** Reserves storage for maxBoxes boxes (dimensionless count). */
    public SealedComponents3D(int maxBoxes) {
        if (maxBoxes < 0) throw new IllegalArgumentException("negative capacity");
        parent = new int[maxBoxes]; rootToComp = new int[maxBoxes];
        componentOfBox = new int[maxBoxes]; sealed = new int[maxBoxes]; volume = new int[maxBoxes];
        inflowFaces = new int[maxBoxes]; inflowRate = new double[maxBoxes]; openArea = new double[maxBoxes];
    }
    /** Reserves storage and labels the graph immediately. */
    public SealedComponents3D(BoxGraph3D graph) { this(graph.boxCount()); recompute(graph); }
    /**
     * Recomputes ids, sealed flags and volumes (m³), applies the inflow-pocket rule to the graph's effective
     * boundary kinds, without allocation; graph must fit reserved capacity.
     */
    public void recompute(BoxGraph3D g) {
        int n = g.boxCount();
        if (n > parent.length) throw new IllegalArgumentException("graph exceeds reserved capacity");
        boxCount = n;
        for (int i = 0; i < n; i++) { parent[i] = g.doorOpen(i) ? i : -1; rootToComp[i] = -1; }
        for (int f = 0; f < g.faceCount(); f++) {
            if (g.aperture(f) <= 0) continue;
            int a = find(g.faceA(f)), b = find(g.faceB(f));
            if (a < b) parent[b] = a; else if (b < a) parent[a] = b;
        }
        int comps = 0;
        for (int i = 0; i < n; i++) {
            if (parent[i] < 0) { componentOfBox[i] = -1; continue; }
            int root = find(i), c = rootToComp[root];
            if (c < 0) {
                c = comps++; rootToComp[root] = c; sealed[c] = 1; volume[c] = 0;
                inflowFaces[c] = 0; inflowRate[c] = 0; openArea[c] = 0;
            }
            componentOfBox[i] = c;
            volume[c] += g.boxSx(i) * g.boxSy(i) * g.boxSz(i);
        }
        componentCount = comps;
        for (int k = 0; k < g.boundaryCount(); k++) {
            double ap = g.boundaryAperture(k);
            if (ap <= 0) continue;
            int c = componentOfBox[g.boundaryBox(k)];
            if (c < 0) continue;
            if (g.declaredBoundaryKind(k) == BoundaryKind.OPEN) {
                sealed[c] = 0; openArea[c] += ap * g.boundaryArea(k);
            } else {
                inflowFaces[c]++;
                // Speed into the domain, m/s: boundaryInflow is along +axis.
                double in = g.boundarySide(k) == 0 ? g.boundaryInflow(k) : -g.boundaryInflow(k);
                inflowRate[c] += in * ap * g.boundaryArea(k);
            }
        }
        // Rule (a): a sealed component with INFLOW faces is a pocket; its INFLOW faces become OPEN.
        pocketCount = 0; pocketVolume = 0; pocketInflow = 0; maxOutflowSpeed = 0;
        for (int c = 0; c < comps; c++) {
            if (sealed[c] != 0 && inflowFaces[c] > 0) {
                sealed[c] = 2; pocketCount++; pocketVolume += volume[c]; pocketInflow += inflowRate[c];
            } else if (sealed[c] == 0 && openArea[c] > 0) {
                maxOutflowSpeed = Math.max(maxOutflowSpeed, inflowRate[c] / openArea[c]);
            }
        }
        openedFaces = 0; kindChanges = 0;
        for (int k = 0; k < g.boundaryCount(); k++) {
            if (g.declaredBoundaryKind(k) != BoundaryKind.INFLOW) continue;
            int c = componentOfBox[g.boundaryBox(k)];
            boolean opened = c >= 0 && sealed[c] == 2;
            if (opened) openedFaces++;
            if (g.inflowOpened(k) != opened) { g.setInflowOpened(k, opened); kindChanges++; }
        }
        sealedCount = 0; sealedVolume = 0;
        for (int c = 0; c < comps; c++) {
            if (sealed[c] == 2) sealed[c] = 0;
            else if (sealed[c] != 0) { sealedCount++; sealedVolume += volume[c]; }
        }
    }
    private int find(int x) {
        int r = x;
        while (parent[r] != r) r = parent[r];
        while (x != r) { int next = parent[x]; parent[x] = r; x = next; }
        return r;
    }
    /** Last graph's box count. */
    public int boxCount() { return boxCount; }
    /** Number of open-fluid components. */
    public int componentCount() { return componentCount; }
    /** Component id, or -1 for a closed door. */
    public int componentOfBox(int box) { return componentOfBox[box]; }
    /** Sealed flag (0 or 1). */
    public int sealedFlag(int component) { return sealed[component]; }
    /** Whether a component has no OPEN pressure boundary. */
    public boolean isComponentSealed(int component) { return sealed[component] != 0; }
    /** Whether a box belongs to a sealed component. */
    public boolean isBoxSealed(int box) {
        int c = componentOfBox[box]; return c >= 0 && sealed[c] != 0;
    }
    /** Fluid volume, m³ (integer unit cells). */
    public int componentVolume(int component) { return volume[component]; }
    /** Number of sealed components. */
    public int sealedCount() { return sealedCount; }
    /** Total sealed fluid volume, m³ (integer unit cells). */
    public int sealedVolume() { return sealedVolume; }
    /** Number of inflow pockets opened by rule (a) in the last recompute. */
    public int pocketCount() { return pocketCount; }
    /** Total pocket fluid volume, m³ (integer unit cells). */
    public int pocketVolume() { return pocketVolume; }
    /** Total declared inflow into pockets, m³/s (now released through the opened faces). */
    public double pocketInflow() { return pocketInflow; }
    /** INFLOW faces currently opened by rule (a). */
    public int openedFaces() { return openedFaces; }
    /** INFLOW faces whose effective kind the last recompute changed (opened or restored). */
    public int kindChanges() { return kindChanges; }
    /**
     * Near-pocket indicator: max over non-pocket components with OPEN area of declared inflow / OPEN area,
     * m/s (the mean outflow speed the OPEN faces must carry); 0 if none. Report-only.
     */
    public double maxOutflowSpeed() { return maxOutflowSpeed; }
}
