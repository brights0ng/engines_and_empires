// Written by Claude (M7a); edited by Claude (M7f: wall stores saved one by one).
package dev.brights0ng.greedyfluids.region;

import java.util.Arrays;

/**
 * A region's temperatures by cell, °C, for saving, restoring and carrying across a recentre (M7a). air holds each
 * air cell's temperature and NaN for solid or unknown cells; solid holds each solid cell's wall temperature where a
 * wall store tracks it (the mean of the stores that contain the block) and NaN elsewhere. Both are in grid index
 * order (y·nz + z)·nx + x. Velocity is not kept: a restored region starts at rest and its flow settles within
 * seconds. Immutable: the arrays are copied in and out.
 * <p>M7f: the wall stores may also be kept one by one ({@link #stores}): store k is the one whose ray leaves air
 * cell {@link #storeCell} in direction {@link #storeDir} (0..5 for −x, +x, −y, +y, −z, +z; 6 a door panel, as
 * {@code WallStore3D.find}), at {@link #storeT} °C. A restore sets those stores exactly and uses the per-block means
 * only for the rest: a block's mean mixes every store it sits in (a wall between a room and the air above the roof
 * holds both), so restoring from means alone moves stores by degrees.
 */
public final class ThermalState {
    private final int nx, ny, nz;
    private final float[] air, solid;
    private final int[] storeCell;
    private final byte[] storeDir;
    private final float[] storeT;

    /** Per-cell values only (no stores kept one by one). */
    public ThermalState(int nx, int ny, int nz, float[] air, float[] solid) {
        this(nx, ny, nz, air, solid, new int[0], new byte[0], new float[0]);
    }

    /** Per-cell values and stores kept one by one (parallel arrays, any order; cells in grid index order). */
    public ThermalState(int nx, int ny, int nz, float[] air, float[] solid, int[] storeCell, byte[] storeDir,
            float[] storeT) {
        if (nx < 1 || ny < 1 || nz < 1) throw new IllegalArgumentException("grid dimensions must be positive");
        int n = nx * ny * nz;
        if (air.length != n || solid.length != n) throw new IllegalArgumentException("expected one value per cell");
        if (storeCell.length != storeDir.length || storeCell.length != storeT.length)
            throw new IllegalArgumentException("one cell, direction and temperature per store");
        for (int k = 0; k < storeCell.length; k++)
            if (storeCell[k] < 0 || storeCell[k] >= n || storeDir[k] < 0 || storeDir[k] > 6)
                throw new IllegalArgumentException("store " + k + " out of range: cell " + storeCell[k] + ", direction "
                        + storeDir[k]);
        this.nx = nx; this.ny = ny; this.nz = nz; this.air = air.clone(); this.solid = solid.clone();
        this.storeCell = storeCell.clone(); this.storeDir = storeDir.clone(); this.storeT = storeT.clone();
    }

    /** A state that knows nothing (every cell NaN). */
    public static ThermalState unknown(int nx, int ny, int nz) {
        float[] a = new float[nx * ny * nz];
        Arrays.fill(a, Float.NaN);
        return new ThermalState(nx, ny, nz, a, a);
    }

    public int nx() { return nx; }
    public int ny() { return ny; }
    public int nz() { return nz; }
    /** Air temperature of a cell by grid index, °C, or NaN. */
    public float air(int index) { return air[index]; }
    /** Wall temperature of a solid cell by grid index, °C, or NaN. */
    public float solid(int index) { return solid[index]; }
    /** Copy of the air temperatures. */
    public float[] airArray() { return air.clone(); }
    /** Stores kept one by one (M7f). */
    public int stores() { return storeCell.length; }
    /** The air cell (grid index) store k's ray leaves from. */
    public int storeCell(int k) { return storeCell[k]; }
    /** Store k's direction: 0..5 for −x, +x, −y, +y, −z, +z; 6 a door panel. */
    public int storeDir(int k) { return storeDir[k]; }
    /** Store k's temperature, °C. */
    public float storeT(int k) { return storeT[k]; }
    /** Copy of the wall temperatures. */
    public float[] solidArray() { return solid.clone(); }

    /**
     * This state seen from a window of size (nx, ny, nz) whose low corner sits at (dx, dy, dz) in this state's
     * cells: cells inside both windows keep their values, the rest are NaN. For v1 recentring, the new window is
     * the old one moved by (dx, dy, dz).
     */
    public ThermalState moved(int dx, int dy, int dz, int nx, int ny, int nz) {
        float[] a = new float[nx * ny * nz], s = new float[a.length];
        Arrays.fill(a, Float.NaN); Arrays.fill(s, Float.NaN);
        for (int y = 0; y < ny; y++) {
            int oy = y + dy;
            if (oy < 0 || oy >= this.ny) continue;
            for (int z = 0; z < nz; z++) {
                int oz = z + dz;
                if (oz < 0 || oz >= this.nz) continue;
                for (int x = 0; x < nx; x++) {
                    int ox = x + dx;
                    if (ox < 0 || ox >= this.nx) continue;
                    int to = (y * nz + z) * nx + x, from = (oy * this.nz + oz) * this.nx + ox;
                    a[to] = air[from]; s[to] = solid[from];
                }
            }
        }
        int kept = 0;
        int[] cells = new int[storeCell.length];
        byte[] dirs = new byte[storeCell.length];
        float[] temps = new float[storeCell.length];
        for (int k = 0; k < storeCell.length; k++) {
            int c = storeCell[k], ox = c % this.nx, oz = c / this.nx % this.nz, oy = c / (this.nx * this.nz);
            int x = ox - dx, y = oy - dy, z = oz - dz;
            if (x < 0 || x >= nx || y < 0 || y >= ny || z < 0 || z >= nz) continue;
            cells[kept] = (y * nz + z) * nx + x; dirs[kept] = storeDir[k]; temps[kept++] = storeT[k];
        }
        return new ThermalState(nx, ny, nz, a, s, Arrays.copyOf(cells, kept), Arrays.copyOf(dirs, kept),
                Arrays.copyOf(temps, kept));
    }
}
