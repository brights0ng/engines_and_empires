// Written by Claude (M8e e3).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D.BoundaryKind;
import java.util.Arrays;

/**
 * A heat-only estimate of where a region's air and wall stores settle (M8e e3, the dynamic start; Bright, decisions
 * 48–49, 53–55): what a region opening with heat sources or fixed walls starts from, and what a saved one decays
 * toward, instead of the background.
 *
 * <p><b>The physics</b> is the heat solve's ({@code HeatSolve3D}) with the air at rest, three changes:
 * <ul>
 *   <li><b>Mixing:</b> air-to-air faces conduct at an effective diffusivity ({@link Settings#kappa}, m²/s) that stands
 *       for the mixing the flow would do; open boundaries and EXCHANGE faces keep the solver's own κ.</li>
 *   <li><b>Outdoor air is tied</b> to its background (decision 55): each cell's air couples to its background at
 *       follow × ρc / {@link Settings#tieSeconds} W/K, so air open to the sky stays at the weather and the solver
 *       builds the plume itself once it runs.</li>
 *   <li><b>Time</b> (decision 53): fixed walls (lava, magma) are permanent, so they are taken to <i>steady state</i>
 *       (stage 1); block sources are taken {@link Settings#horizonSeconds} on from there in
 *       {@link #HORIZON_STEPS} implicit steps (stage 2), "lit for a while" rather than forever. A horizon of +∞ makes stage 2 steady too.</li>
 * </ul>
 *
 * <p><b>The solve.</b> Wall stores are eliminated exactly (each store's own equation is local), which leaves a
 * symmetric positive definite system on the boxes alone: an AIR store links its two boxes, an AMBIENT store is a sink
 * to its far background, a fixed store a source at its temperature, and a GROUND or door store holds heat only
 * through its capacity over the step. It is solved by IC(0)-preconditioned CG ({@link Pcg}); the stores' temperatures
 * are then worked back out. Everything is allocated per call: this runs once when a region opens, not per step.
 *
 * <p><b>The cold start</b> it is measured from ({@link Estimate#coldBoxT}, {@link Estimate#coldStoreT}): boxes at
 * their background and stores equilibrated against it, as a fresh region starts ({@code AdaptiveMesh3D}). A host
 * moves a region toward the estimate by adding (estimate − cold) × weight to each box and store.
 *
 * <p>Pure, single-threaded; nothing in the solver is changed.
 */
public final class SteadyHeat3D {
    /**
     * Effective air-to-air diffusivity before calibration, m²/s (M8e e3b settles it): room-scale mixing runs about
     * speed × size, 0.2 m/s × 3 m.
     */
    public static final double DEFAULT_KAPPA = 0.5;
    /** Block sources' horizon, s: one in-game day (24,000 ticks), the saved state's decay time (decision 53). */
    public static final double DEFAULT_HORIZON = 1200;
    /**
     * Implicit steps the horizon is split into: one step of H settles a mode of time constant τ to 1/(1 + τ/H) of its
     * way (a room's air, τ ≈ H/3, to 75 %), eight to within a few per cent of the exact e^(−H/τ).
     */
    public static final int HORIZON_STEPS = 8;
    /** Outdoor air's tie to its background, s (decision 55): strong enough that open air reads as the weather. */
    public static final double DEFAULT_TIE = 1;
    /**
     * CG stops when every box's residual heating rate, |residual| / (ρc · volume), is below this, K/s: about 0.004 K
     * an hour, so what is left is far slower than anything a reader sees.
     */
    public static final double TOLERANCE = 1e-6;
    /** CG iteration cap. */
    public static final int MAX_ITERATIONS = 20_000;

    /**
     * The estimate's knobs: {@code kappa}, the effective diffusivity, m²/s (positive); {@code horizonSeconds}, block
     * sources' horizon, s (positive, +∞ for steady); {@code tieSeconds}, the outdoor tie's time, s (positive, +∞ for no
     * tie).
     */
    public record Settings(double kappa, double horizonSeconds, double tieSeconds) {
        public static final Settings DEFAULT = new Settings(DEFAULT_KAPPA, DEFAULT_HORIZON, DEFAULT_TIE);

        public Settings {
            if (!(kappa > 0) || !(horizonSeconds > 0) || !(tieSeconds > 0))
                throw new IllegalArgumentException("kappa, horizon and tie must be positive");
        }

        /** These settings with another effective diffusivity. */
        public Settings withKappa(double value) { return new Settings(value, horizonSeconds, tieSeconds); }

        /** These settings with another horizon. */
        public Settings withHorizon(double value) { return new Settings(kappa, value, tieSeconds); }

        /** These settings with another tie. */
        public Settings withTie(double value) { return new Settings(kappa, horizonSeconds, value); }
    }

    /**
     * An estimate on one graph and one set of wall stores: {@code boxT} and {@code storeT}, °C, by box and store index
     * (fixed stores at their temperature); {@code coldBoxT} and {@code coldStoreT}, the cold start it is measured from;
     * {@code iterations}, CG iterations over both stages; {@code ms}, wall time; {@code converged}, whether every solve
     * met {@link #TOLERANCE}. Arrays are owned by the estimate: treat as read-only.
     */
    public record Estimate(BoxGraph3D graph, WallStore3D walls, double[] boxT, double[] storeT, double[] coldBoxT,
                           double[] coldStoreT, int iterations, double ms, boolean converged) {
        /** The largest rise of any box over its cold start, °C (negative where sinks win). */
        public double maxRise() {
            double m = Double.NEGATIVE_INFINITY;
            for (int b = 0; b < boxT.length; b++) m = Math.max(m, boxT[b] - coldBoxT[b]);
            return m;
        }
    }

    /**
     * Whether a solver has anything to estimate: a fixed store, or a box with a nonzero source in
     * {@code sourceWatts} (per box, W; null for the solver's own).
     */
    public static boolean needed(BoxSolver3D solver, double[] sourceWatts) {
        return anyFixed(solver.wallStore()) || anySource(solver, sourceWatts);
    }

    /**
     * The estimate for a solver's graph, stores and background; {@code exchange} gives EXCHANGE faces' far sides (null:
     * insulated); {@code sourceWatts} per box, W (null: the solver's own sources, entity heat included). Returns the
     * cold start itself (no iterations) when there is nothing to estimate.
     */
    public static Estimate estimate(BoxSolver3D solver, ExchangeTemperatures exchange, double[] sourceWatts,
            Settings settings) {
        long start = System.nanoTime();
        BoxGraph3D g = solver.graph();
        WallStore3D w = solver.wallStore();
        int n = g.boxCount(), ns = w.count();
        Background3D bg = solver.background();
        if (sourceWatts != null && sourceWatts.length != n) throw new IllegalArgumentException("expected one source per box");
        double[] q = new double[n];
        for (int b = 0; b < n; b++) q[b] = sourceWatts != null ? sourceWatts[b] : solver.source(b);
        // the cold start: boxes at their background, stores equilibrated against it
        double[] coldBox = new double[n], coldStore = new double[ns], storeBg = new double[ns];
        for (int b = 0; b < n; b++) coldBox[b] = solver.backgroundT(b);
        for (int i = 0; i < ns; i++) {
            storeBg[i] = w.kind(i) == WallStore3D.AMBIENT ? bg.cell(w.blockCell(w.blockStart(i + 1) - 1)) : bg.reference();
            int a = g.boxOfCellIndex(w.cellA(i));
            double ta = coldBox[a];
            coldStore[i] = w.isFixed(i) ? w.temperature(i) : switch (w.kind(i)) {
                case WallStore3D.AIR -> (w.gA(i) * ta + w.gB(i) * coldBox[g.boxOfCellIndex(w.cellB(i))]) / (w.gA(i) + w.gB(i));
                case WallStore3D.AMBIENT -> (w.gA(i) * ta + w.gB(i) * storeBg[i]) / (w.gA(i) + w.gB(i));
                default -> ta;
            };
        }
        boolean fixed = anyFixed(w), sources = anySource(solver, sourceWatts);
        if (!fixed && !sources)
            return new Estimate(g, w, coldBox.clone(), coldStore.clone(), coldBox, coldStore, 0, ms(start), true);
        BoxSystem system = new BoxSystem(solver, exchange, settings, storeBg);
        double[] box = coldBox.clone(), store = coldStore.clone();
        double[] zero = new double[n];
        int iterations = 0;
        boolean converged = true;
        // stage 1: the fixed walls at steady state, no sources
        if (fixed) {
            iterations += system.solve(zero, Double.POSITIVE_INFINITY, box, store);
            converged &= system.converged;
        }
        // stage 2: the block sources, the horizon on from stage 1 in HORIZON_STEPS implicit steps (one when steady)
        if (sources) {
            boolean steady = Double.isInfinite(settings.horizonSeconds());
            int steps = steady ? 1 : HORIZON_STEPS;
            for (int k = 0; k < steps; k++) {
                iterations += system.solve(q, steady ? settings.horizonSeconds() : settings.horizonSeconds() / steps, box, store);
                converged &= system.converged;
            }
        }
        return new Estimate(g, w, box, store, coldBox, coldStore, iterations, ms(start), converged);
    }

    private static double ms(long start) { return (System.nanoTime() - start) * 1e-6; }

    private static boolean anyFixed(WallStore3D w) {
        for (int i = 0; i < w.count(); i++) if (w.isFixed(i)) return true;
        return false;
    }

    private static boolean anySource(BoxSolver3D solver, double[] sourceWatts) {
        int n = solver.graph().boxCount();
        for (int b = 0; b < n; b++) if ((sourceWatts != null ? sourceWatts[b] : solver.source(b)) != 0) return true;
        return false;
    }

    /** The box system: its pattern, the parts that don't change between stages, and the CG. */
    private static final class BoxSystem {
        final BoxGraph3D g;
        final WallStore3D w;
        final double rc;
        final double[] storeBg;
        /** Per box: air capacity, J/K; the fixed part of the diagonal, W/K, and of the right-hand side, W. */
        final double[] capacity, baseDiagonal, baseRhs;
        /** CSR of the box system; slot of each face's (a, b) and (b, a) entries and each AIR store's. */
        final int[] rowPtr, cols, faceAB, faceBA, storeAB, storeBA, diagSlot;
        final double[] faceG;
        final Pcg cg;
        boolean converged;

        BoxSystem(BoxSolver3D solver, ExchangeTemperatures exchange, Settings s, double[] storeBg) {
            g = solver.graph(); w = solver.wallStore(); this.storeBg = storeBg;
            SolverConfig3D c = solver.config();
            rc = c.rhoCp();
            int n = g.boxCount(), nf = g.faceCount(), ns = w.count();
            Background3D bg = solver.background();
            capacity = new double[n]; baseDiagonal = new double[n]; baseRhs = new double[n];
            for (int b = 0; b < n; b++) capacity[b] = rc * g.boxVolume(b);
            // pattern: the diagonal, each face's pair, each non-fixed AIR store's pair (deduplicated by sort)
            long[] pairs = new long[n + 2 * nf + 2 * ns];
            int np = 0;
            for (int b = 0; b < n; b++) pairs[np++] = (long) b << 32 | b;
            for (int f = 0; f < nf; f++) {
                int a = g.faceA(f), b = g.faceB(f);
                pairs[np++] = (long) a << 32 | b; pairs[np++] = (long) b << 32 | a;
            }
            for (int i = 0; i < ns; i++) {
                if (w.isFixed(i) || w.kind(i) != WallStore3D.AIR) continue;
                int a = g.boxOfCellIndex(w.cellA(i)), b = g.boxOfCellIndex(w.cellB(i));
                pairs[np++] = (long) a << 32 | b; pairs[np++] = (long) b << 32 | a;
            }
            pairs = Arrays.copyOf(pairs, np);
            Arrays.sort(pairs);
            int unique = 0;
            for (int k = 0; k < np; k++) if (k == 0 || pairs[k] != pairs[k - 1]) pairs[unique++] = pairs[k];
            rowPtr = new int[n + 1]; cols = new int[unique];
            for (int k = 0; k < unique; k++) { rowPtr[(int) (pairs[k] >>> 32) + 1]++; cols[k] = (int) pairs[k]; }
            for (int b = 0; b < n; b++) rowPtr[b + 1] += rowPtr[b];
            final long[] sorted = Arrays.copyOf(pairs, unique);
            java.util.function.LongUnaryOperator slot = key -> Arrays.binarySearch(sorted, key);
            diagSlot = new int[n];
            for (int b = 0; b < n; b++) diagSlot[b] = (int) slot.applyAsLong((long) b << 32 | b);
            faceAB = new int[nf]; faceBA = new int[nf]; faceG = new double[nf];
            for (int f = 0; f < nf; f++) {
                int a = g.faceA(f), b = g.faceB(f);
                faceAB[f] = (int) slot.applyAsLong((long) a << 32 | b);
                faceBA[f] = (int) slot.applyAsLong((long) b << 32 | a);
                double ap = g.aperture(f), area = g.faceArea(f);
                faceG[f] = rc * s.kappa() * ap * area / g.faceDn(f) + g.faceClosedConductance(f) * (1 - ap) * area;
            }
            storeAB = new int[ns]; storeBA = new int[ns];
            Arrays.fill(storeAB, -1); Arrays.fill(storeBA, -1);
            for (int i = 0; i < ns; i++) {
                if (w.isFixed(i) || w.kind(i) != WallStore3D.AIR) continue;
                int a = g.boxOfCellIndex(w.cellA(i)), b = g.boxOfCellIndex(w.cellB(i));
                storeAB[i] = (int) slot.applyAsLong((long) a << 32 | b);
                storeBA[i] = (int) slot.applyAsLong((long) b << 32 | a);
            }
            // open and closed boundaries (HeatSolve3D.ambientConductance), at the solver's own κ
            for (int k = 0; k < g.boundaryCount(); k++) {
                double ap = g.boundaryAperture(k), area = g.boundaryArea(k);
                double cond = g.boundaryClosedConductance(k) * (1 - ap) * area;
                if (g.boundaryKind(k) == BoundaryKind.OPEN) cond += rc * c.kappa() * ap * area / 0.5;
                int b = g.boundaryBox(k);
                baseDiagonal[b] += cond; baseRhs[b] += cond * solver.backgroundT(b);
            }
            // EXCHANGE faces with a far side, at the solver's own κ (HeatSolve3D.exchangeConductance)
            if (exchange != null)
                for (int e = 0; e < g.exchangeCount(); e++) {
                    int b = g.exchangeBox(e), axis = g.exchangeAxis(e);
                    double half = 0.5 * (axis == 0 ? g.boxSx(b) : axis == 1 ? g.boxSy(b) : g.boxSz(b));
                    var side = g.exchangeDomainSide(e);
                    for (int k = g.exchangeCellsStart(e); k < g.exchangeCellsEnd(e); k++) {
                        int cell = g.exchangeCell(k);
                        double far = exchange.at(side, cell);
                        if (!Double.isFinite(far)) continue;
                        double gc = rc * c.kappa() / (half + exchange.distance(side, cell));
                        baseDiagonal[b] += gc; baseRhs[b] += gc * far;
                    }
                }
            // outdoor air tied to its background, cell by cell
            if (bg.follows() && Double.isFinite(s.tieSeconds())) {
                double per = rc / s.tieSeconds();
                int cells = g.nx() * g.ny() * g.nz();
                for (int cell = 0; cell < cells; cell++) {
                    double f = bg.follow(cell);
                    int b = g.boxOfCellIndex(cell);
                    if (f == 0 || b < 0) continue;
                    baseDiagonal[b] += per * f; baseRhs[b] += per * f * bg.cell(cell);
                }
            }
            // fixed stores: a source at their temperature on each side that has air
            for (int i = 0; i < ns; i++) {
                if (!w.isFixed(i)) continue;
                double t = w.temperature(i);
                int a = g.boxOfCellIndex(w.cellA(i));
                baseDiagonal[a] += w.gA(i); baseRhs[a] += w.gA(i) * t;
                if (w.kind(i) == WallStore3D.AIR) {
                    int b = g.boxOfCellIndex(w.cellB(i));
                    baseDiagonal[b] += w.gB(i); baseRhs[b] += w.gB(i) * t;
                }
            }
            cg = new Pcg(rowPtr, cols, Pcg.Preconditioner.IC0);
            if (cg.values().length != cols.length) throw new IllegalStateException("pattern");
        }

        /**
         * One implicit step of {@code horizon} s (+∞: steady) from {@code box}/{@code store}, with {@code q} W per box;
         * overwrites both with the result and returns the CG iterations.
         */
        int solve(double[] q, double horizon, double[] box, double[] store) {
            int n = g.boxCount(), ns = w.count();
            double inv = Double.isInfinite(horizon) ? 0 : 1 / horizon;
            double[] v = cg.values(), rhs = new double[n], scale = new double[n];
            Arrays.fill(v, 0);
            for (int b = 0; b < n; b++) {
                v[diagSlot[b]] += baseDiagonal[b] + capacity[b] * inv;
                rhs[b] = baseRhs[b] + capacity[b] * inv * box[b] + q[b];
            }
            for (int f = 0; f < g.faceCount(); f++) {
                double c = faceG[f];
                v[diagSlot[g.faceA(f)]] += c; v[diagSlot[g.faceB(f)]] += c;
                v[faceAB[f]] -= c; v[faceBA[f]] -= c;
            }
            for (int i = 0; i < ns; i++) {
                if (w.isFixed(i)) continue;
                double ga = w.gA(i), gb = w.gB(i), cs = w.capacity(i) * inv;
                double d = cs + ga + gb;
                int a = g.boxOfCellIndex(w.cellA(i));
                v[diagSlot[a]] += ga * (d - ga) / d;
                rhs[a] += ga * cs * store[i] / d;
                if (w.kind(i) == WallStore3D.AIR) {
                    int b = g.boxOfCellIndex(w.cellB(i));
                    v[diagSlot[b]] += gb * (d - gb) / d;
                    rhs[b] += gb * cs * store[i] / d;
                    v[storeAB[i]] -= ga * gb / d; v[storeBA[i]] -= ga * gb / d;
                } else if (w.kind(i) == WallStore3D.AMBIENT) rhs[a] += ga * gb * storeBg[i] / d;
            }
            for (int b = 0; b < n; b++) scale[b] = 1 / capacity[b];
            double[] x = box.clone();
            int it = cg.solve(x, rhs, scale, TOLERANCE, MAX_ITERATIONS);
            converged = cg.lastExit() == Pcg.Exit.CONVERGED;
            // the stores, worked back out of their own equations
            for (int i = 0; i < ns; i++) {
                if (w.isFixed(i)) { store[i] = w.temperature(i); continue; }
                double ga = w.gA(i), gb = w.gB(i), cs = w.capacity(i) * inv;
                double far = w.kind(i) == WallStore3D.AIR ? x[g.boxOfCellIndex(w.cellB(i))]
                        : w.kind(i) == WallStore3D.AMBIENT ? storeBg[i] : 0;
                double d = cs + ga + gb;
                store[i] = (cs * store[i] + ga * x[g.boxOfCellIndex(w.cellA(i))] + gb * far) / d;
            }
            System.arraycopy(x, 0, box, 0, n);
            return it;
        }
    }

    private SteadyHeat3D() {
    }
}
