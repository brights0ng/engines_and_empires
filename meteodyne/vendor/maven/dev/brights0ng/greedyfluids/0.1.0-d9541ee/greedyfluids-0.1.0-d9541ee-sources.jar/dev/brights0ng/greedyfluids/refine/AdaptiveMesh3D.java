// Written by ChatGPT from Claude's M5d spec.
// Edited by ChatGPT from Claude's M5d2 spec.
// Edited by Claude: immediate AIR/SOLID edit batches with full remeshes (M5e1).
// Edited by Claude: local remeshing and local remap projection (M5e2).
// Edited by Claude: indicator, solver-build and edit sub-stage timers (M5f).
// Edited by ChatGPT from Claude's M6a spec.
// Edited by Claude: roofed-inflow column marking on edits (M6b1).
// Edited by Claude: report-only opening-rule variants (M6b2); default rule THROUGH_AXIS_R1 (M6b2 adoption).
// Edited by ChatGPT from Claude's M6b1 spec.
// Edited by Claude: indicators and raster share the solver's gradient workspace (M6c1).
// Edited by Claude: report-only local remesh levers: BLOCK8 scope, single round, local merge remeshes, full fallback (M6c2).
// Edited by Claude: RING scope with single-round local remeshes is the default (M6c2 adoption, Bright 2026-11-09).
// Edited by Claude: local rasterisation and transfer (M6c3).
// Edited by Claude: remeshes share the solver's solid distances (M6d2).
// Edited by Claude: thermal velocity gate, default 0.25 °C (M6d4).
// Edited by Claude: local wall-store rebuild on edits (M6e2).
// Edited by Claude: velocity hold cycle with wake events, report-only (M6e4).
// Edited by Claude: per-cell background temperature for the initial field, solvers, gate and hold; background
// updates leave the hold alone; the weather shift of following air; report-only contrast gate mode, store shift
// and contrast hold trigger (M7a); the store shift is D3's default (Bright, 2026-11-13); per-door toggles and
// entity heat that never wakes the hold (M7a).
// Edited by Claude: edit batches may place and remove doors (M7b).
// Edited by Claude: fixed wall temperatures (M7c).
// Edited by Claude: report-only keep-fine that follows source changes (M7f); on by default (M7f adoption).
// Edited by Claude: report-only store shift limited to stores beside fully following air (M7f).
// Edited by Claude: report-only wind-change handling for the velocity hold (M7f).
// Edited by Claude: the outdoor-store shift and wind changes that leave the hold are D3's defaults (M7f adoption).
package dev.brights0ng.greedyfluids.refine;

import dev.brights0ng.greedyfluids.grid.CellEdit3D;
import dev.brights0ng.greedyfluids.grid.CellGrid3D;
import dev.brights0ng.greedyfluids.grid.CellType;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D.BoundaryKind;
import dev.brights0ng.greedyfluids.mesh.GreedyMesher3D;
import dev.brights0ng.greedyfluids.mesh.InflowExposure3D;
import dev.brights0ng.greedyfluids.mesh.MeshConstraint3D;
import dev.brights0ng.greedyfluids.mesh.StaticRefinement3D;
import dev.brights0ng.greedyfluids.solve.Background3D;
import dev.brights0ng.greedyfluids.solve.BoxSolver3D;
import dev.brights0ng.greedyfluids.solve.SolverConfig3D;
import dev.brights0ng.greedyfluids.solve.StepStats;
import dev.brights0ng.greedyfluids.solve.WallStore3D;
import java.util.Arrays;
import java.util.List;
import java.util.function.IntToDoubleFunction;
import java.util.function.IntUnaryOperator;

/** Adaptive cuboid mesh with axis limits, conservative remap and a cold pressure projection. */
public final class AdaptiveMesh3D {
    /** Which old boxes a split-cadence or edit remesh rebuilds; merge-cadence remeshes are always full. */
    /** FULL: always a full mesh; RING (default since M6c2): rebuild the boxes holding dirty cells; SECTION (default
     *  M3c–M6c1): widen to 16³ sections; BLOCK8 (report-only, M6c2): widen to 8³ blocks. */
    public enum LocalScope { FULL, RING, SECTION, BLOCK8 }
    private final CellGrid3D grid;
    private final SolverConfig3D config;
    private final RefineSettings settings;
    private WallStore3D walls;
    private final int[] limX, limY, limZ, calm;
    private final byte[] limitCause;
    private boolean warmPressure = true;
    private final double[][] cells, unitFaces;
    private Background3D background;
    private final MeshConstraint3D constraint;
    private final boolean[] keepFine, dirty;
    private final StaticRefinement3D.OpeningRule openingRule;
    private final byte[] axisMask;
    private LocalScope scope = LocalScope.RING;
    private final int[] localStats = new int[3];
    private long localRemeshes, localRebuilt, localKept, localRounds;
    private BoxSolver3D solver;
    private Indicators3D indicators;
    private Remap3D.Raster raster;
    private double[][] boxFields;
    private final StepStats stats = new StepStats();
    private long steps, lastEvalStep, remeshes, changed, skipped, splitEvents, mergeEvents, boxSum, samples;
    private int phase, skippedInRow, boxMin, boxMax;
    private long changedBoxes, remapPCG;
    private double energyBefore = Double.NaN, energyAfter = Double.NaN, divergenceAfter = Double.NaN;
    private double maxEnergyError, maxDivergence, remeshMs, meshMs, projectMs;
    private long editApplications;
    private double editMs, maxEditDivergence;

    /** Initial cell T is in °C (null means ambient); limits start at maxExtent, at most 16 cells. */
    public AdaptiveMesh3D(CellGrid3D grid, double[] initialT, SolverConfig3D config, RefineSettings settings) {
        this(grid, initialT, config, settings, StaticRefinement3D.DEFAULT_RULE);
    }

    /** As above, with an explicit opening rule (M6b2); StaticRefinement3D.DEFAULT_RULE is the default. */
    public AdaptiveMesh3D(CellGrid3D grid, double[] initialT, SolverConfig3D config, RefineSettings settings,
            StaticRefinement3D.OpeningRule openingRule) {
        this(grid, initialT, config, settings, openingRule,
                Background3D.uniform(grid.nx(), grid.ny(), grid.nz(), config.ambientT()));
    }

    /**
     * As above, with a background temperature field (M7a; °C per cell). Initial cell T null means the background.
     * The background replaces config ambientT in the solver (see {@link Background3D}), the thermal velocity gate
     * and the velocity hold's flow test.
     */
    public AdaptiveMesh3D(CellGrid3D grid, double[] initialT, SolverConfig3D config, RefineSettings settings,
            StaticRefinement3D.OpeningRule openingRule, Background3D background) {
        if (settings.maxExtent() > 16) throw new IllegalArgumentException("maxExtent exceeds 16");
        if (!background.fits(grid.nx(), grid.ny(), grid.nz())) throw new IllegalArgumentException("background does not fit the grid");
        this.background = background;
        this.grid = grid; this.config = config; this.settings = settings;
        int n = grid.nx() * grid.ny() * grid.nz();
        if (initialT != null && initialT.length != n) throw new IllegalArgumentException("initial T length");
        limX = new int[n]; limY = new int[n]; limZ = new int[n]; calm = new int[n]; dirty = new boolean[n];
        Arrays.fill(limX, settings.maxExtent()); Arrays.fill(limY, settings.maxExtent());
        Arrays.fill(limZ, settings.maxExtent());
        limitCause = new byte[n];
        cells = new double[4][n];
        if (initialT != null) System.arraycopy(initialT, 0, cells[0], 0, n);
        else for (int i = 0; i < n; i++) cells[0][i] = background.cell(i);
        unitFaces = new double[][]{new double[(grid.nx() + 1) * grid.ny() * grid.nz()],
                new double[grid.nx() * (grid.ny() + 1) * grid.nz()],
                new double[grid.nx() * grid.ny() * (grid.nz() + 1)]};
        constraint = new MeshConstraint3D(grid, limX, limY, limZ, cells,
                new double[]{0.5 * settings.epsT(), 0.5 * settings.epsU(), 0.5 * settings.epsU(), 0.5 * settings.epsU()});
        this.openingRule = openingRule;
        StaticRefinement3D.Marks marks = StaticRefinement3D.marks(grid, openingRule);
        keepFine = marks.fine(); axisMask = marks.axis();
        constraint.setAxisMask(axisMask);
        setThermalVelocityGate(DEFAULT_THERMAL_GATE);
        BoxGraph3D g = mesh();
        walls = new WallStore3D(grid, config.rhoCp());
        solver = new BoxSolver3D(g, walls, config);
        solver.setBackground(background);
        double[] t = new double[g.boxCount()]; Remap3D.boxMeans(g, cells[0], t);
        for (int b = 0; b < t.length; b++) solver.setTemperature(b, t[b]);
        solver.setSources(g.sourcePowers(grid)); solver.equilibrateWallStores();
        attach(); stats.boxes = g.boxCount();
        boxMin = boxMax = g.boxCount(); boxSum = g.boxCount(); samples = 1;
    }

    private BoxGraph3D mesh() {
        return GreedyMesher3D.mesh(grid, keepFine, GreedyMesher3D.DEFAULT_GRADING, constraint, config.rhoCp());
    }
    /** Full mesh, or a local one around the dirty cells (SECTION widens them to whole 16³ sections); clears dirty. */
    private BoxGraph3D mesh(boolean local) {
        BoxGraph3D g;
        if (local && scope != LocalScope.FULL) {
            if (scope == LocalScope.SECTION) widenToSections();
            else if (scope == LocalScope.BLOCK8) widenToBlocks(8);
            if (fullFallback < 1 && rebuildFraction() > fullFallback) { local = false; fallbacks++; }
        }
        // The mesher reads raster cells (constraint fields) only inside the boxes it rebuilds. A single-round local
        // mesh rebuilds exactly the old boxes holding dirty cells, so only those need rasterising before it.
        if (raster.isLocal()) {
            BoxGraph3D old = graph();
            if (local && scope != LocalScope.FULL && singleRound) {
                for (int c = 0; c < dirty.length; c++) if (dirty[c]) Remap3D.rasteriseCell(raster, c);
            } else for (int b = 0; b < old.boxCount(); b++) Remap3D.rasteriseBox(raster, b);
        }
        if (!local || scope == LocalScope.FULL) g = mesh();
        else {
            g = GreedyMesher3D.meshLocal(grid, keepFine, GreedyMesher3D.DEFAULT_GRADING, constraint, config.rhoCp(),
                    graph(), dirty, localStats, singleRound);
            localRemeshes++; localRounds += localStats[0]; localRebuilt += localStats[1]; localKept += localStats[2];
        }
        Arrays.fill(dirty, false);
        if (verifyMesh && GreedyMesher3D.violations(g, GreedyMesher3D.DEFAULT_GRADING) > 0)
            throw new IllegalStateException("mesh rule violation after " + (local ? "local" : "full") + " remesh at step " + steps);
        return g;
    }
    private boolean verifyMesh;
    private boolean singleRound = true, localMerge;
    private boolean localRaster = true;
    /**
     * Remeshes and edits rasterise only the old boxes they read or replace, and unchanged boxes and faces keep
     * their exact old values (default on since M6c3). Off: the full raster and transfer, which return those values
     * to roundoff (the identity reference).
     */
    public void setLocalRaster(boolean on) { localRaster = on; }
    private boolean localWallStores = true;
    /**
     * Edits rebuild the wall stores along the edited cells' axis lines only (default on since M6e2). Off: the full
     * rebuild from a scan of the grid, which gives the same stores bit for bit (the identity reference).
     */
    public void setLocalWallStores(boolean on) { localWallStores = on; }
    private double fullFallback = 1;
    private long fallbacks;
    /** Local remeshes grade violating kept boxes in place instead of restarting (default on since M6c2; off restarts). */
    public void setSingleRoundLocal(boolean on) { singleRound = on; }
    /** Report-only (M6c2): merge-cadence remeshes are local around the cells whose limits were raised (default full). */
    public void setLocalMergeRemesh(boolean on) { localMerge = on; }
    /**
     * Report-only (M6c2): a local remesh whose widened dirty cells touch more than this fraction of the old boxes
     * runs as a full mesh. 1 (the default) never falls back.
     */
    public void setFullFallback(double fraction) {
        if (!(fraction > 0 && fraction <= 1)) throw new IllegalArgumentException("fallback fraction in (0, 1]");
        fullFallback = fraction;
    }
    /** Local remeshes run as full meshes by the fallback (M6c2). */
    public long fullFallbacks() { return fallbacks; }

    /**
     * Default thermal velocity gate, °C (M6d4; Bright, 2026-11-10). It compares each box's temperature with its
     * background (Background3D, M7a), so the host must keep the background equal to the air the region would have
     * at rest; where it does not, the gate opens and cost reverts toward the ungated mesh.
     */
    public static final double DEFAULT_THERMAL_GATE = 0.25;
    private double thermalDelta = Double.NaN;
    private boolean[] activeBoxes, velocityCells;
    /**
     * Thermal velocity gate (M6d4, I-c): velocity jumps split boxes, hold them uncalm and guard merges only in boxes
     * whose temperature differs from their background by more than delta °C, and in their face neighbours. Velocity
     * only feeds temperature, so velocity structure in air at its background is not resolved. Evaluated at each indicator evaluation;
     * the merge guard uses the cells of those boxes. Default {@link #DEFAULT_THERMAL_GATE}; NaN turns it off.
     */
    public void setThermalVelocityGate(double delta) {
        if (!Double.isNaN(delta) && !(delta > 0 && Double.isFinite(delta)))
            throw new IllegalArgumentException("delta must be NaN (off) or finite and > 0");
        thermalDelta = delta;
        if (Double.isNaN(delta)) { velocityCells = null; constraint.setVelocityMask(null); return; }
        velocityCells = new boolean[grid.nx() * grid.ny() * grid.nz()];
        Arrays.fill(velocityCells, true);
        constraint.setVelocityMask(velocityCells);
    }
    /** Thermal velocity gate in force, °C (NaN off). */
    public double thermalVelocityGate() { return thermalDelta; }
    /**
     * What the thermal gate and the hold's flow test count as air that matters (M7a). BACKGROUND (the default):
     * a box more than the gate from its background. CONTRAST (report-only, Bright 2026-11-13): a box with a
     * temperature jump of more than the gate to a face neighbour across an open face, or, on an OPEN domain
     * boundary, more than the gate from its background. Contrast is what velocity acts on (heat moves by u·∇T),
     * so air that trails a moving background uniformly does not open the gate.
     */
    public enum GateMode { BACKGROUND, CONTRAST }
    private GateMode gateMode = GateMode.BACKGROUND;
    /** Selects the gate mode (report-only; BACKGROUND is D3's). */
    public void setGateMode(GateMode mode) { gateMode = java.util.Objects.requireNonNull(mode); }
    /** Gate mode in force. */
    public GateMode gateMode() { return gateMode; }
    /** Boxes whose air matters under the gate mode, at threshold delta °C; allocates the result. */
    private boolean[] warmBoxes(BoxGraph3D g, double delta) {
        int n = g.boxCount();
        boolean[] warm = new boolean[n];
        if (gateMode == GateMode.BACKGROUND) {
            for (int b = 0; b < n; b++) warm[b] = Math.abs(solver.temperature(b) - solver.backgroundT(b)) > delta;
            return warm;
        }
        for (int f = 0; f < g.faceCount(); f++) {
            if (g.aperture(f) == 0) continue;
            int a = g.faceA(f), b = g.faceB(f);
            if (Math.abs(solver.temperature(a) - solver.temperature(b)) > delta) { warm[a] = true; warm[b] = true; }
        }
        for (int k = 0; k < g.boundaryCount(); k++) {
            if (g.boundaryKind(k) != BoundaryKind.OPEN || g.boundaryAperture(k) == 0) continue;
            int b = g.boundaryBox(k);
            if (Math.abs(solver.temperature(b) - solver.backgroundT(b)) > delta) warm[b] = true;
        }
        return warm;
    }
    /** Boxes where velocity counts under the thermal gate (warm boxes and their face neighbours); updates the cell mask. */
    private boolean[] thermalMask(BoxGraph3D g, double[] boxT) {
        int n = g.boxCount();
        if (activeBoxes == null || activeBoxes.length != n) activeBoxes = new boolean[n];
        boolean[] warm = warmBoxes(g, thermalDelta);
        System.arraycopy(warm, 0, activeBoxes, 0, n);
        for (int f = 0; f < g.faceCount(); f++) {
            int a = g.faceA(f), b = g.faceB(f);
            if (warm[a]) activeBoxes[b] = true;
            if (warm[b]) activeBoxes[a] = true;
        }
        for (int c = 0; c < velocityCells.length; c++) {
            int b = g.boxOfCellIndex(c);
            velocityCells[c] = b >= 0 && activeBoxes[b];
        }
        return activeBoxes;
    }
    private double rebuildFraction() {
        BoxGraph3D old = graph();
        boolean[] hit = new boolean[old.boxCount()];
        int count = 0;
        for (int c = 0; c < dirty.length; c++) if (dirty[c]) {
            int x = c % grid.nx(), z = (c / grid.nx()) % grid.nz(), y = c / (grid.nx() * grid.nz());
            int b = old.boxOfCell(x, y, z);
            if (b >= 0 && !hit[b]) { hit[b] = true; count++; }
        }
        return old.boxCount() == 0 ? 0 : (double) count / old.boxCount();
    }
    private void widenToBlocks(int s) {
        int sx = (grid.nx() + s - 1) / s, sy = (grid.ny() + s - 1) / s, sz = (grid.nz() + s - 1) / s;
        boolean[] blk = new boolean[sx * sy * sz];
        for (int c = 0; c < dirty.length; c++) if (dirty[c]) {
            int x = c % grid.nx(), z = (c / grid.nx()) % grid.nz(), y = c / (grid.nx() * grid.nz());
            blk[(y / s * sz + z / s) * sx + x / s] = true;
        }
        for (int c = 0; c < dirty.length; c++) {
            int x = c % grid.nx(), z = (c / grid.nx()) % grid.nz(), y = c / (grid.nx() * grid.nz());
            dirty[c] = blk[(y / s * sz + z / s) * sx + x / s];
        }
    }
    /** Tests and benches: check every new mesh with GreedyMesher3D.violations and throw on any violation. */
    public void setVerifyMeshForTesting(boolean on) { verifyMesh = on; }
    private void widenToSections() {
        int s = GreedyMesher3D.SECTION, sx = (grid.nx() + s - 1) / s, sy = (grid.ny() + s - 1) / s, sz = (grid.nz() + s - 1) / s;
        boolean[] sec = new boolean[sx * sy * sz];
        for (int c = 0; c < dirty.length; c++) if (dirty[c]) {
            int x = c % grid.nx(), z = (c / grid.nx()) % grid.nz(), y = c / (grid.nx() * grid.nz());
            sec[(y / s * sz + z / s) * sx + x / s] = true;
        }
        for (int c = 0; c < dirty.length; c++) {
            int x = c % grid.nx(), z = (c / grid.nx()) % grid.nz(), y = c / (grid.nx() * grid.nz());
            dirty[c] = sec[(y / s * sz + z / s) * sx + x / s];
        }
    }
    private int projectionHalo = 2;
    private boolean localProjection = true;
    private long projectedBoxes, projectionCount;
    /** Local remap projection (true, 2D's default) over changed boxes plus halo face rings; false projects all. */
    public void setRemapProjection(boolean local, int haloRings) {
        if (haloRings < 0) throw new IllegalArgumentException("negative halo");
        localProjection = local; projectionHalo = haloRings;
    }
    /** Mean projected boxes per remap projection. */
    public double meanProjectedBoxes() { return projectionCount == 0 ? 0 : (double) projectedBoxes / projectionCount; }
    /**
     * Rows for the remap projection: boxes of next covering the union footprint of changed old and new boxes
     * (a now-solid footprint cell seeds its fluid face neighbours), widened by projectionHalo face rings,
     * closed faces included. Returns the count, or −1 for a full projection.
     */
    private int projectionRows(BoxGraph3D old, BoxGraph3D next, int[] rows) {
        int n = next.boxCount();
        if (!localProjection) { projectedBoxes += n; projectionCount++; return -1; }
        boolean[] foot = new boolean[keepFine.length];
        for (int b = 0; b < n; b++) {
            int ob = old.boxOfCell(next.boxX0(b), next.boxY0(b), next.boxZ0(b));
            if (!sameBox(old, ob, next, b)) paintCells(next, b, foot);
        }
        for (int ob = 0; ob < old.boxCount(); ob++) {
            int b = next.boxOfCell(old.boxX0(ob), old.boxY0(ob), old.boxZ0(ob));
            if (!sameBox(old, ob, next, b)) paintCells(old, ob, foot);
        }
        int[] dist = new int[n]; Arrays.fill(dist, -1);
        for (int c = 0; c < foot.length; c++) if (foot[c]) {
            int x = c % grid.nx(), z = (c / grid.nx()) % grid.nz(), y = c / (grid.nx() * grid.nz());
            int b = next.boxOfCell(x, y, z);
            if (b >= 0) { dist[b] = 0; continue; }
            for (int d = 0; d < 6; d++) {
                int xx = x + (d == 0 ? -1 : d == 1 ? 1 : 0), yy = y + (d == 2 ? -1 : d == 3 ? 1 : 0), zz = z + (d == 4 ? -1 : d == 5 ? 1 : 0);
                if (grid.inBounds(xx, yy, zz)) { int nb = next.boxOfCell(xx, yy, zz); if (nb >= 0) dist[nb] = 0; }
            }
        }
        for (int ring = 1; ring <= projectionHalo; ring++) {
            boolean added = false;
            for (int f = 0; f < next.faceCount(); f++) {
                int a = next.faceA(f), b = next.faceB(f);
                if (dist[a] >= 0 && dist[a] < ring && dist[b] < 0) { dist[b] = ring; added = true; }
                if (dist[b] >= 0 && dist[b] < ring && dist[a] < 0) { dist[a] = ring; added = true; }
            }
            if (!added) break;
        }
        int count = 0;
        for (int b = 0; b < n; b++) if (dist[b] >= 0) rows[count++] = b;
        projectedBoxes += count; projectionCount++;
        return count == n ? -1 : count;
    }
    private void paintCells(BoxGraph3D g, int b, boolean[] foot) {
        for (int y = g.boxY0(b); y < g.boxY0(b) + g.boxSy(b); y++)
            for (int z = g.boxZ0(b); z < g.boxZ0(b) + g.boxSz(b); z++)
                for (int x = g.boxX0(b); x < g.boxX0(b) + g.boxSx(b); x++) foot[grid.index(x, y, z)] = true;
    }
    private int projectRemap(BoxSolver3D next, BoxGraph3D old) {
        int[] rows = new int[next.graph().boxCount()];
        int count = projectionRows(old, next.graph(), rows);
        return count < 0 ? next.projectRemapped() : next.projectRemappedMasked(rows, count);
    }
    /** Selects the local remesh scope (default SECTION; FULL reproduces M5e1). */
    public void setLocalScope(LocalScope s) { scope = java.util.Objects.requireNonNull(s); }
    /** Local remeshes, and summed rounds, rebuilt and kept old boxes over them. */
    public long localRemeshes() { return localRemeshes; }
    public long localRounds() { return localRounds; }
    public long localRebuiltBoxes() { return localRebuilt; }
    public long localKeptBoxes() { return localKept; }
    private void attach() {
        indicators = new Indicators3D(graph(), solver.gradients());
        raster = new Remap3D.Raster(graph(), cells, unitFaces, solver.gradients());
        boxFields = new double[4][graph().boxCount()];
        if (entityCount > 0) applySources();
    }

    private int holdSteps, refreshSteps, wakeSteps, wakeLeft, cyclePosition;
    private long heldSteps;
    /** Air volume, m³, that may differ before a hold counts as changed (adaptive hold). */
    public static final double HOLD_VOLUME = 32;
    private static final int HOLD_LATTICE = 2, HOLD_CHECK_STEPS = 4;
    private static final double HOLD_SPEED_FLOOR = 0.05;
    private double holdFlowTolerance = Double.NaN, holdDeltaT = Double.NaN;
    private boolean holding, afterHold;
    private int stretchLeft, holdLimit, heldInStretch;
    private double heldSpeed = Double.NaN;
    private double[] holdT;
    /**
     * Velocity hold (M6e4, report-only; off by default). A cycle is holdSeconds of heat-only steps on the held
     * velocity field ({@link BoxSolver3D#stepHeatOnly}; no indicators, no remesh) followed by refreshSeconds of
     * full steps. An event (an edit batch, a door change, a source change, a changed background wind, and this
     * call itself) gives wakeSeconds of full steps and then restarts the cycle at its hold. Seconds are rounded to
     * steps; holdSeconds 0 turns the hold off. Remesh cadences count full steps only.
     */
    public void setVelocityHold(double refreshSeconds, double holdSeconds, double wakeSeconds) {
        if (!(refreshSeconds >= 0 && holdSeconds >= 0 && wakeSeconds >= 0)) throw new IllegalArgumentException("negative or NaN hold time");
        double dt = solver.config().dt();
        holdSteps = (int) Math.round(holdSeconds / dt); refreshSteps = (int) Math.round(refreshSeconds / dt);
        wakeSteps = (int) Math.round(wakeSeconds / dt);
        if (holdSteps > 0 && refreshSteps == 0) throw new IllegalArgumentException("a hold needs refresh steps");
        wake();
    }
    /**
     * Makes the velocity hold adaptive (M6e4, report-only); NaN for either argument restores the fixed cycle.
     * The region then holds only while its flow is steady where it matters, in air more than the thermal gate
     * (0.25 °C if the gate is off) from its background:
     * <ul>
     *   <li>Flow test, at the end of every refresh stretch: the mean speed of such air, sampled on a 2 m lattice, is
     *       compared with the previous measurement (the held flow's, after a hold). The flow counts as changed when
     *       there is more than HOLD_VOLUME m³ of such air and its mean speed moved by more than
     *       max(0.05 m/s, flowTolerance × the earlier mean). A changed flow gets another refresh stretch; an
     *       unchanged one is held.</li>
     *   <li>Hold length: starts at one refresh stretch after an event, doubles (up to holdSeconds) each time a
     *       hold is followed by an unchanged flow, and halves when it is followed by a changed one.</li>
     *   <li>Temperature trigger: a hold ends early once more than HOLD_VOLUME m³ of air is more than deltaT °C
     *       from its temperature at the start of the hold (checked every 2 s).</li>
     * </ul>
     */
    public void setAdaptiveHold(double flowTolerance, double deltaT) {
        if (flowTolerance <= 0 || deltaT <= 0) throw new IllegalArgumentException("hold tolerances must be positive");
        holdFlowTolerance = flowTolerance; holdDeltaT = deltaT;
        wake();
    }
    /** Heat-only steps taken so far. */
    public long heldSteps() { return heldSteps; }
    private long holdsStarted, holdEndsLimit, holdEndsTemperature, flowTests, flowTestsChanged, holdEndsWind;
    /**
     * Adaptive-hold counters (diagnostic, M7a): holds started, holds that ran their full length, holds ended early
     * by the temperature trigger, flow tests at the end of refresh stretches, and those that found the flow changed.
     */
    public long[] holdCounters() {
        return new long[]{holdsStarted, holdEndsLimit, holdEndsTemperature, flowTests, flowTestsChanged, holdEndsWind};
    }
    private boolean adaptiveHold() { return !Double.isNaN(holdFlowTolerance) && !Double.isNaN(holdDeltaT); }
    private void wake() {
        wakeLeft = wakeSteps; cyclePosition = 0;
        holding = afterHold = false; stretchLeft = refreshSteps; holdLimit = refreshSteps; heldSpeed = Double.NaN;
    }

    /** Advances by config.dt() seconds; all non-remesh per-step storage is reused. */
    public void step() {
        if (keepFineStale) refreshKeepFine();
        if (holdSteps == 0) { stepFull(); return; }
        if (wakeLeft > 0) {
            wakeLeft--; stepFull();
            if (wakeLeft == 0 && adaptiveHold()) flowChanged();
            return;
        }
        if (!adaptiveHold()) {
            boolean hold = cyclePosition < holdSteps;
            cyclePosition = (cyclePosition + 1) % (holdSteps + refreshSteps);
            if (hold) stepHeld(); else stepFull();
            return;
        }
        if (holding) {
            stepHeld(); heldInStretch++;
            boolean full = --stretchLeft == 0;
            if (full || heldInStretch % HOLD_CHECK_STEPS == 0 && temperatureMoved()) {
                if (full) holdEndsLimit++; else holdEndsTemperature++;
                holding = false; afterHold = true; stretchLeft = refreshSteps;
            }
            return;
        }
        stepFull();
        if (--stretchLeft > 0) return;
        boolean changed = flowChanged();
        flowTests++; if (changed) flowTestsChanged++;
        if (afterHold) holdLimit = changed ? Math.max(refreshSteps, holdLimit / 2) : Math.min(holdSteps, 2 * holdLimit);
        afterHold = false;
        if (changed) { stretchLeft = refreshSteps; return; }
        holding = true; stretchLeft = Math.min(holdLimit, holdSteps); heldInStretch = 0; holdsStarted++;
        holdWindX = solver.backgroundX(); holdWindZ = solver.backgroundZ();
        BoxGraph3D g = solver.graph();
        if (holdT == null || holdT.length < g.boxCount()) holdT = new double[g.boxCount()];
        for (int b = 0; b < g.boxCount(); b++) holdT[b] = solver.temperature(b);
        if (holdTrigger == HoldTrigger.CONTRAST) recordContrastReference(g);
    }
    private void stepHeld() {
        solver.stepHeatOnly(); stats.copyFrom(solver.stats()); heldSteps++;
        stats.indicatorsEvaluated = stats.remeshed = false;
        stats.splits = stats.merges = stats.skippedRemeshes = stats.remapPcgIterations = 0;
        stats.changedBoxes = stats.unchangedBoxes = 0;
        stats.remeshMs = stats.rasterMs = stats.meshMs = stats.remapMs = stats.remapProjectMs = 0;
        stats.solverBuildMs = stats.indicatorMs = 0;
        stats.divergenceAfterRemap = Double.NaN; stats.remapPcgInitialResidual = Double.NaN;
        boxSum += stats.boxes; samples++;
    }
    /**
     * Measures the mean speed of the air that matters (lattice points more than the thermal gate from their background),
     * compares it with the previous measurement and keeps the new one. A spatial mean, so that gusts and eddies,
     * which move every point but not the mean, do not count as change; a flow that is building up or dying does.
     */
    private boolean flowChanged() {
        BoxGraph3D g = solver.graph();
        double[] out = new double[3];
        double gate = Double.isNaN(thermalDelta) ? DEFAULT_THERMAL_GATE : thermalDelta;
        boolean[] warm = warmBoxes(g, gate);
        double sum = 0; int points = 0;
        for (int y = 0; y < g.ny(); y += HOLD_LATTICE) for (int z = 0; z < g.nz(); z += HOLD_LATTICE)
            for (int x = 0; x < g.nx(); x += HOLD_LATTICE) {
                int box = g.boxOfCell(x, y, z);
                if (box < 0 || !warm[box]) continue;
                if (!solver.sampleVelocity(x + 0.5, y + 0.5, z + 0.5, out)) continue;
                sum += Math.sqrt(out[0] * out[0] + out[1] * out[1] + out[2] * out[2]); points++;
            }
        double volume = points * (double) (HOLD_LATTICE * HOLD_LATTICE * HOLD_LATTICE);
        double speed = points == 0 ? 0 : sum / points, before = heldSpeed;
        boolean first = Double.isNaN(before);
        heldSpeed = speed;
        if (first) return true;
        return volume > HOLD_VOLUME && Math.abs(speed - before) > Math.max(HOLD_SPEED_FLOOR, holdFlowTolerance * before);
    }
    /** Whether more than HOLD_VOLUME m³ of air has moved more than holdDeltaT from its hold-start temperature. */
    private boolean temperatureMoved() {
        BoxGraph3D g = solver.graph();
        if (holdTrigger == HoldTrigger.CONTRAST) return contrastMoved(g);
        double volume = 0;
        for (int b = 0; b < g.boxCount(); b++)
            if (Math.abs(solver.temperature(b) - holdT[b]) > holdDeltaT && (volume += g.boxVolume(b)) > HOLD_VOLUME) return true;
        return false;
    }
    /**
     * What the hold's temperature trigger compares (M7a). ABSOLUTE (D3's): each box's temperature against its
     * temperature at the start of the hold (D3's until 2026-11-14; report-only now). CONTRAST (H2, D3's default since
     * the M7a adoption, Bright 2026-11-14): the temperature difference across each
     * open face, and each OPEN-boundary box's departure from its background, against their values at the start
     * of the hold; a box counts when one of its differences moved by more than deltaT. A room that drifts
     * uniformly does not trip it; a heater building a plume does. Weather shifts and background updates move the
     * references with them, so neither ends a hold by itself.
     */
    public enum HoldTrigger { ABSOLUTE, CONTRAST }
    private HoldTrigger holdTrigger = HoldTrigger.CONTRAST;
    private double[] holdFaceDiff, holdDeparture;
    /** Selects the hold's temperature trigger (CONTRAST, D3's since the M7a adoption; ABSOLUTE is report-only). */
    public void setHoldTrigger(HoldTrigger trigger) {
        if (java.util.Objects.requireNonNull(trigger) != holdTrigger) { holdTrigger = trigger; wake(); }
    }
    /** Hold temperature trigger in force. */
    public HoldTrigger holdTrigger() { return holdTrigger; }
    private void recordContrastReference(BoxGraph3D g) {
        if (holdFaceDiff == null || holdFaceDiff.length < g.faceCount()) holdFaceDiff = new double[g.faceCount()];
        if (holdDeparture == null || holdDeparture.length < g.boxCount()) holdDeparture = new double[g.boxCount()];
        for (int f = 0; f < g.faceCount(); f++)
            holdFaceDiff[f] = solver.temperature(g.faceA(f)) - solver.temperature(g.faceB(f));
        for (int b = 0; b < g.boxCount(); b++) holdDeparture[b] = solver.temperature(b) - solver.backgroundT(b);
    }
    /** Moves the contrast references by an air shift (per box, °C; null for none) and a background change. */
    private void moveContrastReference(double[] moved, Background3D old, Background3D bg) {
        BoxGraph3D g = graph();
        if (moved != null)
            for (int f = 0; f < g.faceCount(); f++) holdFaceDiff[f] += moved[g.faceA(f)] - moved[g.faceB(f)];
        for (int b = 0; b < g.boxCount(); b++)
            holdDeparture[b] += (moved == null ? 0 : moved[b]) - (bg.box(g, b) - old.box(g, b));
    }
    private boolean contrastMoved(BoxGraph3D g) {
        int n = g.boxCount();
        boolean[] moved = new boolean[n];
        for (int f = 0; f < g.faceCount(); f++) {
            if (g.aperture(f) == 0) continue;
            int a = g.faceA(f), b = g.faceB(f);
            if (Math.abs(solver.temperature(a) - solver.temperature(b) - holdFaceDiff[f]) > holdDeltaT) {
                moved[a] = true; moved[b] = true;
            }
        }
        for (int k = 0; k < g.boundaryCount(); k++) {
            if (g.boundaryKind(k) != BoundaryKind.OPEN || g.boundaryAperture(k) == 0) continue;
            int b = g.boundaryBox(k);
            if (Math.abs(solver.temperature(b) - solver.backgroundT(b) - holdDeparture[b]) > holdDeltaT) moved[b] = true;
        }
        double volume = 0;
        for (int b = 0; b < n; b++) if (moved[b] && (volume += g.boxVolume(b)) > HOLD_VOLUME) return true;
        return false;
    }
    private void stepFull() {
        long start = System.nanoTime();
        solver.step(); stats.copyFrom(solver.stats());
        stats.indicatorsEvaluated = stats.remeshed = false;
        stats.splits = stats.merges = stats.skippedRemeshes = stats.remapPcgIterations = 0;
        stats.changedBoxes = stats.unchangedBoxes = 0;
        stats.remeshMs = stats.rasterMs = stats.meshMs = stats.remapMs = stats.remapProjectMs = 0;
        stats.solverBuildMs = stats.indicatorMs = 0;
        long cadenceStart = System.nanoTime();
        stats.divergenceAfterRemap = Double.NaN;
        stats.remapPcgInitialResidual = Double.NaN;
        steps++;
        long cadence = steps + phase;
        boolean merge = cadence % settings.mergeCadence() == 0;
        boolean evaluate = merge || cadence % settings.splitCadence() == 0;
        boolean remesh = false;
        BoxGraph3D g = graph();
        if (evaluate) {
            stats.indicatorsEvaluated = true;
            for (int b = 0; b < g.boxCount(); b++) boxFields[0][b] = solver.temperature(b);
            solver.centreVelocities(boxFields[1], boxFields[2], boxFields[3]);
            boolean[] active = Double.isNaN(thermalDelta) ? null : thermalMask(g, boxFields[0]);
            indicators.evaluate(boxFields[0], boxFields[1], boxFields[2], boxFields[3], settings, active);
            int elapsed = (int) (steps - lastEvalStep);
            for (int b = 0; b < g.boxCount(); b++) {
                boolean lowered = false;
                int lx = Math.max(1, g.boxSx(b) / 2), ly = Math.max(1, g.boxSy(b) / 2), lz = Math.max(1, g.boxSz(b) / 2);
                for (int y = g.boxY0(b); y < g.boxY0(b) + g.boxSy(b); y++)
                    for (int z = g.boxZ0(b); z < g.boxZ0(b) + g.boxSz(b); z++)
                        for (int x = g.boxX0(b); x < g.boxX0(b) + g.boxSx(b); x++) {
                            int c = grid.index(x,y,z);
                            calm[c] = indicators.calm[b] ? (int) Math.min(Integer.MAX_VALUE, (long) calm[c] + elapsed) : 0;
                            if (indicators.splitX[b] && limX[c] > lx) { limX[c] = lx; lowered = true; dirty[c] = true; limitCause[c] = 1; }
                            if (indicators.splitY[b] && limY[c] > ly) { limY[c] = ly; lowered = true; dirty[c] = true; limitCause[c] = 1; }
                            if (indicators.splitZ[b] && limZ[c] > lz) { limZ[c] = lz; lowered = true; dirty[c] = true; limitCause[c] = 1; }
                        }
                if (lowered) { stats.splits++; splitEvents++; remesh = true; }
            }
            lastEvalStep = steps;
        }
        if (merge) {
            for (int b = 0; b < g.boxCount(); b++) {
                boolean raised = false;
                for (int y = g.boxY0(b); y < g.boxY0(b) + g.boxSy(b); y++)
                    for (int z = g.boxZ0(b); z < g.boxZ0(b) + g.boxSz(b); z++)
                        for (int x = g.boxX0(b); x < g.boxX0(b) + g.boxSx(b); x++) {
                            int c = grid.index(x,y,z);
                            if (calm[c] < settings.holdSteps()) continue;
                            int cap = Math.min(16, settings.maxExtent());
                            boolean up = limX[c] < cap || limY[c] < cap || limZ[c] < cap;
                            raised |= up;
                            if (up && localMerge) dirty[c] = true;
                            limX[c] = Math.min(cap, 2 * limX[c]); limY[c] = Math.min(cap, 2 * limY[c]);
                            limZ[c] = Math.min(cap, 2 * limZ[c]); calm[c] = 0;
                            if (limX[c] == cap && limY[c] == cap && limZ[c] == cap) limitCause[c] = 0;
                        }
                if (raised) { stats.merges++; mergeEvents++; remesh = true; }
            }
        }
        stats.indicatorMs = (System.nanoTime() - cadenceStart) * 1e-6;
        if (remesh || merge) remesh(merge);
        stats.boxes = graph().boxCount();
        boxMin = Math.min(boxMin, stats.boxes); boxMax = Math.max(boxMax, stats.boxes);
        boxSum += stats.boxes; samples++;
        stats.ms = (System.nanoTime() - start) * 1e-6;
        stats.otherMs = stats.ms - stats.remeshMs - stats.advectMs - stats.dampBuoyMs
                - stats.projectMs - stats.gradientMs - stats.heatMs - stats.indicatorMs;
    }

    private void remesh(boolean mergeCadence) {
        long start = System.nanoTime();
        double raster0 = raster.rasterMs();
        if (localRaster) Remap3D.prepareLocal(solver, raster); else Remap3D.rasterise(solver, raster);
        long rastered = System.nanoTime();
        double raster1 = raster.rasterMs();
        BoxGraph3D old = graph(), nextGraph = mesh(!mergeCadence || localMerge);
        long meshed = System.nanoTime();
        double raster2 = raster.rasterMs();
        stats.meshMs = (meshed - rastered) * 1e-6 - (raster2 - raster1);
        stats.rasterMs = raster2 - raster0;
        double transferRasterMs = 0;
        boolean same = sameBoxes(old, nextGraph);
        if (same && mergeCadence && skippedInRow < 3) {
            skipped++; skippedInRow++; stats.skippedRemeshes = 1;
        } else {
            remeshes++; skippedInRow = 0;
            if (!same) {
                energyBefore = solver.totalEnergy();
                long building = System.nanoTime();
                BoxSolver3D next = new BoxSolver3D(nextGraph, walls, config, solver.solidDistance());
                stats.solverBuildMs = (System.nanoTime() - building) * 1e-6;
                next.setSources(nextGraph.sourcePowers(grid));
                next.setBackground(background);
                next.setBackgroundWind(solver.backgroundX(), solver.backgroundY(), solver.backgroundZ());
                for (int b = 0; b < old.boxCount(); b++) if (old.isDoor(b))
                    next.setDoorOpen(nextGraph.boxOfCell(old.boxX0(b), old.boxY0(b), old.boxZ0(b)), old.doorOpen(b));
                Remap3D.transfer(raster, nextGraph).install(next);
                next.setTime(solver.time());
                for (int b = 0; b < nextGraph.boxCount(); b++) {
                    int ob = old.boxOfCell(nextGraph.boxX0(b), nextGraph.boxY0(b), nextGraph.boxZ0(b));
                    if (sameBox(old, ob, nextGraph, b)) stats.unchangedBoxes++; else stats.changedBoxes++;
                }
                changedBoxes += stats.changedBoxes;
                long projecting = System.nanoTime();
                stats.remapPcgIterations = projectRemap(next, old); remapPCG += stats.remapPcgIterations;
                if (warmPressure) next.setPressure(carryPressure(nextGraph, old::boxOfCellIndex, solver::pressure));
                stats.remapPcgInitialResidual = next.stats().pcgInitialResidual;
                stats.remapProjectMs = (System.nanoTime() - projecting) * 1e-6;
                projectMs += stats.remapProjectMs;
                energyAfter = next.totalEnergy(); divergenceAfter = next.maxDivergence();
                maxEnergyError = Math.max(maxEnergyError, Math.abs(energyAfter - energyBefore) / Math.max(1, Math.abs(energyBefore)));
                maxDivergence = Math.max(maxDivergence, divergenceAfter);
                stats.divergenceAfterRemap = divergenceAfter;
                transferRasterMs = raster.rasterMs() - raster2; stats.rasterMs += transferRasterMs;
                solver = next; attach(); changed++; stats.remeshed = true;
            }
        }
        stats.remapMs = (System.nanoTime() - meshed) * 1e-6 - transferRasterMs;
        stats.remeshMs = (System.nanoTime() - start) * 1e-6;
        meshMs += stats.meshMs; remeshMs += stats.remeshMs;
    }

    /** Roofed-inflow rule: an edit that changes an INFLOW wall column's roof dirties the whole column. */
    private void markRoofChanges(int[] topsBefore, List<CellEdit3D> edits) {
        if (topsBefore == null) return;
        int[] tops = InflowExposure3D.roofTops(grid);
        for (CellEdit3D e : edits) {
            int col = e.z() * grid.nx() + e.x();
            if (!InflowExposure3D.onInflowWall(grid, e.x(), e.z()) || tops[col] == topsBefore[col]) continue;
            for (int y = 0; y < grid.ny(); y++) dirty[grid.index(e.x(), y, e.z())] = true;
        }
    }
    /**
     * Applies an atomic edit batch now (AIR ↔ SOLID, AIR ↔ DOOR; IMMEDIATE, 2D's default): GridEdits3D rules,
     * keep-fine recomputed from the edited geometry (source changes still leave it fixed), cell limits forced to 1
     * with calm reset in the 3×3×3 ring around each edit, then a full remesh, remap and projection. Fallback T is
     * °C.
     */
    public void applyEdits(List<CellEdit3D> edits, GridEdits3D.FallbackT fallback) {
        if (edits.isEmpty()) return;
        wake();
        long start = System.nanoTime();
        int[] topsBefore = InflowExposure3D.roofTops(grid);
        GridEdits3D.Result edit = GridEdits3D.apply(solver, grid, edits, fallback, raster, localRaster, localWallStores);
        walls = edit.store();
        long applied = System.nanoTime();
        markRoofChanges(topsBefore, edits);
        StaticRefinement3D.Marks marks = StaticRefinement3D.marks(grid, openingRule);
        boolean[] fine = marks.fine();
        for (int c = 0; c < fine.length; c++) if (fine[c] != keepFine[c]) { dirty[c] = true; keepFine[c] = fine[c]; }
        if (axisMask != null)
            for (int c = 0; c < axisMask.length; c++) if (marks.axis()[c] != axisMask[c]) { dirty[c] = true; axisMask[c] = marks.axis()[c]; }
        for (CellEdit3D e : edits)
            for (int y = Math.max(0, e.y() - 1); y <= Math.min(grid.ny() - 1, e.y() + 1); y++)
                for (int z = Math.max(0, e.z() - 1); z <= Math.min(grid.nz() - 1, e.z() + 1); z++)
                    for (int x = Math.max(0, e.x() - 1); x <= Math.min(grid.nx() - 1, e.x() + 1); x++) {
                        int c = grid.index(x, y, z);
                        limX[c] = limY[c] = limZ[c] = 1; calm[c] = 0; dirty[c] = true; limitCause[c] = 2;
                    }
        long marked = System.nanoTime();
        BoxGraph3D before = graph();
        BoxGraph3D nextGraph = mesh(true);
        long meshed = System.nanoTime();
        long[] projectNs = new long[1];
        BoxSolver3D next = GridEdits3D.rebuild(solver, edit, raster, nextGraph, grid, s -> {
            long p = System.nanoTime();
            int iterations = projectRemap(s, before);
            projectNs[0] = System.nanoTime() - p;
            return iterations;
        });
        if (warmPressure) next.setPressure(carryPressure(nextGraph, before::boxOfCellIndex, solver::pressure));
        long rebuilt = System.nanoTime();
        maxEditDivergence = Math.max(maxEditDivergence, next.maxDivergence());
        solver = next; attach();
        editApplications++;
        long end = System.nanoTime();
        editStageMs[0] += (applied - start) * 1e-6;
        editStageMs[1] += (marked - applied) * 1e-6;
        editStageMs[2] += (meshed - marked) * 1e-6;
        editStageMs[3] += (rebuilt - meshed - projectNs[0]) * 1e-6;
        editStageMs[4] += projectNs[0] * 1e-6;
        editStageMs[5] += (end - rebuilt) * 1e-6;
        editMs += (end - start) * 1e-6;
    }
    private final double[] editStageMs = new double[6];
    /** Edit sub-stage names, in the order of {@link #editStageMs()}. */
    public static final java.util.List<String> EDIT_STAGES =
            java.util.List.of("apply", "keepFine", "mesh", "build", "project", "attach");
    /**
     * Cumulative edit wall time by sub-stage, ms (a copy): apply (GridEdits3D.apply: mixing, fallback, wall-store
     * rebuild), keepFine (keep-fine recompute and ring marking), mesh (local mesh and graph), build (replacement
     * solver, remap install, carried state), project (remap projection), attach (indicators and raster). They sum
     * to {@link #editMs()}.
     */
    public double[] editStageMs() { return editStageMs.clone(); }
    /** Edit applications, total edit wall time (ms) and largest post-edit |div| (1/s). */
    public long editApplications() { return editApplications; }
    public double editMs() { return editMs; }
    public double maxEditDivergence() { return maxEditDivergence; }

    private static boolean sameBox(BoxGraph3D a, int i, BoxGraph3D b, int j) {
        return i >= 0 && j >= 0 && a.boxX0(i) == b.boxX0(j) && a.boxY0(i) == b.boxY0(j) && a.boxZ0(i) == b.boxZ0(j)
                && a.boxSx(i) == b.boxSx(j) && a.boxSy(i) == b.boxSy(j) && a.boxSz(i) == b.boxSz(j);
    }
    /** Geometry equality in the mesher's deterministic box order. */
    public static boolean sameBoxes(BoxGraph3D a, BoxGraph3D b) {
        if (a.boxCount() != b.boxCount()) return false;
        for (int i = 0; i < a.boxCount(); i++) if (!sameBox(a,i,b,i)) return false;
        return true;
    }

    /**
     * Warm pressure carry after remap projection, in m²/s; on by default since M6b1.
     * M6a: −16 to −18 % PCG iterations on edits; no change under wind.
     * Setting false restores the cold remap projection start.
     */
    public void setWarmPressure(boolean on) { warmPressure = on; }

    /** Mean old pressure (m²/s) over each new box's cells that belonged to an old box; zero if none. */
    static double[] carryPressure(BoxGraph3D next, IntUnaryOperator oldBoxOfCell, IntToDoubleFunction oldPhi) {
        double[] phi = new double[next.boxCount()];
        for (int b = 0; b < next.boxCount(); b++) {
            int count = 0;
            double sum = 0;
            for (int y = next.boxY0(b); y < next.boxY0(b) + next.boxSy(b); y++)
                for (int z = next.boxZ0(b); z < next.boxZ0(b) + next.boxSz(b); z++)
                    for (int x = next.boxX0(b); x < next.boxX0(b) + next.boxSx(b); x++) {
                        int old = oldBoxOfCell.applyAsInt((y * next.nz() + z) * next.nx() + x);
                        if (old >= 0) { sum += oldPhi.applyAsDouble(old); count++; }
                    }
            if (count > 0) phi[b] = sum / count;
        }
        return phi;
    }

    /** Fluid, keep-fine, ring-, split- and other-limited cell counts, then boxes containing keep-fine fluid. */
    public int[] limitCauseCounts() {
        int[] counts = new int[6];
        boolean[] fineBoxes = new boolean[graph().boxCount()];
        int cap = Math.min(16, settings.maxExtent());
        for (int c = 0; c < keepFine.length; c++) {
            int b = graph().boxOfCellIndex(c);
            if (b < 0) continue;
            counts[0]++;
            if (keepFine[c]) { counts[1]++; fineBoxes[b] = true; }
            else if (Math.min(limX[c], Math.min(limY[c], limZ[c])) < cap)
                counts[limitCause[c] == 2 ? 2 : limitCause[c] == 1 ? 3 : 4]++;
        }
        for (boolean fine : fineBoxes) if (fine) counts[5]++;
        return counts;
    }

    /** Independently marked opening, source and door cells, including solids and overlaps. */
    public int[] keepFineRuleCounts() { return StaticRefinement3D.ruleCounts(grid); }
    /** The opening rule this mesh was built with. */
    public StaticRefinement3D.OpeningRule openingRule() { return openingRule; }
    /** Fluid cells with a nonzero axis mask (axis-limited opening rules; 0 otherwise). */
    public int axisMaskedCells() {
        if (axisMask == null) return 0;
        int n = 0;
        for (int c = 0; c < axisMask.length; c++) if (axisMask[c] != 0 && grid.type(c % grid.nx(), c / grid.nx() / grid.nz(), c / grid.nx() % grid.nz()).isFluid()) n++;
        return n;
    }

    /** Current solver and graph; replaced only when box geometry changes. */
    public BoxSolver3D solver() { return solver; }
    public BoxGraph3D graph() { return solver.graph(); }
    /** Last-step statistics, including adaptive work. */
    public StepStats stats() { return stats; }
    /** Test/bench cadence offset, in steps. */
    public void setCadencePhaseForTesting(int value) {
        if (value < 0) throw new IllegalArgumentException("negative cadence phase");
        phase = value;
    }
    /** Changes all doors; apertures survive subsequent remeshes. */
    /**
     * Opens or closes one door cell (M7a): its box's faces open or close and the pocket rule is re-evaluated at
     * the next projection. Wakes the velocity hold when the state changes. Rejects a cell that is not a DOOR.
     */
    public void setDoorOpen(int x, int y, int z, boolean open) {
        if (grid.type(x,y,z) != CellType.DOOR) throw new IllegalArgumentException("not a door cell: " + x + "," + y + "," + z);
        if (grid.doorOpen(x,y,z) == open) return;
        grid.setDoorOpen(x,y,z,open); solver.setDoorOpen(graph().boxOfCell(x,y,z),open); wake();
    }
    private int entityCount;
    private int[] entityCells = new int[0];
    private double[] entityWatts = new double[0];
    /**
     * Replaces the heat of moving entities (players and mobs; M7a): one entry per entity, at its position in
     * region metres, xyzw packed as x, y, z, watts. It is added to the boxes' block sources but never changes the
     * mesh's static refinement and never wakes the velocity hold (Bright, 2026-11-13); the hold's temperature
     * trigger still ends a hold that the heat disturbs. Entries outside the grid or in solid are dropped; returns
     * how many were kept.
     */
    public int setEntityHeat(double[] xyzw) {
        if (xyzw.length % 4 != 0) throw new IllegalArgumentException("expected x, y, z, watts per entity");
        int n = xyzw.length / 4, kept = 0;
        if (entityCells.length < n) { entityCells = new int[n]; entityWatts = new double[n]; }
        for (int i = 0; i < n; i++) {
            int x = (int) Math.floor(xyzw[4 * i]), y = (int) Math.floor(xyzw[4 * i + 1]), z = (int) Math.floor(xyzw[4 * i + 2]);
            double w = xyzw[4 * i + 3];
            if (!Double.isFinite(w)) throw new IllegalArgumentException("entity heat must be finite");
            if (!grid.inBounds(x,y,z) || !grid.type(x,y,z).isFluid() || w == 0) continue;
            entityCells[kept] = grid.index(x,y,z); entityWatts[kept] = w; kept++;
        }
        boolean had = entityCount > 0;
        entityCount = kept;
        if (kept > 0 || had) applySources();
        return kept;
    }
    /** Total entity heat in force, W. */
    public double entityHeat() {
        double sum = 0;
        for (int i = 0; i < entityCount; i++) sum += entityWatts[i];
        return sum;
    }
    /** Block sources per box plus entity heat, onto the current solver. */
    private void applySources() {
        BoxGraph3D g = graph();
        double[] watts = g.sourcePowers(grid);
        for (int i = 0; i < entityCount; i++) {
            int b = g.boxOfCellIndex(entityCells[i]);
            if (b >= 0) watts[b] += entityWatts[i];
        }
        solver.setSources(watts);
    }
    public void setDoorsOpen(boolean open) {
        wake();
        BoxGraph3D g = graph();
        for (int b = 0; b < g.boxCount(); b++) if (g.isDoor(b)) {
            grid.setDoorOpen(g.boxX0(b),g.boxY0(b),g.boxZ0(b),open); solver.setDoorOpen(b,open);
        }
    }
    /**
     * Replaces the background temperature field (°C per cell; M7a). Wall stores and the mesh keep their state:
     * the new background acts through buoyancy, open boundaries, AMBIENT wall stores, the thermal gate and the
     * hold's flow test from the next step. It does not wake the velocity hold (Bright, 2026-11-13, after the ramp
     * pre-flight: waking moved mean temperatures by at most 0.05 °C and cost 10–17 % more); the hold's
     * temperature trigger still ends a hold that the change disturbs.
     */
    public void setBackground(Background3D bg) { setBackground(bg, false); }
    /** As above; wake true (report-only) also wakes the velocity hold, the behaviour before the decision. */
    public void setBackground(Background3D bg, boolean wake) {
        if (!bg.fits(grid.nx(), grid.ny(), grid.nz())) throw new IllegalArgumentException("background does not fit the grid");
        Background3D old = background;
        background = bg;
        double[] moved = bg.follows() ? shiftAir(old, bg) : null;
        if (holding && holdTrigger == HoldTrigger.CONTRAST) moveContrastReference(moved, old, bg);
        solver.setBackground(bg);
        if (wake) wake();
    }
    private boolean shiftStores = true;
    /**
     * H1 (M7a; D3's default, Bright 2026-11-13): the weather shift also moves wall stores that touch following
     * air, by their near cell's follow × Δbackground (an AIR store by the mean over its two cells), so exposed
     * walls and ground follow the day as the air does. On by default; false is the report-only air-only shift.
     */
    public void setShiftStores(boolean on) { shiftStores = on; }
    /** Whether the weather shift moves wall stores too. */
    public boolean shiftStores() { return shiftStores; }
    private boolean shiftOutdoorStoresOnly = true;
    /**
     * The store shift moves a store only by the near cells that fully follow (follow 1, open sky). Air that partly
     * follows (lit through a window or an open door) still shifts, but the walls around it don't: with graded
     * follow, H1 made a door opened for a minute while the weather warmed move its room's walls and floor by
     * follow × Δ (+155 MJ in Meteodyne's model soak). D3's default since the M7f adoption (Bright, 2026-11-16);
     * false is H1 as adopted in M7a (report-only).
     */
    public void setShiftOutdoorStoresOnly(boolean on) { shiftOutdoorStoresOnly = on; }
    /** Whether the store shift is limited to stores beside fully following air. */
    public boolean shiftOutdoorStoresOnly() { return shiftOutdoorStoresOnly; }
    private double shiftEnergy;
    private long shifts;
    /**
     * Weather shift (Bright, 2026-11-13): each box moves by the mean of follow × (new − old background) over its
     * cells, the new field's follow weights. A hold's reference temperatures move with it, so the shift itself
     * does not end a hold. The energy added (J) is counted in {@link #backgroundShiftEnergy}; it falls between
     * steps, so no step's energy residual sees it.
     */
    private double[] shiftAir(Background3D old, Background3D bg) {
        BoxGraph3D g = graph();
        int n = g.boxCount();
        double[] sum = new double[n];
        for (int c = 0; c < cells[0].length; c++) {
            double w = bg.follow(c);
            if (w == 0) continue;
            int b = g.boxOfCellIndex(c);
            if (b >= 0) sum[b] += w * (bg.cell(c) - old.cell(c));
        }
        double energy = 0;
        for (int b = 0; b < n; b++) {
            if (sum[b] == 0) continue;
            double d = sum[b] / ((double) g.boxSx(b) * g.boxSy(b) * g.boxSz(b));
            sum[b] = d;
            solver.setTemperature(b, solver.temperature(b) + d);
            if (holdT != null && b < holdT.length) holdT[b] += d;
            energy += config.rhoCp() * g.boxVolume(b) * d;
        }
        if (shiftStores) {
            WallStore3D w = solver.wallStore();
            for (int i = 0; i < w.count(); i++) {
                if (w.isFixed(i)) continue;
                int a = w.cellA(i), b = w.cellB(i);
                double d = storeShare(bg, old, a);
                if (w.kind(i) == WallStore3D.AIR) d = 0.5 * (d + storeShare(bg, old, b));
                if (d == 0) continue;
                w.setTemperature(i, w.temperature(i) + d);
                energy += w.capacity(i) * d;
            }
        }
        shiftEnergy += energy; shifts++;
        return sum;
    }
    /** A store's shift from one near cell: follow × Δbackground, or 0 off open sky when limited to outdoor stores. */
    private double storeShare(Background3D bg, Background3D old, int c) {
        double f = bg.follow(c);
        return shiftOutdoorStoresOnly && f < 1 ? 0 : f * (bg.cell(c) - old.cell(c));
    }
    /** Energy added by weather shifts so far, J (M7a). */
    public double backgroundShiftEnergy() { return shiftEnergy; }
    /** Background updates that carried follow weights so far. */
    public long backgroundShifts() { return shifts; }
    /** Background temperature field, °C per cell. */
    public Background3D background() { return background; }
    /**
     * What a changed background wind does to the velocity hold (M7f, report-only; Bright, 2026-11-16, after
     * Meteodyne's profile: wind re-sent on every 0.25 m/s move kept the hold from ever starting).
     * <ul>
     *   <li>WAKE (D3 before M7f): an event, as an edit: wake seconds of full steps, then the cycle restarts.</li>
     *   <li>END: a running hold ends as if its temperature trigger had, so the new wind is in the flow after one
     *       refresh stretch and the flow test that follows it; outside a hold, nothing.</li>
     *   <li>NONE (D3's default since the M7f adoption): nothing, as background changes, so the wind reaches a held
     *       flow when the hold ends; but once the wind has moved, since the hold began, by more than the flow
     *       test's tolerance (25 % of its speed then) or {@link #WIND_HOLD_FLOOR} m/s, the hold ends as with END
     *       (Claude's safety valve for a gust front or a storm: a held flow may then lag the wind ≤ 110 s).</li>
     * </ul>
     */
    public enum WindWake { WAKE, END, NONE }
    /** The smallest wind move, m/s, that ends a hold under NONE. */
    public static final double WIND_HOLD_FLOOR = 0.5;
    private WindWake windWake = WindWake.NONE;
    private double holdWindX, holdWindZ;
    /** Sets what a changed background wind does to the velocity hold. */
    public void setWindWake(WindWake mode) { windWake = java.util.Objects.requireNonNull(mode); }
    /** What a changed background wind does to the velocity hold. */
    public WindWake windWake() { return windWake; }
    /** Horizontal background wind components, m/s. */
    public void setBackgroundWind(double wx, double wz) {
        if (wx != solver.backgroundX() || wz != solver.backgroundZ()) {
            switch (windWake) {
                case WAKE -> wake();
                case END -> { if (holding) endHoldByWind(); }
                case NONE -> {
                    double tolerance = Math.max(WIND_HOLD_FLOOR,
                            (Double.isNaN(holdFlowTolerance) ? 0.25 : holdFlowTolerance) * Math.hypot(holdWindX, holdWindZ));
                    if (holding && Math.hypot(wx - holdWindX, wz - holdWindZ) > tolerance) endHoldByWind();
                }
            }
        }
        solver.setBackgroundWind(wx,0,wz);
    }
    private void endHoldByWind() { holding = false; afterHold = true; stretchLeft = refreshSteps; holdEndsWind++; }
    /**
     * Sets cell power, W. With {@link #setSourceKeepFine} on (D3's default), a cell whose source turns on or off has
     * the static marks recomputed before the next step; off (report-only), keep-fine stays as built (as 2D).
     */
    public void setSource(int x, int y, int z, double watts) {
        boolean had = grid.sources().containsKey(grid.index(x,y,z));
        grid.setSource(x,y,z,watts);
        if (sourceKeepFine && had != (watts != 0)) keepFineStale = true;
        if (entityCount > 0) applySources(); else solver.setSources(graph().sourcePowers(grid));
        wake();
    }
    private boolean sourceKeepFine = true, keepFineStale;
    private long keepFineRemeshes;
    /**
     * Keep-fine follows sources (M7f; on by default since the M7f adoption, Bright 2026-11-15): when a cell's source
     * turns on or off ({@link #setSource}), the static marks ({@link StaticRefinement3D#marks}: the source cubes,
     * doors and openings) are recomputed before the next step, and the cells whose marks changed are remeshed
     * locally, with the remap and projection of a cadence remesh, and the velocity hold woken. Off (report-only, D3
     * before the adoption): keep-fine stays as built, and as the last edit batch left it (edit batches always
     * recompute the marks). Turning it back on catches up with sources set since then.
     */
    public void setSourceKeepFine(boolean on) {
        if (on && !sourceKeepFine) keepFineStale = true;
        sourceKeepFine = on;
    }
    /** Whether keep-fine follows sources. */
    public boolean sourceKeepFine() { return sourceKeepFine; }
    /** Local remeshes made because a source change moved the keep-fine marks. */
    public long keepFineRemeshes() { return keepFineRemeshes; }
    private void refreshKeepFine() {
        keepFineStale = false;
        StaticRefinement3D.Marks marks = StaticRefinement3D.marks(grid, openingRule);
        boolean[] fine = marks.fine();
        boolean changed = false;
        for (int c = 0; c < fine.length; c++) if (fine[c] != keepFine[c]) { dirty[c] = true; keepFine[c] = fine[c]; changed = true; }
        if (axisMask != null)
            for (int c = 0; c < axisMask.length; c++) if (marks.axis()[c] != axisMask[c]) { dirty[c] = true; axisMask[c] = marks.axis()[c]; changed = true; }
        if (!changed) return;
        keepFineRemeshes++;
        remesh(false);
        wake();
    }
    /**
     * Fixes a SOLID cell's wall temperature, °C, or clears it with NaN (M7c): the wall stores holding the block keep
     * that temperature. A change wakes the velocity hold.
     */
    public void setFixedTemperature(int x, int y, int z, double celsius) {
        grid.setFixedTemperature(x, y, z, celsius);
        if (solver.wallStore().refreshFixed(grid)) wake();
    }
    /** Allowed extents in cells, and calm duration in steps, for a cell. */
    public int limitX(int x, int y, int z) { return limX[grid.index(x,y,z)]; }
    public int limitY(int x, int y, int z) { return limY[grid.index(x,y,z)]; }
    public int limitZ(int x, int y, int z) { return limZ[grid.index(x,y,z)]; }
    public int calm(int x, int y, int z) { return calm[grid.index(x,y,z)]; }
    /** Most recent changed remap's total air+wall energies, J, and projected divergence, 1/s. */
    public double energyBeforeRemap() { return energyBefore; }
    public double energyAfterRemap() { return energyAfter; }
    public double divergenceAfterRemap() { return divergenceAfter; }
    /** Cumulative attempt, changed, skipped, split/merge-event and changed-new-box counts. */
    public long remeshCount() { return remeshes; }
    public long changedRemeshes() { return changed; }
    public long skippedRemeshes() { return skipped; }
    public long splitEvents() { return splitEvents; }
    public long mergeEvents() { return mergeEvents; }
    public long changedBoxes() { return changedBoxes; }
    /** Box statistics over the initial mesh and every completed step, counts. */
    public int boxMin() { return boxMin; }
    public double boxMean() { return (double) boxSum / samples; }
    public int boxMax() { return boxMax; }
    /** Maximum relative remap energy error and maximum post-remap divergence (1/s). */
    public double maxRemapEnergyError() { return maxEnergyError; }
    public double maxDivergenceAfterRemap() { return maxDivergence; }
    /** Cumulative remesh/mesh/projection wall times, ms, and remap PCG iterations. */
    public double remeshMs() { return remeshMs; }
    public double meshMs() { return meshMs; }
    public double projectMs() { return projectMs; }
    public long remapPCG() { return remapPCG; }
}
