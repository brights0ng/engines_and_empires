// Written by ChatGPT from Claude's M5d spec.
// Edited by Claude: optional shared gradient workspace (M6c1).
// Edited by Claude: optional per-box velocity mask (M6d4).
// Edited by Claude: optional per-box velocity threshold scale (M8c c2, report-only).
package dev.brights0ng.greedyfluids.refine;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.solve.BoxGradients3D;
import java.util.Arrays;

/** Unlimited weighted-LSQ face-jump indicators; evaluate() allocates nothing and never limits gradients. */
public final class Indicators3D {
    private final BoxGraph3D g;
    private final BoxGradients3D gradients;
    private final double[][] jumpT, jumpU;
    private final double[][][] gradient;
    private final double[][] fields = new double[4][];
    /** Per-box indicators: temperature and unstable stratification in °C, velocity in m/s. */
    public final double[] iT, iU, iS;
    /** Per-box refinement, hysteresis and axis flags. Unit extents are never split. */
    public final boolean[] needsSplit, calm, splitX, splitY, splitZ;

    public Indicators3D(BoxGraph3D graph) { this(graph, new BoxGradients3D(graph)); }

    /** Uses a gradient workspace built for the same graph (for example BoxSolver3D.gradients()). */
    public Indicators3D(BoxGraph3D graph, BoxGradients3D shared) {
        if (shared.graph() != graph) throw new IllegalArgumentException("gradients belong to another graph");
        g = graph; gradients = shared;
        int n = g.boxCount();
        gradient = new double[4][3][n]; jumpT = new double[3][n]; jumpU = new double[3][n];
        iT = new double[n]; iU = new double[n]; iS = new double[n];
        needsSplit = new boolean[n]; calm = new boolean[n];
        splitX = new boolean[n]; splitY = new boolean[n]; splitZ = new boolean[n];
    }

    /** Box-centre T (°C) and reconstructed u, v, w (m/s). */
    public void evaluate(double[] t, double[] u, double[] v, double[] w, RefineSettings s) {
        evaluate(t, u, v, w, s, null);
    }

    /**
     * As above with an optional per-box mask: where velocityActive[b] is false the velocity jumps of box b are
     * ignored (they neither split it nor keep it from being calm). Null counts every box.
     */
    public void evaluate(double[] t, double[] u, double[] v, double[] w, RefineSettings s, boolean[] velocityActive) {
        evaluate(t, u, v, w, s, velocityActive, null);
    }

    /**
     * As above with an optional per-box velocity threshold scale (M8c c2, report-only): box b's velocity jumps count
     * against velocityScale[b] times the threshold (for splitting, calm and the split axes). Null scales nothing.
     */
    public void evaluate(double[] t, double[] u, double[] v, double[] w, RefineSettings s, boolean[] velocityActive,
            double[] velocityScale) {
        double epsU = s.epsU();
        fields[0] = t; fields[1] = u; fields[2] = v; fields[3] = w;
        for (int f = 0; f < 4; f++)
            gradients.gradient(fields[f], gradient[f][0], gradient[f][1], gradient[f][2]);
        for (int a = 0; a < 3; a++) { Arrays.fill(jumpT[a], 0); Arrays.fill(jumpU[a], 0); }
        for (int f = 0; f < g.faceCount(); f++) {
            int a = g.faceA(f), b = g.faceB(f), axis = g.faceAxis(f);
            double normal = axis == 0 ? g.boxX0(b) : axis == 1 ? g.boxY0(b) : g.boxZ0(b);
            double cu = 0.5 * (g.faceU0(f) + g.faceU1(f)), cv = 0.5 * (g.faceV0(f) + g.faceV1(f));
            double x = axis == 0 ? normal : cu;
            double y = axis == 1 ? normal : axis == 0 ? cu : cv;
            double z = axis == 2 ? normal : cv;
            double jt = 4 * jump(0, a, b, x, y, z);
            double ju = 4 * Math.max(jump(1, a, b, x, y, z),
                    Math.max(jump(2, a, b, x, y, z), jump(3, a, b, x, y, z)));
            jumpT[axis][a] = Math.max(jumpT[axis][a], jt); jumpT[axis][b] = Math.max(jumpT[axis][b], jt);
            jumpU[axis][a] = Math.max(jumpU[axis][a], ju); jumpU[axis][b] = Math.max(jumpU[axis][b], ju);
        }
        for (int i = 0; i < g.boxCount(); i++) {
            if (velocityActive != null && !velocityActive[i]) { jumpU[0][i] = 0; jumpU[1][i] = 0; jumpU[2][i] = 0; }
            else if (velocityScale != null && velocityScale[i] != 1) {
                double k = 1 / velocityScale[i];
                jumpU[0][i] *= k; jumpU[1][i] *= k; jumpU[2][i] *= k;
            }
            iT[i] = Math.max(jumpT[0][i], Math.max(jumpT[1][i], jumpT[2][i]));
            iU[i] = Math.max(jumpU[0][i], Math.max(jumpU[1][i], jumpU[2][i]));
            iS[i] = Math.max(0, -gradient[0][1][i]) * g.boxSy(i);
            needsSplit[i] = iT[i] > s.epsT() || iU[i] > epsU || iS[i] > s.epsS();
            calm[i] = iT[i] < 0.5 * s.epsT() && iU[i] < 0.5 * epsU && iS[i] < 0.5 * s.epsS();
            boolean x = jumpT[0][i] > 0.5 * s.epsT() || jumpU[0][i] > 0.5 * epsU;
            boolean y = jumpT[1][i] > 0.5 * s.epsT() || jumpU[1][i] > 0.5 * epsU
                    || iS[i] > 0.5 * s.epsS();
            boolean z = jumpT[2][i] > 0.5 * s.epsT() || jumpU[2][i] > 0.5 * epsU;
            if (needsSplit[i] && !(x || y || z)) x = y = z = true;
            splitX[i] = needsSplit[i] && x && g.boxSx(i) > 1;
            splitY[i] = needsSplit[i] && y && g.boxSy(i) > 1;
            splitZ[i] = needsSplit[i] && z && g.boxSz(i) > 1;
        }
    }

    private double jump(int field, int a, int b, double x, double y, double z) {
        double[][] d = gradient[field];
        return Math.abs(fields[field][a] - fields[field][b]
                + d[0][a] * (x - g.boxCx(a)) + d[1][a] * (y - g.boxCy(a)) + d[2][a] * (z - g.boxCz(a))
                - d[0][b] * (x - g.boxCx(b)) - d[1][b] * (y - g.boxCy(b)) - d[2][b] * (z - g.boxCz(b)));
    }
}
