// Written by ChatGPT from Claude's M5b spec.
// Edited by ChatGPT from Claude's M5d spec.
// Edited by Claude: edit ledger carried across replacement solvers (M5e1).
// Edited by Claude: remap projection without the gravity shift (2D's rule); masked variant (M5e2).
// Edited by Claude: components (and the inflow-pocket rule) refreshed before closures (M6b1).
// Edited by Claude: gradients() shared with indicators and raster (M6c1).
// Edited by Claude: solid distances for sub-stepped advection; speed cap max(maxSpeed, 3|wind|) applied before the
// projection (M6d2).
// Edited by Claude: stepHeatOnly, heat advanced on a held velocity field (M6e4, report-only).
// Edited by Claude: per-cell background temperature (Background3D) in place of the scalar ambient; source(box) (M7a).
// Edited by Claude: EXCHANGE faces' far-side temperatures (M8b).
// Edited by Claude: buoyancy against the background's buoyancy reference (M8b5).
// Edited by Claude: the heat sweeps' relaxation settable after the build (M8e4).
// Edited by Claude: refreshWallCouplings (M8e).
package dev.brights0ng.greedyfluids.solve;

import dev.brights0ng.greedyfluids.mesh.BoxGraph3D;
import dev.brights0ng.greedyfluids.mesh.BoxGraph3D.BoundaryKind;
import java.util.Arrays;

/** Fixed cuboid-mesh flow and heat solver; all per-step storage is allocated at construction. */
public final class BoxSolver3D {
    private final BoxGraph3D g;
    private final WallStore3D walls;
    private SolverConfig3D c; // only its thermal relaxation changes after the build (setThermalRelaxation)
    private final FlowState3D state;
    private final Reconstruction3D reconstruction;
    private final Advection3D advection;
    private final Forcing3D forcing;
    private final PressureProjection3D pressure;
    private final HeatSolve3D heat;
    private final SealedComponents3D components;
    private final SolidDistance3D distance;
    private final StepStats stats = new StepStats();
    private final double[] sources, shift, scratch, cellT, boxBg;
    /** Each box's buoyancy reference, °C, when the background has one of its own (M8b5); null until then. */
    private double[] boxRef;
    private Background3D background;
    private boolean stale = true, componentsDirty, topologyDirty;
    // Edit ledger since the previous step: heat change J, applications and fallback cell counts.
    private double pendingEditEnergy;
    private int pendingEditApplications, pendingFallbackAir, pendingFallbackBlocks;

    /** Speed cap multiple of the background wind speed: the cap is max(maxSpeed, WIND_CAP_FACTOR × |wind|), m/s. */
    public static final double WIND_CAP_FACTOR = 3;

    /** Builds a solver with temperatures in °C and wall stores from the graph's grid. */
    public BoxSolver3D(BoxGraph3D graph, WallStore3D walls, SolverConfig3D config) {
        this(graph, walls, config, SolidDistance3D.of(graph));
    }
    /**
     * As above, reusing solid distances of the same solid cells (a remesh of an unchanged grid, or
     * {@code previous.edited(graph)} after edits).
     */
    public BoxSolver3D(BoxGraph3D graph, WallStore3D walls, SolverConfig3D config, SolidDistance3D distance) {
        g = graph; this.walls = walls; c = config; this.distance = distance;
        state = new FlowState3D(g, c); reconstruction = new Reconstruction3D(g);
        advection = new Advection3D(g, c, reconstruction, distance); forcing = new Forcing3D(g, c);
        pressure = new PressureProjection3D(g, c); heat = new HeatSolve3D(g, walls, c);
        components = new SealedComponents3D(g);
        sources = new double[g.boxCount()]; shift = new double[g.faceCount()]; scratch = new double[g.boxCount()];
        cellT = new double[g.nx() * g.ny() * g.nz()];
        boxBg = new double[g.boxCount()];
        setBackground(Background3D.uniform(g.nx(), g.ny(), g.nz(), c.ambientT()));
        ensureReconstruction();
    }
    /**
     * Sets the background temperature field (°C per cell; uniform at config ambientT until set). It is the
     * reference of buoyancy, open-boundary exchange and inflow, and AMBIENT wall stores' far sides. Box
     * temperatures and wall stores are not changed.
     */
    public void setBackground(Background3D bg) {
        if (!bg.fits(g.nx(), g.ny(), g.nz())) throw new IllegalArgumentException("background does not fit the grid");
        background = bg;
        bg.boxes(g, boxBg);
        double[] ref = boxBg;
        if (!bg.plainBuoyancy()) {
            if (boxRef == null) boxRef = new double[g.boxCount()];
            bg.buoyancyBoxes(g, boxRef);
            ref = boxRef;
        }
        forcing.setBackground(ref); heat.setBackground(bg, boxBg);
    }
    /** Background temperature field, °C per cell. */
    public Background3D background() { return background; }
    /** Mean background temperature of a box, °C. */
    public double backgroundT(int box) { return boxBg[box]; }
    /** Advances flow and heat by config.dt() s; overwrites the step statistics. */
    public void step() {
        long start = System.nanoTime();
        ensureReconstruction();
        stats.editEnergy = pendingEditEnergy; stats.editApplications = pendingEditApplications;
        stats.editFallbackAirCells = pendingFallbackAir; stats.editFallbackBlocks = pendingFallbackBlocks;
        pendingEditEnergy = 0; pendingEditApplications = pendingFallbackAir = pendingFallbackBlocks = 0;
        stats.gradientMs = 0;
        advection.advect(state);
        long advected = System.nanoTime(); stats.advectMs = (advected - start) * 1e-6;
        forcing.damp(state); forcing.buoyancy(state);
        long forced = System.nanoTime(); stats.dampBuoyMs = (forced - advected) * 1e-6;
        refreshComponents();
        state.applyClosures(g);
        stats.clamps = clamp();
        long projectStart = System.nanoTime();
        stats.pcgIterations = project();
        stats.projectMs = (System.nanoTime() - projectStart) * 1e-6;
        measure();
        long heatStart = System.nanoTime();
        heat.solve(state, sources, stats);
        stats.heatMs = (System.nanoTime() - heatStart) * 1e-6 - stats.gradientMs;
        reconstruction.update(state); stale = false;
        state.time += c.dt(); stats.boxes = g.boxCount();
        stats.ms = (System.nanoTime() - start) * 1e-6;
        stats.otherMs = stats.ms - stats.advectMs - stats.dampBuoyMs - stats.projectMs - stats.gradientMs - stats.heatMs;
    }
    /**
     * Advances heat only by config.dt() s, holding the velocity field: no advection of momentum, forcing or
     * projection (M6e4, report-only). The held field is the last projected one, so it stays divergence-free.
     * Overwrites the heat statistics and the step time.
     */
    public void stepHeatOnly() {
        long start = System.nanoTime();
        ensureReconstruction();
        if (stale) { refreshComponents(); state.applyClosures(g); reconstruction.update(state); stale = false; }
        stats.gradientMs = 0;
        heat.solve(state, sources, stats);
        state.time += c.dt(); stats.boxes = g.boxCount();
        stats.ms = (System.nanoTime() - start) * 1e-6;
        stats.heatMs = stats.ms - stats.gradientMs;
        stats.advectMs = stats.dampBuoyMs = stats.projectMs = stats.otherMs = 0; stats.pcgIterations = 0;
    }
    /** Used after Remap3D installs velocities; cold-starts pressure and returns PCG iterations. */
    public int projectRemapped() { return projectRemappedMasked(null, 0); }
    /**
     * Remap projection on the listed boxes only (null: all), pressure cold-started; phi outside the rows stays 0,
     * so faces between two unlisted boxes keep their velocities. No gravity-consistent shift: the remap
     * projection only removes divergence (2D's rule, BoxSolver2D.project(false)).
     */
    public int projectRemappedMasked(int[] rows, int nRows) {
        Arrays.fill(state.phi, 0);
        refreshComponents();
        state.applyClosures(g);
        stats.pcgIterations = pressure.project(state, null, components, stats, rows, nRows);
        reconstruction.update(state); stale = false;
        return stats.pcgIterations;
    }
    /** Relabels components after a door toggle; the pocket rule may change effective boundary kinds. */
    private void refreshComponents() {
        if (componentsDirty) { components.recompute(g); componentsDirty = false; }
    }
    private int project() {
        refreshComponents();
        stats.topologyChanged = topologyDirty; topologyDirty = false;
        forcing.gravityShift(state, shift);
        return pressure.project(state, shift, components, stats);
    }
    private void ensureReconstruction() {
        if (stale) { refreshComponents(); state.applyClosures(g); reconstruction.update(state); stale = false; }
    }
    /** Speed cap, m/s: max(config maxSpeed, WIND_CAP_FACTOR × background wind speed). */
    public double speedCap() {
        double wind = Math.sqrt(state.backgroundX * state.backgroundX + state.backgroundY * state.backgroundY
                + state.backgroundZ * state.backgroundZ);
        return Math.max(c.maxSpeed(), WIND_CAP_FACTOR * wind);
    }
    /** Clamps interior and OPEN boundary normal speeds to the cap before the projection; returns the count. */
    private int clamp() {
        double cap = speedCap();
        int clamps = 0;
        for (int f = 0; f < state.u.length; f++)
            if (Math.abs(state.u[f]) > cap) { state.u[f] = Math.copySign(cap, state.u[f]); clamps++; }
        for (int k = 0; k < state.ub.length; k++)
            if (Math.abs(state.ub[k]) > cap && g.boundaryKind(k) == BoundaryKind.OPEN) {
                state.ub[k] = Math.copySign(cap, state.ub[k]); clamps++;
            }
        return clamps;
    }
    /** Max normal speed and divergence after the projection; nothing is changed here. */
    private void measure() {
        double max = 0;
        for (double u : state.u) max = Math.max(max, Math.abs(u));
        for (double u : state.ub) max = Math.max(max, Math.abs(u));
        stats.maxSpeed = max; stats.maxDivergence = maxDivergence();
    }
    /**
     * Adds one edit application to this replacement solver's ledger, after remap and projection: old's
     * unreported ledger plus energy (J, E_after − E_before) and fallback air/block cell counts.
     * Reported in the next step's statistics; never part of that step's energy residual.
     */
    public void recordEdit(BoxSolver3D old, double energy, int fallbackAir, int fallbackBlocks) {
        pendingEditEnergy = old.pendingEditEnergy + energy;
        pendingEditApplications = old.pendingEditApplications + 1;
        pendingFallbackAir = old.pendingFallbackAir + fallbackAir;
        pendingFallbackBlocks = old.pendingFallbackBlocks + fallbackBlocks;
    }
    /**
     * This graph's weighted-LSQ gradient workspace (geometry in m). Share it with other users of the same graph
     * (Indicators3D, Remap3D.Raster) instead of rebuilding it; calls keep no state between them, single thread.
     */
    public BoxGradients3D gradients() { return heat.gradients(); }
    /** Capped distances to solid cells (shared with replacement solvers on the same solid cells). */
    public SolidDistance3D solidDistance() { return distance; }
    /** Fixed graph; coordinates in m, face areas in m². */
    public BoxGraph3D graph() { return g; }
    /** Wall stores, with temperatures in °C and energy in J. */
    public WallStore3D wallStore() { return walls; }
    /** Re-reads the wall stores' couplings after {@link WallStore3D#refreshFixed} changed them (M8e). */
    public void refreshWallCouplings() { heat.refreshWallCouplings(); }
    /** Physical and numerical settings in their documented SI units. */
    public SolverConfig3D config() { return c; }
    /**
     * Sets the heat sweeps' over-relaxation factor from the next step on, dimensionless, in (0, 2) (M8e4; replays and
     * benches; D3's default is {@link SolverConfig3D#ADAPTIVE_THERMAL_RELAXATION}).
     */
    public void setThermalRelaxation(double omega) {
        c = c.withThermalRelaxation(omega);
        heat.setThermalRelaxation(omega);
    }
    /** Simulation time, s. */
    public double time() { return state.time; }
    /** Sets simulation time, s. */
    public void setTime(double seconds) { state.time = seconds; }
    /** Mutable last-step statistics in the units documented by StepStats. */
    public StepStats stats() { return stats; }
    /** Box temperature, °C. */
    public double temperature(int box) { return state.T[box]; }
    /** Sets box temperature, °C. */
    public void setTemperature(int box, double celsius) { state.T[box] = celsius; }
    /** Interior face normal velocity, m/s along +axis. */
    public double faceVelocity(int face) { return state.u[face]; }
    /** Sets interior face normal velocity, m/s along +axis. */
    public void setFaceVelocity(int face, double speed) { state.u[face] = speed; stale = true; }
    /** Boundary normal velocity, m/s along +axis. */
    public double boundaryVelocity(int boundary) { return state.ub[boundary]; }
    /** Sets boundary normal velocity, m/s along +axis. */
    public void setBoundaryVelocity(int boundary, double speed) { state.ub[boundary] = speed; stale = true; }
    /** Box pressure potential, m²/s. */
    public double pressure(int box) { return state.phi[box]; }
    /** Copies box pressure potentials, m²/s. */
    public void setPressure(double[] perBox) { copyBoxes(perBox, state.phi); }
    /** Copies per-box source powers, W. */
    public void setSources(double[] perBoxWatts) { copyBoxes(perBoxWatts, sources); }
    /** Heat source of a box, W (block sources plus any entity heat the mesh added). */
    public double source(int box) { return sources[box]; }
    private void copyBoxes(double[] from, double[] to) {
        if (from.length != g.boxCount()) throw new IllegalArgumentException("expected one value per box");
        System.arraycopy(from, 0, to, 0, to.length);
    }
    /** Sets the EXCHANGE faces' far-side temperatures (M8b; null, the default: all insulated). */
    public void setExchange(ExchangeTemperatures temperatures) { heat.setExchange(temperatures); }
    /** Changes a door aperture (dimensionless 0/1); topology statistics change at the next projection. */
    public void setDoorOpen(int box, boolean open) {
        boolean before = g.doorOpen(box); g.setDoorOpen(box, open);
        if (before != open) { componentsDirty = true; topologyDirty = true; stale = true; }
    }
    /** Equilibrates wall temperatures against box and background temperatures, °C. */
    public void equilibrateWallStores() {
        for (int cell = 0; cell < cellT.length; cell++) {
            int box = g.boxOfCellIndex(cell); cellT[cell] = box < 0 ? background.cell(cell) : state.T[box];
        }
        walls.equilibrate(cellT, heat::storeBackground);
    }
    /** Stored air plus wall energy relative to 0 °C, J. */
    public double totalEnergy() { return heat.totalEnergy(state); }
    /** Sets normal components from (ux,uy,uz), m/s, then applies closures and projects. */
    public void setUniformVelocity(double ux, double uy, double uz) {
        for (int f = 0; f < state.u.length; f++) state.u[f] = FlowState3D.component(g.faceAxis(f), ux, uy, uz);
        for (int k = 0; k < state.ub.length; k++) state.ub[k] = FlowState3D.component(g.boundaryAxis(k), ux, uy, uz);
        refreshComponents(); state.applyClosures(g); stats.pcgIterations = project(); reconstruction.update(state);
        stale = false;
    }
    /** Component labels, sealed flags and inflow-pocket statistics as of the last projection. */
    public SealedComponents3D components() { return components; }
    /** Sets background wind components, m/s. */
    public void setBackgroundWind(double ux, double uy, double uz) { state.setBackgroundWind(ux, uy, uz); }
    /** Background x component, m/s. */
    public double backgroundX() { return state.backgroundX; }
    /** Background y component, m/s. */
    public double backgroundY() { return state.backgroundY; }
    /** Background z component, m/s. */
    public double backgroundZ() { return state.backgroundZ; }
    /** Maximum absolute net volume flux / box volume, 1/s. */
    public double maxDivergence() {
        ensureReconstruction(); Arrays.fill(scratch, 0);
        for (int f = 0; f < state.u.length; f++) {
            double flux = state.u[f] * g.aperture(f) * g.faceArea(f);
            scratch[g.faceA(f)] += flux; scratch[g.faceB(f)] -= flux;
        }
        for (int k = 0; k < state.ub.length; k++) scratch[g.boundaryBox(k)] += (g.boundarySide(k) == 1 ? 1 : -1)
                * state.ub[k] * g.boundaryAperture(k) * g.boundaryArea(k);
        double max = 0;
        for (int i = 0; i < scratch.length; i++) max = Math.max(max, Math.abs(scratch[i] / g.boxVolume(i)));
        return max;
    }
    /** Samples box temperature (°C) at coordinates in m; the background in solid or outside (the reference). */
    public double sampleT(double x, double y, double z) {
        ensureReconstruction(); int box = g.boxAt(x, y, z);
        if (box >= 0) return state.T[box];
        return background.at((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
    }
    /** Samples velocity into out[3] (m/s) at coordinates in m; false outside or in solid. */
    public boolean sampleVelocity(double x, double y, double z, double[] out) {
        ensureReconstruction(); return reconstruction.sample(x, y, z, out);
    }
    /** Copies six side means (m/s), ordered x low/high, y low/high, z low/high. */
    public void sideVelocities(int box, double[] out) { ensureReconstruction(); reconstruction.sideVelocities(box, out); }
    /** Fills per-box centre velocity components, m/s. */
    public void centreVelocities(double[] ux, double[] uy, double[] uz) {
        ensureReconstruction(); reconstruction.centreVelocities(ux, uy, uz);
    }
}
