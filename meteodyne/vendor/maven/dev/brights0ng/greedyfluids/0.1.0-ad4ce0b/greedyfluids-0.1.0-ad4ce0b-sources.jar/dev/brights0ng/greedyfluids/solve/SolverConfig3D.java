// Written by ChatGPT from Claude's M5b spec.
// Edited by Claude: heat sweep over-relaxation factor (M6e3).
// Edited by Claude: ambientT is the expansion reference and default background; withAmbientT (M7a).
// Edited by Claude: D3's heat sweeps back to plain Gauss–Seidel; over-relaxation 1.2 diverged in strong flow (2026-11-21).
package dev.brights0ng.greedyfluids.solve;

/**
 * Fixed-mesh numerics: pressure is always PCG with the P1w multigrid preconditioner;
 * buoyancy is always gravity-consistent and wall storage is always on. These are not options.
 * @param dt step, s
 * @param rhoCp volumetric heat capacity, J/(m³·K)
 * @param kappa diffusivity, m²/s
 * @param g gravity, m/s²
 * @param damping damping rate, 1/s
 * @param maxSpeed speed cap, m/s
 * @param pcgMaxIterations pressure iteration cap, count
 * @param pcgTolerance divergence tolerance, 1/s
 * @param thermalMaxSweeps heat sweep cap, count
 * @param thermalTolerance temperature tolerance, °C per sweep
 * @param ambientT reference temperature, °C: the expansion coefficient is 1/(ambientT + 273.15), and the default
 *        uniform background ({@link Background3D}) when no per-cell field is set
 * @param thermalRelaxation over-relaxation factor of the heat sweeps, dimensionless, in (0, 2); 1 is plain
 *        Gauss–Seidel (M6e3 lever W)
 */
public record SolverConfig3D(double dt, double rhoCp, double kappa, double g, double damping,
        double maxSpeed, int pcgMaxIterations, double pcgTolerance, int thermalMaxSweeps,
        double thermalTolerance, double ambientT, double thermalRelaxation) {
    /** Settled physical and numerical defaults, in the units documented above. */
    /**
     * PCG tolerance (absolute max |r/V|, 1/s) for the adaptive solver D3 since M6b2 (Bright, 2026-11-07;
     * sweep variant T5). DEFAULT keeps 1e-7, which the references (A3, G3) use.
     */
    public static final double ADAPTIVE_PCG_TOLERANCE = 1e-5;
    /**
     * Heat sweep settings of adaptive (D3) runs: tolerance in °C per sweep (M6e3; Bright, 2026-11-11; sweep W12) and
     * the over-relaxation factor, 1: plain Gauss–Seidel (Bright, 2026-11-21). W12's relaxation 1.2 took about 30 %
     * fewer sweeps in still scenarios, but the heat matrix is not symmetric (upwind advection), and where flow through
     * small boxes dominates their heat capacity over a step (beyond about 3.7 m/s through 1 m boxes at 0.5 s) 1.2 is
     * outside the range over-relaxation is guaranteed to settle in. In strong wind its sweeps grew instead of settling:
     * a 30 m/s tile ran to the 500-sweep cap and 1e5 °C in one step (Meteodyne's failed tile, Engines and Empires
     * 2026-11-21; {@code HeatSweepStabilityTest}), where plain sweeps settle in under 25. A tolerance of 1e-5 (W12H5)
     * was the default for one commit and was withdrawn: its ledger exceeded 1e-4 on two extruded scenarios.
     * References keep DEFAULT's plain sweeps.
     */
    public static final double ADAPTIVE_THERMAL_TOLERANCE = 1e-7, ADAPTIVE_THERMAL_RELAXATION = 1;
    public static final SolverConfig3D DEFAULT =
            new SolverConfig3D(0.5, 1206, 1, 9.81, 0.05, 30, 1000, 1e-7, 500, 1e-7, 0);
    /** Plain Gauss–Seidel heat sweeps (thermalRelaxation 1). */
    public SolverConfig3D(double dt, double rhoCp, double kappa, double g, double damping, double maxSpeed,
            int pcgMaxIterations, double pcgTolerance, int thermalMaxSweeps, double thermalTolerance, double ambientT) {
        this(dt, rhoCp, kappa, g, damping, maxSpeed, pcgMaxIterations, pcgTolerance, thermalMaxSweeps,
                thermalTolerance, ambientT, 1);
    }
    public SolverConfig3D {
        if (!(thermalRelaxation > 0 && thermalRelaxation < 2)) throw new IllegalArgumentException("invalid solver configuration");
        if (!(dt > 0) || !(rhoCp > 0) || !(maxSpeed > 0) || !(pcgTolerance > 0)
                || !(thermalTolerance > 0) || !(kappa >= 0) || !(g >= 0) || !(damping >= 0)
                || pcgMaxIterations < 1 || thermalMaxSweeps < 1
                || !Double.isFinite(dt + rhoCp + maxSpeed + pcgTolerance + thermalTolerance
                        + kappa + g + damping + ambientT))
            throw new IllegalArgumentException("invalid solver configuration");
    }
    /** Copies with gravity in m/s². */
    public SolverConfig3D withG(double value) {
        return new SolverConfig3D(dt, rhoCp, kappa, value, damping, maxSpeed, pcgMaxIterations,
                pcgTolerance, thermalMaxSweeps, thermalTolerance, ambientT, thermalRelaxation);
    }
    /** Copies with diffusivity in m²/s. */
    public SolverConfig3D withKappa(double value) {
        return new SolverConfig3D(dt, rhoCp, value, g, damping, maxSpeed, pcgMaxIterations,
                pcgTolerance, thermalMaxSweeps, thermalTolerance, ambientT, thermalRelaxation);
    }
    /** Copies with pressure tolerance (1/s), heat tolerance (°C/sweep), and sweep cap (count). */
    public SolverConfig3D withTolerances(double pressure, double thermal, int sweeps) {
        return new SolverConfig3D(dt, rhoCp, kappa, g, damping, maxSpeed, pcgMaxIterations,
                pressure, sweeps, thermal, ambientT, thermalRelaxation);
    }
    /** Copies with the reference temperature, °C. */
    public SolverConfig3D withAmbientT(double value) {
        return new SolverConfig3D(dt, rhoCp, kappa, g, damping, maxSpeed, pcgMaxIterations,
                pcgTolerance, thermalMaxSweeps, thermalTolerance, value, thermalRelaxation);
    }
    /** Copies with the heat sweeps' over-relaxation factor, in (0, 2). */
    public SolverConfig3D withThermalRelaxation(double value) {
        return new SolverConfig3D(dt, rhoCp, kappa, g, damping, maxSpeed, pcgMaxIterations,
                pcgTolerance, thermalMaxSweeps, thermalTolerance, ambientT, value);
    }
}
